/* PublicDROP service worker: push notifications + installable-app support.
   It only ever steps in when a page navigation fails (offline); video, API and all other requests go straight to the network. */
var PD_CACHE = "publicdrop-shell-v1";
var PD_OFFLINE = "/offline.html";

self.addEventListener("install", function (e) {
  e.waitUntil(
    caches.open(PD_CACHE)
      .then(function (c) { return c.addAll([PD_OFFLINE, "/assets/icon-192.png"]); })
      .catch(function () {})
      .then(function () { return self.skipWaiting(); })
  );
});
self.addEventListener("activate", function (e) {
  e.waitUntil(
    caches.keys()
      .then(function (keys) { return Promise.all(keys.filter(function (k) { return k.indexOf("publicdrop-shell-") === 0 && k !== PD_CACHE; }).map(function (k) { return caches.delete(k); })); })
      .catch(function () {})
      .then(function () { return self.clients.claim(); })
  );
});

self.addEventListener("fetch", function (event) {
  var req = event.request;
  if (req.mode !== "navigate" || req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin || url.pathname.indexOf("/admin") === 0 || url.pathname.indexOf("/pd-api") === 0) return;
  event.respondWith(
    fetch(req).catch(function () {
      return caches.match(PD_OFFLINE).then(function (r) { return r || Response.error(); });
    })
  );
});

self.addEventListener("push", function (event) {
  var d = {};
  try { d = event.data ? event.data.json() : {}; } catch (e) {}
  event.waitUntil(
    self.registration.showNotification(d.title || "PublicDROP", {
      body: d.body || "",
      icon: "/assets/icon-192.png",
      badge: "/assets/icon-192.png",
      data: { url: d.url || "/" }
    })
  );
});

self.addEventListener("notificationclick", function (event) {
  event.notification.close();
  var target;
  try {
    target = new URL((event.notification.data && event.notification.data.url) || "/", self.location.origin);
    if (target.origin !== self.location.origin) target = new URL("/", self.location.origin);
  } catch (e) { target = new URL("/", self.location.origin); }
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (list) {
      for (var i = 0; i < list.length; i++) {
        if (list[i].url.indexOf(self.location.origin) === 0 && "focus" in list[i]) {
          if ("navigate" in list[i]) list[i].navigate(target.href);
          return list[i].focus();
        }
      }
      return self.clients.openWindow(target.href);
    })
  );
});
