/* PublicDROP service worker: push notifications only. It never touches page or video requests. */
self.addEventListener("install", function () { self.skipWaiting(); });
self.addEventListener("activate", function (e) { e.waitUntil(self.clients.claim()); });

self.addEventListener("push", function (event) {
  var d = {};
  try { d = event.data ? event.data.json() : {}; } catch (e) {}
  event.waitUntil(
    self.registration.showNotification(d.title || "PublicDROP", {
      body: d.body || "",
      icon: "/assets/icon-192.png",
      badge: "/assets/icon-192.png",
      data: { url: d.url || "/" }
    })
  );
});

self.addEventListener("notificationclick", function (event) {
  event.notification.close();
  var target;
  try {
    target = new URL((event.notification.data && event.notification.data.url) || "/", self.location.origin);
    if (target.origin !== self.location.origin) target = new URL("/", self.location.origin);
  } catch (e) { target = new URL("/", self.location.origin); }
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (list) {
      for (var i = 0; i < list.length; i++) {
        if (list[i].url.indexOf(self.location.origin) === 0 && "focus" in list[i]) {
          if ("navigate" in list[i]) list[i].navigate(target.href);
          return list[i].focus();
        }
      }
      return self.clients.openWindow(target.href);
    })
  );
});
