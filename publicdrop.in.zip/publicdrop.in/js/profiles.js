/* PublicDROP profiles: "Who's watching?" screen after login + full-screen My Space (account center).
   Additive: if this file fails to load, the rest of the website keeps working.
   Extra profiles are stored in the user's Supabase user_metadata (pd_profiles), so no database change is needed. */
(function () {
  "use strict";

  var AVATARS = [["a1", "Aria"],["a2", "Kabir"],["a3", "Meera"],["a4", "Zane"],["a5", "Ishaan"],["a6", "Luna"],["a7", "Rohan"],["a8", "Anaya"],["a9", "Veer"],["a10", "Sana"],["a11", "Dev"],["a12", "Tara"],["a13", "Kavya"],["a14", "Rudra"],["a15", "Pia"],["a16", "Omar"],["a17", "Nina"],["a18", "Yash"],["a19", "Zoya"],["a20", "Aman"],["a21", "Jiya"],["a22", "Aarav"],["a23", "Noor"],["a24", "Reyansh"],["a25", "Diya"],["a26", "Kian"],["a27", "Quest"],["a28", "Byte"],["a29", "Nova"],["a30", "Pixel"],["a31", "Ember"],["a32", "Rex"]];
  var MAX_PROFILES = 4; /* the main profile + up to 3 more = 4 in total */
  var CFG = window.PUBLICDROP_CONFIG || {};
  var TELEGRAM_URL = CFG.TELEGRAM_URL || "https://t.me/PublicDROPflix";
  var TELEGRAM_USERNAME = CFG.TELEGRAM_USERNAME || "@PublicDROPflix";
  var WHATSAPP_URL = CFG.WHATSAPP_CHANNEL_URL || "https://whatsapp.com/channel/0029Vb9CSbC0bIdvhZbGNS0h";
  var HISTORY_KEY = "publicdrop-watch-history", FAVORITES_KEY = "publicdrop-favorites", LANG_KEY = "publicdrop-lang";
  var CHOSEN_KEY = "pd-profile-chosen";
  var LANGS = [["en", "English", true], ["hi", "हिन्दी (Hindi)"], ["ta", "தமிழ் (Tamil)"], ["te", "తెలుగు (Telugu)"], ["bn", "বাংলা (Bengali)"], ["mr", "मराठी (Marathi)"]];

  /* ---------- small helpers ---------- */
  function $(sel) { return document.querySelector(sel); }
  function auth() { return window.PublicDROPAuth || null; }
  function session() { var a = auth(); return a && a.getSession ? a.getSession() : null; }
  function user() { var s = session(); return s && s.user ? s.user : null; }
  function esc(v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function ssGet(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
  function ssSet(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }
  /* "who is watching" is remembered on this device for 24 hours (survives closing the app); logout clears it */
  var CHOSEN_TTL = 24 * 3600 * 1000;
  function chosenOk(uid) {
    try { var v = JSON.parse(localStorage.getItem(CHOSEN_KEY) || "null"); if (v && v.uid === uid && Date.now() - v.ts < CHOSEN_TTL && v.ts <= Date.now() + 60000) return true; } catch (e) {}
    return false;
  }
  function chosenSet(uid) { try { localStorage.setItem(CHOSEN_KEY, JSON.stringify({ uid: uid, ts: Date.now() })); } catch (e) {} }
  function chosenDel() { try { localStorage.removeItem(CHOSEN_KEY); sessionStorage.removeItem(CHOSEN_KEY); } catch (e) {} }
  function ssDel(k) { try { sessionStorage.removeItem(k); } catch (e) {} }
  function readList(k) { try { var v = JSON.parse(localStorage.getItem(k) || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function validAvatar(id) { return /^a([1-9]|[12]\d|3[0-2])$/.test(String(id || "")); }
  function avatarSrc(id) { return "/assets/avatars/" + (validAvatar(id) ? id : "a1") + ".svg?v=2"; }
  function cleanName(v) { return String(v == null ? "" : v).replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 30); }
  function safeImg(url) { return /^(https:\/\/|\/|data:image\/)/i.test(String(url || "")) ? String(url) : ""; }
  function timeAgo(ts) {
    var s = Math.max(0, (Date.now() - Number(ts || 0)) / 1000);
    if (s < 60) return "just now"; if (s < 3600) return Math.floor(s / 60) + " min ago";
    if (s < 86400) return Math.floor(s / 3600) + " h ago"; if (s < 86400 * 30) return Math.floor(s / 86400) + " d ago";
    return new Date(Number(ts)).toLocaleDateString();
  }
  function clock(sec) {
    sec = Math.max(0, Math.floor(Number(sec) || 0));
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(s).padStart(2, "0");
  }
  function watchHref(e) {
    var type = ["movie", "tv", "anime"].indexOf(e.type) > -1 ? e.type : "movie", q = new URLSearchParams();
    if (type !== "movie") { q.set("season", String(Math.max(1, Number(e.season) || 1))); q.set("episode", String(Math.max(1, Number(e.episode) || 1))); }
    if (type === "anime") { q.set("dub", e.dub === "dub" ? "dub" : "sub"); if (e.isTmdb) q.set("isTmdb", "1"); if (e.tmdbType) q.set("tmdbType", e.tmdbType); }
    var suffix = q.toString();
    return "#/watch/" + type + "/" + encodeURIComponent(e.id) + (suffix ? "?" + suffix : "");
  }

  var ICONS = {
    back: '<path d="m15 18-6-6 6-6"/>',
    chev: '<path d="m9 18 6-6-6-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    send: '<path d="M22 2 11 13"/><path d="m22 2-7 20-4-9-9-4Z"/>',
    check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
    film: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
    chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/><path d="M9 11h6M9 14h4"/>'
  };
  function ico(name, cls) { return '<svg class="pd-ico ' + (cls || "") + '" viewBox="0 0 24 24" aria-hidden="true">' + ICONS[name] + "</svg>"; }

  /* ---------- profiles (main profile = the account itself; extras live in user_metadata.pd_profiles) ---------- */
  function mainName(u) {
    var a = auth();
    return cleanName(a && a.displayName ? a.displayName(u) : (u.email || "").split("@")[0]) || "Me";
  }
  function getProfiles(u) {
    var m = u.user_metadata || {};
    var list = [{ id: "main", name: mainName(u), avatar: validAvatar(m.avatar_id) ? m.avatar_id : "a9", main: true }];
    (Array.isArray(m.pd_profiles) ? m.pd_profiles : []).slice(0, MAX_PROFILES - 1).forEach(function (p) {
      var name = p ? cleanName(p.name).slice(0, 20) : "";
      if (p && /^p[a-z0-9]{4,12}$/.test(String(p.id)) && name) list.push({ id: p.id, name: name, avatar: validAvatar(p.avatar) ? p.avatar : "a9" });
    });
    return list;
  }
  function extras(u) { return getProfiles(u).filter(function (p) { return !p.main; }).map(function (p) { return { id: p.id, name: p.name, avatar: p.avatar }; }); }
  function activeProfile(u) {
    var list = getProfiles(u), id = lsGet("pd-profile:" + u.id);
    return list.filter(function (p) { return p.id === id; })[0] || list[0];
  }
  function setActive(u, id) { lsSet("pd-profile:" + u.id, id); paintTop(); }
  function newId() { return "p" + (Math.random().toString(36) + "000000").slice(2, 8); }

  /* ---------- top-bar avatar shows the profile you picked ---------- */
  function paintTop() {
    var btn = $("#account-button"), av = $("#account-avatar"), u = user();
    if (!btn || !av || !u) return;
    btn.title = "My Space"; btn.setAttribute("aria-label", "My Space");
    btn.setAttribute("aria-haspopup", "menu"); btn.setAttribute("aria-expanded", String(menuOpen));
    var src = avatarSrc(activeProfile(u).avatar), img = av.querySelector("img");
    if (img && img.getAttribute("src") === src) return;
    var changed = Boolean(img);
    av.innerHTML = '<img alt="" decoding="async" src="' + src + '">';
    if (changed) { btn.classList.remove("pd-pop-anim"); void btn.offsetWidth; btn.classList.add("pd-pop-anim"); }
  }
  (function watchTop() {
    function go() {
      var av = $("#account-avatar");
      if (!av || !window.MutationObserver) return;
      new MutationObserver(function () { paintTop(); }).observe(av, { childList: true });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else go();
  })();

  /* ---------- the full-screen layer ---------- */
  var root = null, viewEl = null, stack = [], hist = false, ignorePop = false, afterPop = null, editMode = false;

  function isOpen() { return Boolean(root && root.classList.contains("is-open")); }
  function top() { return stack[stack.length - 1]; }

  function ensureRoot() {
    if (root) return root;
    root = document.createElement("div");
    root.className = "pd-screen"; root.id = "pd-screen";
    root.setAttribute("role", "dialog"); root.setAttribute("aria-modal", "true"); root.setAttribute("aria-label", "PublicDROP profiles and My Space");
    viewEl = document.createElement("div"); viewEl.style.cssText = "display:flex;flex-direction:column;flex:1;min-height:0";
    root.appendChild(viewEl);
    document.body.appendChild(root);
    root.addEventListener("click", onClick);
    return root;
  }
  function lock(on) {
    document.documentElement.classList.toggle("pd-lock", on);
    ["#app", ".topbar", ".mobile-nav"].forEach(function (sel) { var el = $(sel); if (el) { try { el.inert = on; } catch (e) {} } });
  }
  function openScreen(view, params, dismissible) {
    ensureRoot();
    stack = [{ view: view, params: params || {}, dismissible: dismissible }];
    root.classList.add("is-open"); lock(true);
    if (!hist) { try { history.pushState({ pdScreen: 1 }, ""); hist = true; } catch (e) {} }
    render(true);
  }
  function nav(view, params) { stack.push({ view: view, params: params || {} }); render(true); }
  function hide() { if (root) root.classList.remove("is-open"); lock(false); stack = []; editMode = false; }
  function goBack() {
    if (stack.length > 1) { if (top().view === "who") editMode = false; stack.pop(); render(true); return; }
    if (hist) history.back(); else hide();
  }
  /* close everything and (optionally) run something once the browser history has settled */
  function closeAll(then) {
    var had = hist; hist = false; hide();
    if (had) { ignorePop = true; afterPop = then || null; try { history.back(); } catch (e) { ignorePop = false; if (then) then(); } }
    else if (then) then();
  }
  window.addEventListener("popstate", function () {
    if (ignorePop) { ignorePop = false; var f = afterPop; afterPop = null; if (f) setTimeout(f, 0); return; }
    if (!isOpen()) return;
    if (stack.length > 1) { stack.pop(); render(true); try { history.pushState({ pdScreen: 1 }, ""); hist = true; } catch (e) {} return; }
    hist = false;
    if (stack[0] && stack[0].dismissible) hide();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape" || !isOpen() || document.querySelector(".pd-confirm")) return;
    if (stack.length > 1 || (stack[0] && stack[0].dismissible)) { e.preventDefault(); goBack(); }
  });

  function host() { return root && isOpen() ? root : document.body; }
  function toast(text) {
    var old = document.querySelector(".pd-toast"); if (old) old.remove();
    var t = document.createElement("div"); t.className = "pd-toast"; t.setAttribute("role", "status"); t.textContent = text;
    host().appendChild(t); setTimeout(function () { if (t.parentNode) t.remove(); }, 2600);
  }

  function confirmBox(o) {
    return new Promise(function (resolve) {
      ensureRoot();
      var wrap = document.createElement("div"); wrap.className = "pd-confirm";
      wrap.innerHTML = '<div class="pd-confirm-box" role="alertdialog" aria-modal="true" aria-labelledby="pd-c-t" aria-describedby="pd-c-d">' +
        '<div class="pd-confirm-ico">' + ico(o.icon || "logout") + '</div><h3 id="pd-c-t">' + esc(o.title) + '</h3><p id="pd-c-d">' + esc(o.text) + '</p>' +
        '<div class="pd-confirm-actions"><button type="button" class="pd-btn-cancel">' + esc(o.cancel || "Cancel") + '</button><button type="button" class="pd-btn-ok">' + esc(o.ok || "OK") + '</button></div></div>';
      var prev = document.activeElement;
      host().appendChild(wrap);
      var cancel = wrap.querySelector(".pd-btn-cancel"), ok = wrap.querySelector(".pd-btn-ok");
      function done(v) { document.removeEventListener("keydown", onKey, true); wrap.remove(); if (prev && prev.focus) { try { prev.focus({ preventScroll: true }); } catch (e) {} } resolve(v); }
      function onKey(e) {
        if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); done(false); }
        else if (e.key === "Tab") { e.preventDefault(); (document.activeElement === cancel ? ok : cancel).focus(); }
      }
      document.addEventListener("keydown", onKey, true);
      cancel.addEventListener("click", function () { done(false); });
      ok.addEventListener("click", function () { done(true); });
      wrap.addEventListener("click", function (e) { if (e.target === wrap) done(false); });
      cancel.focus(); /* Cancel is focused first, so an accidental Enter never logs anyone out */
    });
  }

  /* ---------- views ---------- */
  function topBar(title, backLabel) {
    return '<div class="pd-top"><button type="button" class="pd-icon-btn" data-act="back" aria-label="' + esc(backLabel || "Back") + '">' + ico("back") + "</button><h2>" + esc(title) + "</h2></div>";
  }

  function vWho() {
    var u = user(), list = getProfiles(u), act = activeProfile(u), switching = stack.length > 1;
    var tiles = list.map(function (p, i) {
      return '<button type="button" class="pd-tile' + (p.id === act.id ? " is-active" : "") + '" data-act="pick-profile" data-id="' + esc(p.id) + '" style="--i:' + i + '">' +
        '<span class="pd-tile-ring"><img alt="" src="' + avatarSrc(p.avatar) + '">' + (editMode ? '<span class="pd-edit-ico">' + ico("edit") + "</span>" : "") + "</span>" +
        '<span class="pd-tile-name">' + esc(p.name) + "</span></button>";
    }).join("");
    if (list.length < MAX_PROFILES) {
      tiles += '<button type="button" class="pd-tile pd-tile-add" data-act="add-profile" style="--i:' + list.length + '"><span class="pd-tile-ring">' + ico("plus") + '</span><span class="pd-tile-name">Add Profile</span></button>';
    }
    return '<div class="pd-who' + (editMode ? " pd-editing" : "") + '">' +
      '<div class="pd-top pd-who-top"><div class="pd-left">' +
      (switching ? '<button type="button" class="pd-icon-btn" data-act="back" aria-label="Back">' + ico("back") + "</button>" : '<span class="pd-brand"><img alt="" src="/assets/publicdrop-favicon.png"><span>PublicDROP</span></span>') +
      "</div><h1>" + (editMode ? "Manage profiles" : "Who’s watching?") + '</h1><div class="pd-right"><button type="button" class="pd-text-btn" data-act="toggle-edit">' +
      (editMode ? "Done" : ico("edit") + " Edit") + "</button></div></div>" +
      '<div class="pd-who-stage"><p class="pd-who-sub">' + (editMode ? "Tap a profile to change its name or avatar" : "Pick a profile to start watching") + "</p>" +
      '<div class="pd-who-grid">' + tiles + "</div></div></div>";
  }

  function vMySpace() {
    var u = user(), list = getProfiles(u), act = activeProfile(u);
    var chips = list.map(function (p) {
      return '<button type="button" class="pd-chip' + (p.id === act.id ? " is-active" : "") + '" data-act="switch" data-id="' + esc(p.id) + '"><span class="pd-chip-ring"><img alt="" src="' + avatarSrc(p.avatar) + '"></span><span>' + esc(p.name) + "</span></button>";
    }).join("");
    if (list.length < MAX_PROFILES) chips += '<button type="button" class="pd-chip pd-chip-add" data-act="add-profile"><span class="pd-chip-ring">' + ico("plus") + "</span><span>Add Profile</span></button>";
    var lang = (LANGS.filter(function (l) { return l[0] === (lsGet(LANG_KEY) || "en"); })[0] || LANGS[0])[1];
    return topBar("Help & Settings", "Close") +
      '<div class="pd-col"><section class="pd-me"><div class="pd-me-avatar"><img alt="" src="' + avatarSrc(act.avatar) + '"></div><div class="pd-me-info"><strong>' + esc(act.name) + "</strong><span>" + esc(u.email || "") + '</span><span class="pd-sync">Cloud sync on</span></div></section>' +
      '<div style="display:flex;align-items:center;justify-content:space-between"><span class="pd-label">Profiles</span><button type="button" class="pd-text-btn" style="min-height:34px;margin-top:20px;padding:0 13px;font-size:.78rem" data-act="manage">' + ico("edit") + " Manage</button></div>" +
      '<div class="pd-strip">' + chips + "</div>" +
      '<span class="pd-label">Settings</span><ul class="pd-menu">' +
      '<li style="--n:0"><button type="button" class="pd-row" data-act="account"><span class="pd-row-ico">' + ico("user") + '</span><span class="pd-row-txt"><b>Account Settings</b><small>Profile, watch history &amp; My List</small></span>' + ico("chev", "pd-chev") + "</button></li>" +
      '<li style="--n:0"><button type="button" class="pd-row" data-act="audiolang"><span class="pd-row-ico">' + ico("film") + '</span><span class="pd-row-txt"><b>Movie Language</b><small>' + esc(audioName()) + ' \u00b7 top hit movies shown on the home page</small></span>' + ico("chev", "pd-chev") + "</button></li>" +
      '<li style="--n:1"><button type="button" class="pd-row" data-act="language"><span class="pd-row-ico">' + ico("globe") + '</span><span class="pd-row-txt"><b>App Language</b><small>' + esc(lang) + "</small></span>" + ico("chev", "pd-chev") + "</button></li>" +
      '<li style="--n:2"><button type="button" class="pd-row" data-act="help"><span class="pd-row-ico">' + ico("send") + '</span><span class="pd-row-txt"><b>Help &amp; Support</b><small>Contact admin · Telegram · WhatsApp updates</small></span>' + ico("chev", "pd-chev") + "</button></li>" +
      '<li style="--n:3"><button type="button" class="pd-row" data-act="request"><span class="pd-row-ico">' + ico("film") + '</span><span class="pd-row-txt"><b>Request a Movie</b><small>Can\u2019t find a title? Ask the admin to add it</small></span>' + ico("chev", "pd-chev") + "</button></li></ul>" +
      '<div class="pd-logout-wrap"><button type="button" class="pd-logout" data-act="logout">Log Out</button></div><p class="pd-foot">PublicDROP</p></div>';
  }

  function vAccount() {
    var u = user(), tab = top().params.tab || "overview", body = "";
    var tabs = [["overview", "Overview"], ["history", "Watch history"], ["list", "My List"]].map(function (t) {
      return '<button type="button" class="pd-tab" role="tab" data-act="tab" data-tab="' + t[0] + '" aria-selected="' + (t[0] === tab) + '">' + t[1] + "</button>";
    }).join("");
    if (tab === "history") {
      var hl = readList(HISTORY_KEY).filter(function (x) { return x && x.id && x.title; });
      body = hl.length ? '<div class="pd-list">' + hl.map(function (e) {
        var label = e.type === "movie" ? "Movie" : "S" + Math.max(1, Number(e.season) || 1) + " E" + Math.max(1, Number(e.episode) || 1);
        var pct = e.duration > 0 ? Math.min(100, Math.round(e.currentTime / e.duration * 100)) : 0;
        var status = e.finished ? "Finished" : (e.duration > 0 ? "Stopped at " + clock(e.currentTime) + " (" + pct + "%)" : "Watched");
        return mediaRow(watchHref(e), e, label + " · " + status + " · " + timeAgo(e.watchedAt), !e.finished && pct > 0 ? pct : 0);
      }).join("") + '</div><button type="button" class="pd-danger-link" data-act="clear-history">Clear watch history</button>'
        : '<div class="pd-empty">Nothing watched yet.<br>Start a movie or series and it will show up here.</div>';
    } else if (tab === "list") {
      var fl = readList(FAVORITES_KEY).filter(function (x) { return x && x.id && x.title && ["movie", "tv", "anime"].indexOf(x.type) > -1; });
      body = fl.length ? '<div class="pd-list">' + fl.map(function (m) {
        var kind = m.type === "tv" ? "Series" : m.type === "anime" ? "Anime" : "Movie", year = m.year || (m.releaseDate ? String(m.releaseDate).slice(0, 4) : "");
        return mediaRow("#/detail/" + m.type + "/" + m.id, m, kind + (year ? " · " + year : ""), 0);
      }).join("") + "</div>" : '<div class="pd-empty">Your list is empty.<br>Tap the + or heart on any title to save it here.</div>';
    } else {
      var provider = String((u.app_metadata && u.app_metadata.provider) || "email");
      var providerName = { google: "Google", discord: "Discord", github: "GitHub" }[provider] || "Email & password";
      body = '<div class="pd-card"><div class="pd-kv"><span>Email</span><b>' + esc(u.email || "—") + '</b></div><div class="pd-kv"><span>Name</span><b>' + esc(mainName(u)) + '</b></div>' +
        '<div class="pd-kv"><span>Sign-in method</span><b>' + esc(providerName) + '</b></div><div class="pd-kv"><span>Profiles</span><b>' + getProfiles(u).length + " of " + MAX_PROFILES + "</b></div>" +
        (u.created_at ? '<div class="pd-kv"><span>Member since</span><b>' + esc(new Date(u.created_at).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" })) + "</b></div>" : "") + "</div>" +
        '<button type="button" class="pd-primary" data-act="edit-main">Edit my name &amp; avatar</button>' +
        (provider === "email" ? '<button type="button" class="pd-secondary" data-act="change-pass">Change password</button>'
          : '<p class="pd-hint">You sign in with ' + esc(providerName) + ", so there is no site password to change.</p>");
    }
    return topBar("Account Settings") + '<div class="pd-col"><div class="pd-tabs" role="tablist">' + tabs + "</div>" + body + "</div>";
  }

  function mediaRow(href, item, sub, pct) {
    var img = safeImg(item.poster || item.backdrop);
    return '<a class="pd-media" href="' + esc(href) + '" data-go="1">' + (img ? '<img loading="lazy" alt="" src="' + esc(img) + '">' : '<span class="pd-ph"></span>') +
      '<span class="pd-info"><b>' + esc(item.title || "Untitled") + "</b><small>" + esc(sub) + "</small>" + (pct ? '<span class="pd-bar"><i style="width:' + pct + '%"></i></span>' : "") + "</span></a>";
  }

  function audioName() { var A = window.PublicDROPAudio; return A ? A.info(A.get()).name : "Hindi"; }
  function vAudioLang() {
    var A = window.PublicDROPAudio, cur = A ? A.get() : "hi"; if (!A) return topBar("Movie Language");
    return topBar("Movie Language") + '<div class="pd-col"><div class="pd-card" style="padding:0"><ul class="pd-lang" role="radiogroup" aria-label="Movie language">' +
      A.langs.map(function (l) { return '<li><button type="button" role="radio" data-act="set-audio" data-lang="' + l.code + '" aria-checked="' + (l.code === cur) + '"><span class="pd-radio"></span><span>' + esc(l.name + (l.native && l.native !== l.name ? " (" + l.native + ")" : "")) + "</span></button></li>"; }).join("") +
      '</ul></div><p class="pd-note">The home page shows the top hit movies made in this language. Default is Hindi.</p></div>';
  }
  function vLanguage() {
    var cur = lsGet(LANG_KEY) || "en";
    return topBar("App Language") + '<div class="pd-col"><div class="pd-card" style="padding:0"><ul class="pd-lang" role="radiogroup" aria-label="App language">' +
      LANGS.map(function (l) {
        var on = l[2] === true;
        return '<li><button type="button" role="radio" data-act="set-lang" data-lang="' + l[0] + '" aria-checked="' + (l[0] === cur) + '"' + (on ? "" : " disabled") + '><span class="pd-radio"></span><span>' + esc(l[1]) + "</span>" + (on ? "" : "<small>Coming soon</small>") + "</button></li>";
      }).join("") + '</ul></div><p class="pd-note">PublicDROP is available in English today. More languages are on the way.</p></div>';
  }

  function avatarLabel(id) { var f = AVATARS.filter(function (a) { return a[0] === id; })[0]; return f ? f[1] : ""; }

  function vEditor() {
    var u = user(), p = top().params, isMain = p.id === "main", isNew = !p.id;
    if (!p.init) {
      var found = getProfiles(u).filter(function (x) { return x.id === p.id; })[0];
      if (isNew) {
        var used = getProfiles(u).map(function (x) { return x.avatar; });
        var free = AVATARS.filter(function (a) { return used.indexOf(a[0]) < 0; });
        p.avatar = (free[Math.floor(Math.random() * free.length)] || AVATARS[0])[0]; p.name = "";
      } else if (found) { p.avatar = found.avatar; p.name = found.name; }
      else { p.avatar = "a9"; p.name = ""; }
      p.init = true;
    }
    var items = AVATARS.map(function (a, i) {
      return '<button type="button" class="pd-car-item" role="option" tabindex="-1" data-act="pick-avatar" data-idx="' + i + '" data-av="' + a[0] + '" aria-selected="' + (a[0] === p.avatar) + '" aria-label="' + esc(a[1]) + '"><img alt="" draggable="false" src="' + avatarSrc(a[0]) + '"></button>';
    }).join("");
    return '<div class="pd-top pd-ed-top"><button type="button" class="pd-icon-btn pd-plain" data-act="back" aria-label="Back">' + ico("back") + "</button><h2>" + (isNew ? "Create Profile" : "Edit Profile") + '</h2><span class="pd-ed-sp"></span></div>' +
      '<div class="pd-car-wrap"><div class="pd-car" id="pd-car" role="listbox" tabindex="0" aria-label="Swipe to choose an avatar">' + items + '</div>' +
      '<div class="pd-car-name" id="pd-ed-avname" aria-live="polite">' + esc(avatarLabel(p.avatar)) + "</div></div>" +
      '<div class="pd-col pd-ed-col"><label class="pd-float"><input id="pd-ed-name" maxlength="' + (isMain ? 30 : 20) + '" autocomplete="off" autocapitalize="words" enterkeyhint="done" placeholder=" " aria-label="Your Name" value="' + esc(p.name) + '"><span>Your Name</span></label>' +
      '<p class="pd-msg" id="pd-ed-msg" role="status"></p>' +
      (!isMain && !isNew ? '<button type="button" class="pd-secondary is-danger" data-act="delete-profile">Delete profile</button>' : "") + "</div>" +
      '<button type="button" class="pd-fab" data-act="save-profile" aria-label="' + (isNew ? "Create profile" : "Save changes") + '">' + ico("check") + "</button>";
  }

  /* swipe carousel: the avatar in the middle is the chosen one and grows; the others shrink away */
  function initCarousel() {
    var car = $("#pd-car"); if (!car) return;
    var items = [].slice.call(car.querySelectorAll(".pd-car-item")), p = top().params, slot = 78, raf = 0, drag = null;
    function idxOf(id) { for (var i = 0; i < items.length; i++) if (items[i].getAttribute("data-av") === id) return i; return 0; }
    function paint() {
      raf = 0;
      var mid = car.scrollLeft + car.clientWidth / 2, best = 0, bd = 1e9;
      slot = items[0].offsetWidth || slot;
      items.forEach(function (it, i) {
        var c = it.offsetLeft + it.offsetWidth / 2, d = Math.abs(c - mid);
        it.firstChild.style.transform = "scale(" + (1 + 0.85 * Math.max(0, 1 - d / slot)).toFixed(3) + ")";
        it.style.opacity = String(Math.max(0.45, 1 - d / (slot * 3.2)).toFixed(2));
        if (d < bd) { bd = d; best = i; }
      });
      var id = items[best].getAttribute("data-av");
      items.forEach(function (it, i) { it.setAttribute("aria-selected", String(i === best)); it.classList.toggle("is-center", i === best); });
      if (p.avatar !== id) { p.avatar = id; var nm = $("#pd-ed-avname"); if (nm) { nm.textContent = avatarLabel(id); nm.classList.remove("pd-swap"); void nm.offsetWidth; nm.classList.add("pd-swap"); } }
    }
    function go(i, smooth) { i = Math.max(0, Math.min(items.length - 1, i)); car.scrollTo({ left: i * (items[0].offsetWidth || slot), behavior: smooth ? "smooth" : "auto" }); }
    car.addEventListener("scroll", function () { if (!raf) raf = requestAnimationFrame(paint); }, { passive: true });
    car.addEventListener("keydown", function (e) {
      var cur = idxOf(p.avatar);
      if (e.key === "ArrowRight") { e.preventDefault(); go(cur + 1, true); } else if (e.key === "ArrowLeft") { e.preventDefault(); go(cur - 1, true); }
      else if (e.key === "Home") { e.preventDefault(); go(0, true); } else if (e.key === "End") { e.preventDefault(); go(items.length - 1, true); }
    });
    car.addEventListener("click", function (e) { var it = e.target.closest && e.target.closest(".pd-car-item"); if (it && !car.__moved) go(Number(it.getAttribute("data-idx")), true); car.__moved = false; });
    /* mouse drag (touch already scrolls natively) */
    car.addEventListener("pointerdown", function (e) { if (e.pointerType !== "mouse" || e.button) return; drag = { x: e.clientX, l: car.scrollLeft }; car.__moved = false; });
    window.addEventListener("pointermove", function mv(e) {
      if (!document.body.contains(car)) { window.removeEventListener("pointermove", mv); return; }
      if (!drag) return; var dx = e.clientX - drag.x;
      if (Math.abs(dx) > 4) { car.__moved = true; car.classList.add("is-drag"); car.scrollLeft = drag.l - dx; }
    });
    window.addEventListener("pointerup", function up() {
      if (!document.body.contains(car)) { window.removeEventListener("pointerup", up); return; }
      if (!drag) return; drag = null;
      if (car.classList.contains("is-drag")) { car.classList.remove("is-drag"); go(Math.round(car.scrollLeft / (items[0].offsetWidth || slot)), true); }
    });
    car.style.scrollBehavior = "auto"; car.scrollLeft = idxOf(p.avatar) * (items[0].offsetWidth || slot); paint(); car.style.scrollBehavior = "";
    window.addEventListener("resize", function rs() { if (!document.body.contains(car)) { window.removeEventListener("resize", rs); return; } go(idxOf(p.avatar), false); });
    var nameInput = $("#pd-ed-name");
    if (nameInput) {
      nameInput.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); saveProfile(); } });
      if (!p.id) { try { nameInput.focus({ preventScroll: true }); } catch (e) {} }
    }
  }

  /* ---------- Help & Support and Request a Movie (messages go to the admin panel; signed-in people only) ---------- */
  async function accessToken() {
    try { var c = await auth().getClient(); var r = await c.auth.getSession(); var t = r && r.data && r.data.session && r.data.session.access_token; if (t) return t; } catch (e) {}
    var s = session(); return (s && s.access_token) || "";
  }
  async function sendToAdmin(payload) {
    var tok = await accessToken();
    if (!tok) throw new Error("Please sign in to send this.");
    var res, j = {};
    try { res = await fetch("/pd-api/inbox", { method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + tok }, body: JSON.stringify(payload) }); }
    catch (e) { throw new Error("No connection. Please check your internet and try again."); }
    try { j = await res.json(); } catch (e) {}
    if (!res.ok) throw new Error(j.error || "Could not send. Please try again in a moment.");
  }
  function vHelp() {
    var u = user();
    return topBar("Help & Support", "Back") +
      '<div class="pd-col">' +
      '<section class="pd-hero"><span class="pd-hero-ico">' + ico("chat") + '</span><div><strong>We\u2019re here to help</strong><span>Message the admin directly, or join our channels to get every update first.</span></div></section>' +
      '<span class="pd-label">Updates &amp; community</span><ul class="pd-menu">' +
      '<li style="--n:0"><a class="pd-row" href="' + esc(TELEGRAM_URL) + '" target="_blank" rel="noopener noreferrer"><span class="pd-row-ico">' + ico("send") + '</span><span class="pd-row-txt"><b>Telegram</b><small>Username: <span class="pd-user">' + esc(TELEGRAM_USERNAME) + "</span> · tap to join</small></span>" + ico("chev", "pd-chev") + "</a></li>" +
      '<li style="--n:1"><a class="pd-row" href="' + esc(WHATSAPP_URL) + '" target="_blank" rel="noopener noreferrer"><span class="pd-row-ico">' + ico("chat") + '</span><span class="pd-row-txt"><b>Join WhatsApp Channel</b><small>All updates, new releases and announcements</small></span>' + ico("chev", "pd-chev") + "</a></li></ul>" +
      '<span class="pd-label">Message the admin</span>' +
      '<div class="pd-form">' +
      '<label class="pd-fl" for="pd-h-sub">Subject <em>(optional)</em></label><input class="pd-field" id="pd-h-sub" maxlength="120" autocomplete="off" placeholder="e.g. Video not playing">' +
      '<label class="pd-fl" for="pd-h-body">Your message</label><textarea class="pd-field pd-area" id="pd-h-body" maxlength="1500" rows="5" placeholder="Tell us what you need help with\u2026"></textarea>' +
      '<p class="pd-hint">Sent to the admin from <b>' + esc((u && u.email) || "your account") + '</b>. Please never share your password.</p>' +
      '<button type="button" class="pd-primary" data-act="send-help" style="margin-top:14px">Send message</button>' +
      '<p class="pd-msg" id="pd-h-msg" role="status"></p></div></div>';
  }
  function vRequest() {
    var u = user();
    return topBar("Request a Movie", "Back") +
      '<div class="pd-col">' +
      '<section class="pd-hero"><span class="pd-hero-ico">' + ico("film") + '</span><div><strong>Can\u2019t find something?</strong><span>Tell us the title and the admin will see your request right away.</span></div></section>' +
      '<div class="pd-form">' +
      '<label class="pd-fl" for="pd-r-title">Movie or series name</label><input class="pd-field" id="pd-r-title" maxlength="120" autocomplete="off" enterkeyhint="next" placeholder="e.g. Oppenheimer">' +
      '<div class="pd-two"><div><label class="pd-fl" for="pd-r-type">Type</label><select class="pd-field" id="pd-r-type"><option value="movie">Movie</option><option value="series">Series</option><option value="anime">Anime</option><option value="cartoon">Cartoon</option></select></div>' +
      '<div><label class="pd-fl" for="pd-r-year">Year <em>(optional)</em></label><input class="pd-field" id="pd-r-year" maxlength="4" inputmode="numeric" autocomplete="off" placeholder="2023"></div></div>' +
      '<label class="pd-fl" for="pd-r-note">Anything else? <em>(optional)</em></label><textarea class="pd-field pd-area" id="pd-r-note" maxlength="500" rows="3" placeholder="Language, season, quality\u2026"></textarea>' +
      '<p class="pd-hint">Sent as <b>' + esc((u && u.email) || "your account") + "</b>. One request per title, please.</p>" +
      '<button type="button" class="pd-primary" data-act="send-request" style="margin-top:14px">Send request</button>' +
      '<p class="pd-msg" id="pd-r-msg" role="status"></p></div></div>';
  }
  function vPassword() {
    return topBar("Change Password") + '<div class="pd-col"><div class="pd-form">' +
      '<label class="pd-fl" for="pd-pw-cur">Current password</label><input class="pd-field" id="pd-pw-cur" type="password" autocomplete="current-password" maxlength="128">' +
      '<label class="pd-fl" for="pd-pw-new">New password <em>(min 8 characters)</em></label><input class="pd-field" id="pd-pw-new" type="password" autocomplete="new-password" maxlength="128">' +
      '<label class="pd-fl" for="pd-pw-rep">Confirm new password</label><input class="pd-field" id="pd-pw-rep" type="password" autocomplete="new-password" maxlength="128">' +
      '<button type="button" class="pd-primary" data-act="save-pass" style="margin-top:20px">Update password</button>' +
      '<p class="pd-msg" id="pd-pw-msg" role="status"></p></div></div>';
  }
  async function submitPassword() {
    var u = user(), cur = $("#pd-pw-cur"), nw = $("#pd-pw-new"), rep = $("#pd-pw-rep"), msg = $("#pd-pw-msg"), btn = root.querySelector('[data-act="save-pass"]');
    if (!u || !cur || !msg) return;
    function say(t, cls) { msg.className = "pd-msg " + (cls || ""); msg.textContent = t; }
    if (!cur.value) { say("Enter your current password.", "err"); cur.focus(); return; }
    if (nw.value.length < 8) { say("New password must be at least 8 characters.", "err"); nw.focus(); return; }
    if (nw.value === cur.value) { say("New password must be different from the current one.", "err"); nw.focus(); return; }
    if (nw.value !== rep.value) { say("The two new passwords do not match.", "err"); rep.focus(); return; }
    if (!auth()) { say("Sign-in service is not ready. Please try again.", "err"); return; }
    btn.disabled = true; say("Updating\u2026");
    try {
      var c = await auth().getClient();
      var chk = await c.auth.signInWithPassword({ email: u.email, password: cur.value });
      if (chk && chk.error) { say("Current password is incorrect.", "err"); cur.focus(); btn.disabled = false; return; }
      var r = await c.auth.updateUser({ password: nw.value });
      if (r && r.error) { say(r.error.message || "Could not update the password.", "err"); btn.disabled = false; return; }
      cur.value = ""; nw.value = ""; rep.value = "";
      say("Password updated.", "ok"); toast("Password changed");
    } catch (e) { say((e && e.message) || "Could not update the password.", "err"); }
    btn.disabled = false;
  }
  async function submitHelp() {
    var body = $("#pd-h-body"), sub = $("#pd-h-sub"), msg = $("#pd-h-msg"), btn = root.querySelector('[data-act="send-help"]');
    if (!body || !msg) return;
    function say(t, cls) { msg.className = "pd-msg " + (cls || ""); msg.textContent = t; }
    if (body.value.trim().length < 5) { say("Please write your message first.", "err"); body.focus(); return; }
    btn.disabled = true; say("Sending\u2026");
    try {
      await sendToAdmin({ kind: "message", subject: sub.value.trim(), body: body.value.trim() });
      body.value = ""; sub.value = ""; say("Sent! The admin will read it in the admin panel.", "ok"); toast("Message sent to admin");
    } catch (e) { say((e && e.message) || "Could not send.", "err"); }
    btn.disabled = false;
  }
  async function submitRequest() {
    var title = $("#pd-r-title"), type = $("#pd-r-type"), year = $("#pd-r-year"), note = $("#pd-r-note"), msg = $("#pd-r-msg"), btn = root.querySelector('[data-act="send-request"]');
    if (!title || !msg) return;
    function say(t, cls) { msg.className = "pd-msg " + (cls || ""); msg.textContent = t; }
    var y = year.value.replace(/\D/g, "").slice(0, 4);
    if (title.value.trim().length < 2) { say("Please type the movie or series name.", "err"); title.focus(); return; }
    if (y && (y.length !== 4 || Number(y) < 1900 || Number(y) > new Date().getFullYear() + 2)) { say("Please enter a 4-digit year, or leave it empty.", "err"); year.focus(); return; }
    btn.disabled = true; say("Sending\u2026");
    try {
      await sendToAdmin({ kind: "request", subject: title.value.trim(), type: type.value, year: y, body: note.value.trim() });
      title.value = ""; year.value = ""; note.value = ""; say("Request sent! The admin can see it in the admin panel.", "ok"); toast("Request sent to admin");
    } catch (e) { say((e && e.message) || "Could not send.", "err"); }
    btn.disabled = false;
  }

  var VIEWS = { who: vWho, myspace: vMySpace, account: vAccount, language: vLanguage, audiolang: vAudioLang, editor: vEditor, help: vHelp, request: vRequest, password: vPassword };

  function render(focusHeading) {
    if (!root || !stack.length) return;
    var t = top(), fn = VIEWS[t.view];
    if (!user()) { hide(); return; }
    var scroll = root.scrollTop;
    viewEl.innerHTML = fn();
    root.scrollTop = focusHeading ? 0 : scroll;
    if (focusHeading) {
      var h = viewEl.querySelector("h1,h2");
      if (h) { h.tabIndex = -1; try { h.focus({ preventScroll: true }); } catch (e) {} }
    }
    if (t.view === "editor") initCarousel();
  }

  /* ---------- actions ---------- */
  function choose(id, quiet) {
    var u = user(); if (!u) return;
    var p = getProfiles(u).filter(function (x) { return x.id === id; })[0] || getProfiles(u)[0];
    chosenSet(u.id); setActive(u, p.id);
    if (isOpen() && top().view === "myspace") { render(false); if (!quiet) toast("Now watching as " + p.name); return; }
    if (isOpen() && stack.length > 1 && stack[0].view === "myspace") { /* picked from "Manage" inside My Space: go back to it */
      editMode = false; stack.pop(); render(true); toast("Now watching as " + p.name); return;
    }
    closeAll();
  }

  async function saveProfile() {
    var t = top(), p = t.params, u = user(), msg = $("#pd-ed-msg"), input = $("#pd-ed-name"), btn = root.querySelector('[data-act="save-profile"]');
    if (!u || !msg || !input) return;
    var isMain = p.id === "main", name = cleanName(input.value);
    if (!isMain) name = name.slice(0, 20);
    function fail(text) { msg.className = "pd-msg err"; msg.textContent = text; }
    if (name.length < 2) return fail("Please enter a name with at least 2 characters.");
    var clash = getProfiles(u).some(function (x) { return x.id !== p.id && x.name.toLowerCase() === name.toLowerCase(); });
    if (clash) return fail("Another profile already uses that name.");
    if (!auth()) return fail("Sign-in service is not ready. Please try again.");
    btn.disabled = true; msg.className = "pd-msg"; msg.textContent = "Saving…";
    try {
      if (isMain) {
        await auth().updateProfile({ name: name, avatar: p.avatar });
      } else {
        var list = extras(u);
        if (p.id) { list = list.map(function (x) { return x.id === p.id ? { id: x.id, name: name, avatar: p.avatar } : x; }); }
        else { if (list.length >= MAX_PROFILES - 1) throw new Error("You can have up to " + MAX_PROFILES + " profiles."); list.push({ id: newId(), name: name, avatar: p.avatar }); }
        await auth().updateMeta({ pd_profiles: list });
      }
      paintTop();
      goBack(); toast(p.id ? "Profile updated" : "Profile created");
    } catch (e) {
      btn.disabled = false; fail((e && e.message) || "Could not save. Please check your connection and try again.");
    }
  }

  async function deleteProfile() {
    var t = top(), p = t.params, u = user();
    if (!u || !p.id || p.id === "main") return;
    var ok = await confirmBox({ icon: "user", title: "Delete this profile?", text: "“" + (cleanName($("#pd-ed-name").value) || "This profile") + "” will be removed from your account.", ok: "Delete", cancel: "Cancel" });
    if (!ok) return;
    try {
      await auth().updateMeta({ pd_profiles: extras(u).filter(function (x) { return x.id !== p.id; }) });
      if (lsGet("pd-profile:" + u.id) === p.id) setActive(u, "main");
      goBack(); toast("Profile deleted");
    } catch (e) { toast("Could not delete. Please try again."); }
  }

  async function doLogout() {
    var ok = await confirmBox({
      icon: "logout", title: "Log out of PublicDROP?",
      text: "You will need to sign in again to see your profiles, My List and Continue Watching on this device.", ok: "Log Out", cancel: "Cancel"
    });
    if (!ok) return;
    try {
      await auth().signOut();
      chosenDel();
      closeAll();
    } catch (e) { toast((e && e.message) || "Could not log out. Please try again."); }
  }

  async function clearHistory() {
    var ok = await confirmBox({ icon: "user", title: "Clear watch history?", text: "This removes the list of titles you have watched. My List is not affected.", ok: "Clear", cancel: "Cancel" });
    if (!ok) return;
    try { localStorage.setItem(HISTORY_KEY, "[]"); } catch (e) {}
    var u = user();
    try { var ss = window.PublicDROPAuth && PublicDROPAuth.getSession && PublicDROPAuth.getSession(); if (ss && ss.access_token) fetch("/pd-api/wh", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "Authorization": "Bearer " + ss.access_token }, body: JSON.stringify({ clear: true }) }).catch(function () {}); } catch (e) {}
    if (u && auth()) { try { var c = await auth().getClient(); await c.from("watch_history").delete().eq("user_id", u.id); } catch (e) {} }
    render(false);
  }

  document.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && e.target && e.target.id === "pd-r-title") { e.preventDefault(); submitRequest(); }
  });

  function onClick(e) {
    var link = e.target.closest && e.target.closest("a[data-go]");
    if (link) { e.preventDefault(); var href = link.getAttribute("href"); closeAll(function () { location.hash = href; }); return; }
    var el = e.target.closest && e.target.closest("[data-act]");
    if (!el || !root.contains(el)) return;
    var act = el.getAttribute("data-act");
    if (act === "back") goBack();
    else if (act === "toggle-edit") { editMode = !editMode; render(false); }
    else if (act === "pick-profile") { if (editMode) nav("editor", { id: el.getAttribute("data-id") }); else choose(el.getAttribute("data-id")); }
    else if (act === "switch") choose(el.getAttribute("data-id"));
    else if (act === "add-profile") nav("editor", { id: null });
    else if (act === "manage") { editMode = true; nav("who", { switching: true }); }
    else if (act === "account") nav("account", { tab: "overview" });
    else if (act === "language") nav("language");
    else if (act === "audiolang") nav("audiolang");
    else if (act === "set-audio") { if (window.PublicDROPAudio) window.PublicDROPAudio.set(el.getAttribute("data-lang")); render(false); toast("Movie language saved"); }
    else if (act === "help") nav("help");
    else if (act === "request") nav("request");
    else if (act === "send-help") submitHelp();
    else if (act === "send-request") submitRequest();
    else if (act === "tab") { top().params.tab = el.getAttribute("data-tab"); render(false); }
    else if (act === "edit-main") nav("editor", { id: "main" });
    else if (act === "change-pass") nav("password");
    else if (act === "save-pass") submitPassword();
    else if (act === "set-lang") { lsSet(LANG_KEY, el.getAttribute("data-lang")); render(false); toast("Language saved"); }
    else if (act === "pick-avatar") { /* handled by the carousel */ }
    else if (act === "save-profile") saveProfile();
    else if (act === "delete-profile") deleteProfile();
    else if (act === "logout") doLogout();
    else if (act === "clear-history") clearHistory();
  }

  /* ---------- wiring ---------- */
  function openMySpace() {
    closeMenu(true);
    if (!user()) { if (auth() && auth().open) auth().open(); return; }
    var d = $("#auth-dialog"); if (d && d.open) d.close();
    if (isOpen()) return;
    editMode = false; openScreen("myspace", {}, true);
  }

  function recovering() { var r = $("#auth-recovery-view"); return Boolean(r && !r.hidden); }

  function maybeGate(u) {
    if (!u || isOpen() || recovering() || chosenOk(u.id)) return;
    var d = $("#auth-dialog"); if (d && d.open) d.close();
    closeMenu(true);
    editMode = false; openScreen("who", {}, false);
  }

  /* ---------- quick profile menu: dropdown on desktop, bottom sheet on phones ---------- */
  var pop = null, popBack = null, menuOpen = false, popTimer = 0;

  function popItem(act, icon, title, sub, cls, n) {
    return '<button type="button" role="menuitem" class="pd-pop-item ' + (cls || "") + '" data-pop="' + act + '" style="--n:' + n + '">' +
      '<span class="pd-pop-ico">' + ico(icon) + '</span><span class="pd-pop-txt"><b>' + title + '</b>' + (sub ? "<small>" + sub + "</small>" : "") + "</span>" + (cls === "is-out" ? "" : ico("chev", "pd-chev")) + "</button>";
  }
  function popHTML() {
    var u = user(), list = getProfiles(u), act = activeProfile(u);
    var chips = list.map(function (p, i) {
      return '<button type="button" role="menuitemradio" aria-checked="' + (p.id === act.id) + '" class="pd-pop-chip' + (p.id === act.id ? " is-active" : "") + '" data-pop="switch" data-id="' + esc(p.id) + '" style="--n:' + i + '" title="' + esc(p.name) + '">' +
        '<span class="pd-pop-chip-ring"><img alt="" src="' + avatarSrc(p.avatar) + '"></span><span>' + esc(p.name) + "</span></button>";
    }).join("");
    if (list.length < MAX_PROFILES) chips += '<button type="button" role="menuitem" class="pd-pop-chip pd-pop-chip-add" data-pop="add" style="--n:' + list.length + '" title="Add profile"><span class="pd-pop-chip-ring">' + ico("plus") + "</span><span>Add</span></button>";
    return '<div class="pd-pop-grab" aria-hidden="true"></div>' +
      '<div class="pd-pop-head"><div class="pd-pop-av"><span class="pd-pop-ring"></span><img alt="" src="' + avatarSrc(act.avatar) + '"><i class="pd-pop-dot"></i></div>' +
      '<div class="pd-pop-id"><strong>' + esc(act.name) + "</strong><span>" + esc(u.email || "") + '</span><em class="pd-pop-sync">Cloud sync on</em></div></div>' +
      '<div class="pd-pop-chips" role="group" aria-label="Profiles">' + chips + "</div>" +
      '<div class="pd-pop-list">' +
      popItem("myspace", "user", "My Space", "Profiles, settings &amp; account", "", 0) +
      popItem("audio", "film", "Movie Language", audioName() + " \u00b7 change", "", 0) +
      popItem("history", "clock", "Watch history", "Pick up where you left off", "", 1) +
      popItem("list", "heart", "My List", "Titles you saved", "", 2) +
      popItem("manage", "edit", "Manage profiles", "Names &amp; avatars", "", 3) +
      popItem("help", "send", "Help &amp; Support", "Contact admin &amp; updates", "", 4) +
      popItem("request", "film", "Request a Movie", "Ask us to add a title", "", 5) +
      "</div>" + popItem("logout", "logout", "Log Out", "", "is-out", 6);
  }
  function placePop() {
    var btn = $("#account-button"); if (!pop || !btn) return;
    var r = btn.getBoundingClientRect();
    pop.style.setProperty("--pop-top", Math.round(r.bottom + 10) + "px");
    pop.style.setProperty("--pop-right", Math.max(10, Math.round(window.innerWidth - r.right - 4)) + "px");
  }
  function openMenu() {
    var u = user(); if (!u || menuOpen) return;
    clearTimeout(popTimer);
    if (pop) { pop.remove(); pop = null; } if (popBack) { popBack.remove(); popBack = null; }
    popBack = document.createElement("div"); popBack.className = "pd-pop-back";
    pop = document.createElement("div"); pop.className = "pd-pop"; pop.id = "pd-pop"; pop.setAttribute("role", "menu"); pop.setAttribute("aria-label", "Profile menu");
    pop.innerHTML = popHTML();
    document.body.appendChild(popBack); document.body.appendChild(pop);
    placePop(); menuOpen = true;
    var btn = $("#account-button"); if (btn) { btn.setAttribute("aria-expanded", "true"); btn.classList.add("is-open"); }
    popBack.addEventListener("click", function () { closeMenu(); });
    pop.addEventListener("click", onPopClick);
    pop.addEventListener("keydown", onPopKey);
    var first = pop.querySelector(".pd-pop-item"); if (first) { try { first.focus({ preventScroll: true }); } catch (e) {} }
  }
  function closeMenu(instant) {
    if (!menuOpen) return;
    menuOpen = false;
    var btn = $("#account-button"), had = pop && pop.contains(document.activeElement);
    if (btn) { btn.setAttribute("aria-expanded", "false"); btn.classList.remove("is-open"); if (had && !instant) { try { btn.focus({ preventScroll: true }); } catch (e) {} } }
    var p = pop, b = popBack; pop = null; popBack = null;
    if (!p) return;
    if (instant) { p.remove(); if (b) b.remove(); return; }
    p.classList.add("is-closing"); if (b) b.classList.add("is-closing");
    popTimer = setTimeout(function () { p.remove(); if (b) b.remove(); }, 170);
  }
  function onPopKey(e) {
    var items = [].slice.call(pop.querySelectorAll(".pd-pop-item,.pd-pop-chip")), i = items.indexOf(document.activeElement);
    if (e.key === "ArrowDown" || e.key === "ArrowRight") { e.preventDefault(); items[(i + 1) % items.length].focus(); }
    else if (e.key === "ArrowUp" || e.key === "ArrowLeft") { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
    else if (e.key === "Home") { e.preventDefault(); items[0].focus(); }
    else if (e.key === "End") { e.preventDefault(); items[items.length - 1].focus(); }
    else if (e.key === "Tab") closeMenu();
  }
  function onPopClick(e) {
    var el = e.target.closest && e.target.closest("[data-pop]"); if (!el) return;
    var act = el.getAttribute("data-pop"), u = user(); if (!u) return;
    if (act === "switch") {
      var id = el.getAttribute("data-id"), p = getProfiles(u).filter(function (x) { return x.id === id; })[0];
      if (!p || p.id === activeProfile(u).id) return closeMenu();
      chosenSet(u.id); setActive(u, p.id);
      pop.innerHTML = popHTML(); pop.classList.add("is-swapped"); toast("Now watching as " + p.name);
      popTimer = setTimeout(function () { closeMenu(); }, 520);
    }
    else if (act === "add") { closeMenu(true); openMySpace(); nav("editor", { id: null }); }
    else if (act === "myspace") openMySpace();
    else if (act === "audio") { openMySpace(); nav("audiolang"); }
    else if (act === "history") { openMySpace(); nav("account", { tab: "history" }); }
    else if (act === "manage") { openMySpace(); editMode = true; nav("who", { switching: true }); }
    else if (act === "list") { closeMenu(true); location.hash = "#/favorites"; }
    else if (act === "help") { openMySpace(); nav("help"); }
    else if (act === "request") { openMySpace(); nav("request"); }
    else if (act === "logout") { closeMenu(true); doLogout(); }
  }
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && menuOpen) { e.preventDefault(); closeMenu(); } });
  window.addEventListener("resize", function () { if (menuOpen) placePop(); });
  window.addEventListener("hashchange", function () { closeMenu(true); });
  window.addEventListener("scroll", function () { if (menuOpen && window.innerWidth > 640) closeMenu(); }, { passive: true });

  /* clicking the profile button opens the quick menu (My Space is one tap away) instead of the small sign-in popup */
  document.addEventListener("click", function (e) {
    var btn = e.target.closest && e.target.closest("#account-button");
    if (!btn || !user()) return;
    e.preventDefault(); e.stopImmediatePropagation();
    if (menuOpen) closeMenu(); else openMenu();
  }, true);

  window.addEventListener("publicdrop:authchange", function (e) {
    var u = e.detail && e.detail.user;
    if (!u) {
      chosenDel(); closeMenu(true);
      if (isOpen()) { hist = false; hide(); }
      return;
    }
    paintTop();
    if (isOpen()) { if (top().view !== "editor") render(false); }
    else maybeGate(u);
  });

  function initial() { var u = user(); if (u) { paintTop(); maybeGate(u); } }
  if (document.readyState === "complete") setTimeout(initial, 400); else window.addEventListener("load", function () { setTimeout(initial, 400); });

  window.PublicDROPProfiles = { open: openMySpace, profiles: function () { var u = user(); return u ? getProfiles(u) : []; } };
})();
