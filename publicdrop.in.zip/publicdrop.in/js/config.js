(function () {
  "use strict";

  const isLocal = ["localhost", "127.0.0.1"].includes(window.location.hostname);
  window.PUBLICDROP_CONFIG = Object.freeze({
    IS_LOCAL: isLocal,
    TMDB_BASE_URL: "https://api.themoviedb.org/3",
    TMDB_FALLBACK_BASE_URLS: ["https://api.tmdb.org/3"],
    TMDB_API_KEY: "16f62d38fec24f4e6c2adc9388da20ce",
    API_RELAY_BASE_URL: `${window.location.origin}/api`,
    ANIMEX_RELAY_BASE_URL: `${window.location.origin}/api`,
    PYTHON_EMBED_BASE_URL: "https://vumeto.xyz",
    VUMETO_EMBED_BASE_URL: "https://vumeto.xyz",
    SERVER_ONE_EMBED_BASE_URL: "https://vidstuck.cc",
    VIDSTUCK_EMBED_BASE_URL: "https://vidstuck.cc",
    // vidstuck "server" name for HD-1 (docs example: "valstrax"). Leave empty to let vidstuck choose.
    VIDSTUCK_SERVER: "",
    // Player look + behaviour (all optional)
    PLAYER_BRANDING: "PublicDROP",
    PLAYER_ACCENT: "e50914",
    PLAYER_SUBTITLE: "english",
    PLAYER_STALL_MS: 25000,
    // true = always use our fullscreen (keeps lock + gestures); false = embed's own fullscreen; default = ours on touch devices only
    // PLAYER_CUSTOM_FULLSCREEN: true,
    PUBLICDROP_TV_ENABLED: false,
    // Keep Vidnest out of the Server 2 provider menu.
    VIDNEST_ENABLED: false,
    SUPABASE_URL: "https://gdpfxkobhyhwbhpaiuqr.supabase.co",
    SUPABASE_PUBLISHABLE_KEY: "sb_publishable_psyNZGl9aZOWpK_n_Ul2HQ_8wbVAsYT",
    IMAGE_BASE_URL: "https://image.tmdb.org/t/p",
    CATALOG_REQUEST_TIMEOUT_MS: 15000,
    DEFAULT_LANGUAGE: "en",
  });
})();
