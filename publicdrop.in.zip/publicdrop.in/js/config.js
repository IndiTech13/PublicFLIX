(function () {
  "use strict";

  const isLocal = ["localhost", "127.0.0.1"].includes(window.location.hostname);

  /* Supabase project + PUBLIC key can be changed from  Admin panel > Database  (no file editing, no re-install).
     The server hands them out at /pd-api/public-config; the last answer is remembered in this browser so the
     very first request of the next visit already uses it. The built-in values below are the safe fallback:
     if the server or the browser storage is unavailable, the site simply keeps working with them. */
  const SB_DEFAULT_URL = "https://zmfiavshwwgayrymnjia.supabase.co";
  const SB_DEFAULT_KEY = "sb_publishable_CESpExVqvoN1q1LzhG-nmA_ng_mgEW1";
  const SB_CACHE = "pd-sb-config";
  const urlOk = (v) => /^https:\/\/[a-z0-9][a-z0-9.-]{2,120}$/i.test(v || "");
  const keyOk = (v) => /^sb_publishable_[A-Za-z0-9_-]{16,200}$/.test(v || "") || /^eyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}$/.test(v || "");
  let cached = {};
  try { cached = JSON.parse(localStorage.getItem(SB_CACHE) || "{}") || {}; } catch (e) { cached = {}; }
  const sbUrl = urlOk(cached.url) ? cached.url : SB_DEFAULT_URL;
  const sbKey = keyOk(cached.key) ? cached.key : SB_DEFAULT_KEY;

  /* Extra TMDB key + key mode can be changed from  Admin panel > API keys.  Same idea as Supabase above:
     the last answer is remembered in this browser; the built-in key below always keeps working as a fallback.
     This object is mutable on purpose, so a change from the server applies at once without a reload. */
  const TMDB_CACHE = "pd-tmdb-config";
  const tmdbKeyOk = (v) => /^[a-f0-9]{32}$/i.test(v || "");
  const TMDB_MODES = ["auto", "main", "extra"];
  let tmdbCached = {};
  try { tmdbCached = JSON.parse(localStorage.getItem(TMDB_CACHE) || "{}") || {}; } catch (e) { tmdbCached = {}; }
  window.PUBLICDROP_TMDB = {
    extraKey: tmdbKeyOk(tmdbCached.key) ? tmdbCached.key : "",
    mode: TMDB_MODES.indexOf(tmdbCached.mode) >= 0 ? tmdbCached.mode : "auto",
  };

  /* Server lists (movies + series  |  anime + cartoons) can be changed from  Admin panel > Servers:
     order, on/off, own url template, auto-switch and the last ping-test result. Same idea as the keys above:
     the last answer is remembered in this browser and the built-in lists in js/player.js are the fallback. */
  const SRV_CACHE = "pd-servers-config";
  const SRV_IDS = ["vidlink", "vidstuck", "superembed", "vumeto", "smashy", "twoembed", "nontongo", "vidfast"];
  const srvClean = (c) => {
    const out = { video: { order: [], off: [] }, anime: { order: [], off: [] }, tpl: {}, health: {}, auto: true };
    if (!c || typeof c !== "object") return out;
    ["video", "anime"].forEach((g) => {
      const x = c[g] || {};
      out[g].order = (Array.isArray(x.order) ? x.order : []).filter((i) => SRV_IDS.indexOf(i) >= 0);
      out[g].off = (Array.isArray(x.off) ? x.off : []).filter((i) => SRV_IDS.indexOf(i) >= 0);
    });
    SRV_IDS.forEach((i) => {
      const t = c.tpl && c.tpl[i];
      if (typeof t === "string" && /^https:\/\/[^\s"'<>]{4,500}$/i.test(t)) out.tpl[i] = t;
      const h = c.health && c.health[i];
      if (h && typeof h === "object") out.health[i] = { ok: h.ok !== false, ms: Number(h.ms) || 0, at: Number(h.at) || 0 };
    });
    out.auto = c.auto !== false;
    return out;
  };
  let srvCached = {};
  try { srvCached = JSON.parse(localStorage.getItem(SRV_CACHE) || "{}") || {}; } catch (e) { srvCached = {}; }
  window.PUBLICDROP_SERVERS = srvClean(srvCached);

  /* Site settings from  Admin panel > Control > Site settings: footer links, default server per language, ad-shield taps.
     Remembered in this browser like the lists above, so a change applies from the visitor's next page load. Anything missing or
     invalid falls back to the built-in value below, so a bad setting can never break the site. */
  const SITE_CACHE = "pd-site-config", BUST_KEY = "pd-bust";
  /* avatar sheets (Admin > Control > Avatar sheets): picture a1-a32 come from one sheet, a33-a64 from another */
  const AV_SETS = { g1: ["emoji3d", "mascots"], g2: ["real", "chibi"] };
  const SITE_LANGS = ["hi", "en", "ta", "te", "ml", "kn", "bn", "mr", "pa"];
  const siteClean = (c) => {
    const out = { telegram_url: "", telegram_username: "", whatsapp_url: "", audio_server: {}, shield_clicks: 1, ad_shield: true, avatar_g1: "emoji3d", avatar_g2: "real" };
    if (!c || typeof c !== "object") return out;
    if (/^https:\/\/[^\s"'<>]{4,290}$/i.test(c.telegram_url || "")) out.telegram_url = c.telegram_url;
    if (/^https:\/\/[^\s"'<>]{4,290}$/i.test(c.whatsapp_url || "")) out.whatsapp_url = c.whatsapp_url;
    if (/^@[A-Za-z0-9_]{3,32}$/.test(c.telegram_username || "")) out.telegram_username = c.telegram_username;
    if (c.audio_server && typeof c.audio_server === "object") SITE_LANGS.forEach((l) => { const n = Number(c.audio_server[l]); if (n >= 1 && n <= 8) out.audio_server[l] = Math.floor(n); });
    const sc = Number(c.shield_clicks); if (sc >= 0 && sc <= 3) out.shield_clicks = Math.floor(sc);
    out.ad_shield = c.ad_shield !== false;
    if (AV_SETS.g1.indexOf(c.avatar_g1) >= 0) out.avatar_g1 = c.avatar_g1;
    if (AV_SETS.g2.indexOf(c.avatar_g2) >= 0) out.avatar_g2 = c.avatar_g2;
    return out;
  };
  let siteCached = {};
  try { siteCached = JSON.parse(localStorage.getItem(SITE_CACHE) || "{}") || {}; } catch (e) { siteCached = {}; }
  const SITE = siteClean(siteCached);


  /* ---- avatars: which sheet each avatar number comes from, and its name ---- */
  const AV_NAMES = {
    mascots: ["Sprout", "Bunny", "Dragon", "Bear", "Astro", "Penguin", "Fox", "Alien", "Panda", "Ninja", "Robot", "Unicorn", "Ghost", "Dino", "Octo", "Frog", "Bunny II", "Sprout II", "Bear II", "Dragon II", "Penguin II", "Astro II", "Alien II", "Fox II", "Ninja II", "Panda II", "Unicorn II", "Robot II", "Dino II", "Ghost II", "Frog II", "Octo II"],
    real: ["Little Hero", "Space Ranger", "Wizard Kid", "Pirate", "Samurai", "Blue Ninja", "Viking", "Knight", "Cowboy Kid", "Princess", "Secret Agent", "Mummy", "Vampire", "Dragon Kid", "Alien", "Sprout Buddy", "Cyber Hacker", "Ice Mage", "Fire Hero", "Cat Thief", "Wolf Hoodie", "Elf Archer", "Rockstar", "Pharaoh", "Gladiator", "Ghost Kid", "Zombie Kid", "Mermaid", "Star Pilot", "Detective", "Robot Knight", "Cyclops"],
    chibi: ["Little Hero", "Space Ranger", "Wizard Kid", "Pirate", "Samurai", "Blue Ninja", "Viking", "Knight", "Cowboy Kid", "Princess", "Secret Agent", "Mummy", "Vampire", "Dragon Kid", "Alien", "Sprout Buddy", "Cyber Hacker", "Ice Mage", "Fire Hero", "Cat Thief", "Wolf Hoodie", "Elf Archer", "Witch", "Pharaoh", "Gladiator", "Ghost Kid", "Zombie Kid", "Mermaid", "Star Pilot", "Detective", "Robot Knight", "Cyclops"]
  };
  window.PublicDROPAvatars = Object.freeze({
    sets: AV_SETS,
    setOf: (id) => { const n = Number(String(id).slice(1)); return n <= 32 ? SITE.avatar_g1 : SITE.avatar_g2; },
    url: (id) => { const s = window.PublicDROPAvatars.setOf(id); return "/assets/avatars/sets/" + s + "/" + id + ".webp?v=14"; },
    name: (id, fallback) => { const n = Number(String(id).slice(1)), s = window.PublicDROPAvatars.setOf(id), l = AV_NAMES[s]; return (l && l[n <= 32 ? n - 1 : n - 33]) || fallback || ""; }
  });

  window.PUBLICDROP_CONFIG = Object.freeze({
    IS_LOCAL: isLocal,
    TMDB_BASE_URL: "https://api.themoviedb.org/3",
    TMDB_FALLBACK_BASE_URLS: ["https://api.tmdb.org/3"],
    TMDB_API_KEY: "16f62d38fec24f4e6c2adc9388da20ce",
    API_RELAY_BASE_URL: `${window.location.origin}/api`,
    ANIMEX_RELAY_BASE_URL: `${window.location.origin}/api`,
    PYTHON_EMBED_BASE_URL: "https://vumeto.xyz",
    VUMETO_EMBED_BASE_URL: "https://vumeto.xyz",
    SERVER_ONE_EMBED_BASE_URL: "https://vidstuck.cc",
    VIDSTUCK_EMBED_BASE_URL: "https://vidstuck.cc",
    VIDLINK_EMBED_BASE_URL: "https://vidlink.pro",
    // SuperEmbed VIP only (directstream.php): multi quality, fast HLS, subtitles, one pop-up at most.
    SUPEREMBED_BASE_URL: "https://multiembed.mov",
    SMASHY_EMBED_BASE_URL: "https://player.smashy.stream",
    // Anime backup by title slug: /embedanime/{anime_name}-episode-{n}  and  /embedanime/{anime_name}-dub-episode-{n}
    TWOEMBED_BASE_URL: "https://www.2embed.skin",
    // NontonGo (nontongo.win) and VidFast (vidfast.vc): movies, series and anime. Order / on-off in Admin > Servers.
    NONTONGO_EMBED_BASE_URL: "https://www.nontongo.win",
    VIDFAST_EMBED_BASE_URL: "https://vidfast.vc",
    // vidstuck "server" name for HD-1 (docs example: "valstrax"). Leave empty to let vidstuck choose.
    VIDSTUCK_SERVER: "",
    // Vumeto native server: auto, aether, nova, orion, kumo or flux (docs: vumeto.xyz/docs). "auto" picks one that works.
    VUMETO_SERVER: "auto",
    // Which server number (1, 2 or 3) opens first for each audio language. Hindi defaults to Server 1.
    // A viewer who switches server while watching is remembered per language and wins over this list.
    // false = list only titles originally made in the chosen language (they play in that language on every server).
    INCLUDE_DUBBED_TITLES: false,
    // South Indian superhits added to the Hindi home page (they are released with Hindi dubs).
    SOUTH_HIT_LANGS: ["ta", "te", "kn"],
    AUDIO_DEFAULT_SERVER: Object.assign({ hi: 1 }, SITE.audio_server),
    // Player look + behaviour (all optional)
    PLAYER_BRANDING: "PublicDROP",
    PLAYER_ACCENT: "e50914",
    PLAYER_SUBTITLE: "english",
    // Ad shield (no sandbox): how many first taps the click-catcher absorbs so pop-up ads cannot start. 0 = shield never covers the video.
    PLAYER_AD_SHIELD: SITE.ad_shield,
    PLAYER_SHIELD_CLICKS: SITE.shield_clicks,
    // true = always use our fullscreen (keeps lock + gestures); false = embed's own fullscreen; default = ours on touch devices only
    // PLAYER_CUSTOM_FULLSCREEN: true,
    PUBLICDROP_TV_ENABLED: false,
    // Keep Vidnest out of the Server 2 provider menu.
    VIDNEST_ENABLED: false,
    SUPABASE_URL: sbUrl,
    SUPABASE_PUBLISHABLE_KEY: sbKey,
    // Links shown in the footer and the Help page. Change them here if they ever move.
    TELEGRAM_URL: SITE.telegram_url || "https://t.me/PublicDROPflix",
    TELEGRAM_USERNAME: SITE.telegram_username || "@PublicDROPflix",
    WHATSAPP_CHANNEL_URL: SITE.whatsapp_url || "https://whatsapp.com/channel/0029Vb9CSbC0bIdvhZbGNS0h",
    IMAGE_BASE_URL: "https://image.tmdb.org/t/p",
    CATALOG_REQUEST_TIMEOUT_MS: 15000,
    // With two TMDB keys: a key that has not answered after this many ms is skipped and the other key is used.
    TMDB_SLOW_MS: 6000,
    DEFAULT_LANGUAGE: "en",
  });

  /* Ask the server for the current Supabase settings. If they differ from what this page started with,
     remember them and reload once (not while a video is playing: it then applies on the next visit). */
  try {
    if (!isLocal && window.fetch) {
      fetch("/pd-api/public-config", { cache: "no-store", credentials: "omit" })
        .then((r) => (r.ok ? r.json() : null))
        .then((c) => {
          if (!c) return;
          if (c.tmdb && typeof c.tmdb === "object") {
            const tk = tmdbKeyOk(c.tmdb.key) ? c.tmdb.key : "";
            const tm = TMDB_MODES.indexOf(c.tmdb.mode) >= 0 ? c.tmdb.mode : "auto";
            window.PUBLICDROP_TMDB.extraKey = tk;
            window.PUBLICDROP_TMDB.mode = tm;
            try { localStorage.setItem(TMDB_CACHE, JSON.stringify({ key: tk, mode: tm })); } catch (e) {}
          }
          if (c.servers && typeof c.servers === "object") {
            const sv = srvClean(c.servers);
            Object.keys(sv).forEach((k) => { window.PUBLICDROP_SERVERS[k] = sv[k]; });
            try { localStorage.setItem(SRV_CACHE, JSON.stringify(sv)); } catch (e) {}
          }
          if (c.site && typeof c.site === "object") { try { localStorage.setItem(SITE_CACHE, JSON.stringify(siteClean(c.site))); } catch (e) {} }
          /* "Clear visitors' saved pages" in Admin: a new number means drop the saved home rows once, the next load fetches them fresh */
          if (typeof c.bust === "number" && c.bust > 0) {
            try {
              if (String(localStorage.getItem(BUST_KEY) || "") !== String(c.bust)) {
                Object.keys(localStorage).filter((k) => k.indexOf("pd-c:") === 0).forEach((k) => localStorage.removeItem(k));
                localStorage.setItem(BUST_KEY, String(c.bust));
              }
            } catch (e) {}
          }
          const url = urlOk(c.url) ? c.url : "";
          const key = keyOk(c.key) ? c.key : "";
          const nextUrl = url || SB_DEFAULT_URL, nextKey = key || SB_DEFAULT_KEY;
          if (!url && !key) { try { localStorage.removeItem(SB_CACHE); } catch (e) {} }
          else { try { localStorage.setItem(SB_CACHE, JSON.stringify({ url: url, key: key })); } catch (e) {} }
          if ((nextUrl !== sbUrl || nextKey !== sbKey) && !/\/watch\//.test(location.hash)) {
            let tried = 0;
            try { tried = Number(sessionStorage.getItem("pd-sb-reload") || 0); sessionStorage.setItem("pd-sb-reload", String(tried + 1)); } catch (e) { tried = 1; }
            if (tried < 1) location.reload();
          }
        })
        .catch(() => {});
    }
  } catch (e) {}
})();
