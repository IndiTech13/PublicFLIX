(function () {
  "use strict";

  const isLocal = ["localhost", "127.0.0.1"].includes(window.location.hostname);

  /* Supabase project + PUBLIC key can be changed from  Admin panel > Database  (no file editing, no re-install).
     The server hands them out at /pd-api/public-config; the last answer is remembered in this browser so the
     very first request of the next visit already uses it. The built-in values below are the safe fallback:
     if the server or the browser storage is unavailable, the site simply keeps working with them. */
  const SB_DEFAULT_URL = "https://zmfiavshwwgayrymnjia.supabase.co";
  const SB_DEFAULT_KEY = "sb_publishable_CESpExVqvoN1q1LzhG-nmA_ng_mgEW1";
  const SB_CACHE = "pd-sb-config";
  const urlOk = (v) => /^https:\/\/[a-z0-9][a-z0-9.-]{2,120}$/i.test(v || "");
  const keyOk = (v) => /^sb_publishable_[A-Za-z0-9_-]{16,200}$/.test(v || "") || /^eyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}$/.test(v || "");
  let cached = {};
  try { cached = JSON.parse(localStorage.getItem(SB_CACHE) || "{}") || {}; } catch (e) { cached = {}; }
  const sbUrl = urlOk(cached.url) ? cached.url : SB_DEFAULT_URL;
  const sbKey = keyOk(cached.key) ? cached.key : SB_DEFAULT_KEY;

  /* Extra TMDB key + key mode can be changed from  Admin panel > API keys.  Same idea as Supabase above:
     the last answer is remembered in this browser; the built-in key below always keeps working as a fallback.
     This object is mutable on purpose, so a change from the server applies at once without a reload. */
  const TMDB_CACHE = "pd-tmdb-config";
  const tmdbKeyOk = (v) => /^[a-f0-9]{32}$/i.test(v || "");
  const TMDB_MODES = ["auto", "main", "extra"];
  let tmdbCached = {};
  try { tmdbCached = JSON.parse(localStorage.getItem(TMDB_CACHE) || "{}") || {}; } catch (e) { tmdbCached = {}; }
  window.PUBLICDROP_TMDB = {
    extraKey: tmdbKeyOk(tmdbCached.key) ? tmdbCached.key : "",
    mode: TMDB_MODES.indexOf(tmdbCached.mode) >= 0 ? tmdbCached.mode : "auto",
  };

  window.PUBLICDROP_CONFIG = Object.freeze({
    IS_LOCAL: isLocal,
    TMDB_BASE_URL: "https://api.themoviedb.org/3",
    TMDB_FALLBACK_BASE_URLS: ["https://api.tmdb.org/3"],
    TMDB_API_KEY: "16f62d38fec24f4e6c2adc9388da20ce",
    API_RELAY_BASE_URL: `${window.location.origin}/api`,
    ANIMEX_RELAY_BASE_URL: `${window.location.origin}/api`,
    PYTHON_EMBED_BASE_URL: "https://vumeto.xyz",
    VUMETO_EMBED_BASE_URL: "https://vumeto.xyz",
    SERVER_ONE_EMBED_BASE_URL: "https://vidstuck.cc",
    VIDSTUCK_EMBED_BASE_URL: "https://vidstuck.cc",
    // vidstuck "server" name for HD-1 (docs example: "valstrax"). Leave empty to let vidstuck choose.
    VIDSTUCK_SERVER: "",
    // Player look + behaviour (all optional)
    PLAYER_BRANDING: "PublicDROP",
    PLAYER_ACCENT: "e50914",
    PLAYER_SUBTITLE: "english",
    PLAYER_STALL_MS: 25000,
    // true = always use our fullscreen (keeps lock + gestures); false = embed's own fullscreen; default = ours on touch devices only
    // PLAYER_CUSTOM_FULLSCREEN: true,
    PUBLICDROP_TV_ENABLED: false,
    // Keep Vidnest out of the Server 2 provider menu.
    VIDNEST_ENABLED: false,
    SUPABASE_URL: sbUrl,
    SUPABASE_PUBLISHABLE_KEY: sbKey,
    // Links shown in the footer and the Help page. Change them here if they ever move.
    TELEGRAM_URL: "https://t.me/PublicDROPflix",
    TELEGRAM_USERNAME: "@PublicDROPflix",
    WHATSAPP_CHANNEL_URL: "https://whatsapp.com/channel/0029Vb9CSbC0bIdvhZbGNS0h",
    IMAGE_BASE_URL: "https://image.tmdb.org/t/p",
    CATALOG_REQUEST_TIMEOUT_MS: 15000,
    // With two TMDB keys: a key that has not answered after this many ms is skipped and the other key is used.
    TMDB_SLOW_MS: 6000,
    DEFAULT_LANGUAGE: "en",
  });

  /* Ask the server for the current Supabase settings. If they differ from what this page started with,
     remember them and reload once (not while a video is playing: it then applies on the next visit). */
  try {
    if (!isLocal && window.fetch) {
      fetch("/pd-api/public-config", { cache: "no-store", credentials: "omit" })
        .then((r) => (r.ok ? r.json() : null))
        .then((c) => {
          if (!c) return;
          if (c.tmdb && typeof c.tmdb === "object") {
            const tk = tmdbKeyOk(c.tmdb.key) ? c.tmdb.key : "";
            const tm = TMDB_MODES.indexOf(c.tmdb.mode) >= 0 ? c.tmdb.mode : "auto";
            window.PUBLICDROP_TMDB.extraKey = tk;
            window.PUBLICDROP_TMDB.mode = tm;
            try { localStorage.setItem(TMDB_CACHE, JSON.stringify({ key: tk, mode: tm })); } catch (e) {}
          }
          const url = urlOk(c.url) ? c.url : "";
          const key = keyOk(c.key) ? c.key : "";
          const nextUrl = url || SB_DEFAULT_URL, nextKey = key || SB_DEFAULT_KEY;
          if (!url && !key) { try { localStorage.removeItem(SB_CACHE); } catch (e) {} }
          else { try { localStorage.setItem(SB_CACHE, JSON.stringify({ url: url, key: key })); } catch (e) {} }
          if ((nextUrl !== sbUrl || nextKey !== sbKey) && !/\/watch\//.test(location.hash)) {
            let tried = 0;
            try { tried = Number(sessionStorage.getItem("pd-sb-reload") || 0); sessionStorage.setItem("pd-sb-reload", String(tried + 1)); } catch (e) { tried = 1; }
            if (tried < 1) location.reload();
          }
        })
        .catch(() => {});
    }
  } catch (e) {}
})();
