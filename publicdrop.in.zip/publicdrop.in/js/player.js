(function () {
  "use strict";
  /*
    PublicDROP player  ·  v6 (no auto-switch, sandbox-free ad shield, own screen modes, NontonGo + VidFast)

    app.js calls PublicDROPStaticPlayer.mount(container, options) and keeps the returned cleanup function.

    Providers
      Server 1  vidstuck.cc   (movies + TV)   https://vidstuck.cc/embed/movie/{tmdb} · /embed/tv/{tmdb}/{s}/{e}
      Server 2  vumeto.xyz    (movies, TV, anime)
      Server 3  vumeto.xyz    server=nova
      Server N  nontongo.win  (movies, TV, anime)
      Server N  vidfast.vc    (movies, TV; anime by TMDB id)
      The server list order and on/off switches come from Admin > Servers. Anime never uses vidstuck (no anime embed URL).
      The player NEVER switches server by itself: only the viewer (Server buttons / key S) changes it.

    Everything the page can do to a cross-origin iframe is done from a layer ABOVE it:
      - Lock screen  : full-cover shield that swallows touches (hold the lock icon to unlock)
      - Brightness   : swipe up/down on the RIGHT edge  (CSS brightness() filter on the iframe)
      - Volume       : swipe up/down on the LEFT edge   (see sendVolume() — needs embed support)
      - Fullscreen   : our own button, so the lock + gestures stay on top of the video
  */
  const config = window.PUBLICDROP_CONFIG || {};
  const trimSlash = value => String(value || "").replace(/\/+$/, "");
  const VUMETO = trimSlash(config.VUMETO_EMBED_BASE_URL || config.PYTHON_EMBED_BASE_URL || "https://vumeto.xyz");
  const VIDSTUCK = trimSlash(config.VIDSTUCK_EMBED_BASE_URL || config.SERVER_ONE_EMBED_BASE_URL || "https://vidstuck.cc");
  const BRAND = String(config.PLAYER_BRANDING || "PublicDROP");
  const ACCENT = String(config.PLAYER_ACCENT || "e50914").replace(/^#/, "");
  const SUBTITLE = String(config.PLAYER_SUBTITLE || "english");

  /* ---------- servers ----------
     Two separate lists (Admin panel > Servers can reorder, switch off, test and re-point them):
       "video"  movies + web series          -> vidlink, vidstuck, vumeto, SuperEmbed VIP
       "anime"  Japanese anime + cartoons    -> vidlink, vumeto, smashy, 2embed (anime backup)
     "signals" = the embed posts progress messages, so "no signal" really means "not playing". */
  const BASE = {
    vidlink: trimSlash(config.VIDLINK_EMBED_BASE_URL || "https://vidlink.pro"),
    vidstuck: VIDSTUCK,
    superembed: trimSlash(config.SUPEREMBED_BASE_URL || "https://multiembed.mov"),
    vumeto: VUMETO,
    smashy: trimSlash(config.SMASHY_EMBED_BASE_URL || "https://player.smashy.stream"),
    twoembed: trimSlash(config.TWOEMBED_BASE_URL || "https://www.2embed.skin"),
    nontongo: trimSlash(config.NONTONGO_EMBED_BASE_URL || "https://www.nontongo.win"),
    vidfast: trimSlash(config.VIDFAST_EMBED_BASE_URL || "https://vidfast.vc"),
  };
  const PROVIDERS = {
    vidlink: { label: "VidLink", groups: ["video", "anime"], signals: true },
    vidstuck: { label: "Vidstuck", groups: ["video"], signals: true },
    superembed: { label: "SuperEmbed VIP", groups: ["video"], signals: false }, /* multiembed.mov/directstream.php answered "File not found" in testing: switched OFF by default, admin can turn it on */
    vumeto: { label: "Vumeto", groups: ["video", "anime"], signals: true },
    smashy: { label: "Smashy", groups: ["anime"], signals: false },
    twoembed: { label: "2Embed Anime", groups: ["anime"], signals: false },
    nontongo: { label: "NontonGo", groups: ["video", "anime"], signals: false },
    vidfast: { label: "VidFast", groups: ["video", "anime"], signals: false },
  };
  const DEFAULT_ORDER = { video: ["vidstuck", "vidlink", "vumeto", "nontongo", "vidfast"], anime: ["vumeto", "vidlink", "nontongo", "vidfast", "smashy", "twoembed"] };
  const adminCfg = () => window.PUBLICDROP_SERVERS || {};
  const groupOf = o => (o && (o.type === "anime" || (o.metadata && o.metadata.isCartoon))) ? "anime" : "video";
  const BRIGHT_MIN = 0.25, BRIGHT_MAX = 1.5;
  const PREF_KEY = "publicdrop_player_prefs";
  const coarse = () => { try { return matchMedia("(pointer: coarse)").matches; } catch { return false; } };
  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

  /* ---------- preferences (brightness / volume / gestures survive episode changes) ---------- */
  /* servers whose own player already has a wide-screen / aspect option: our own button is hidden there.
     Others (VidLink, Vumeto, NontonGo, VidFast ...) get ours. Override in config.js: PLAYER_NATIVE_WIDESCREEN: { vidstuck: true, ... } */
  const NATIVE_WIDE = Object.assign({ vidstuck: true }, config.PLAYER_NATIVE_WIDESCREEN || {});
  const SCREEN_MODES = [
    { id: "fit", label: "Original", sx: 1, sy: 1 },
    { id: "zoom", label: "Zoom", sx: 1.15, sy: 1.15 },
    { id: "fill", label: "Fill screen (removes black bars)", sx: 1.34, sy: 1.34 },
    { id: "wide", label: "Wide stretch (4:3 \u2192 16:9)", sx: 1.34, sy: 1 },
  ];
  const defaults = { brightness: 1, volume: 1, gestures: "auto", hinted: false, shield: config.PLAYER_AD_SHIELD !== false, screen: "fit" };
  let prefs = (() => {
    try { return { ...defaults, ...JSON.parse(localStorage.getItem(PREF_KEY) || "{}") }; } catch { return { ...defaults }; }
  })();
  const savePrefs = () => { try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch {} };
  try {
    if (prefs.shieldOff && !prefs.shieldFix2) {
      Object.keys(prefs.shieldOff).forEach(k => { if (prefs.shieldOff[k] === false) delete prefs.shieldOff[k]; });
      prefs.shieldFix2 = true; savePrefs();
    }
  } catch {}
  /* v6: the sandbox shield is gone, so every per-server "shield off" choice made with the old one is forgotten once */
  try {
    if (!prefs.shieldFix3) { delete prefs.shieldOff; prefs.shield = config.PLAYER_AD_SHIELD !== false; prefs.shieldFix3 = true; savePrefs(); }
  } catch {}
  if (!SCREEN_MODES.some(m => m.id === prefs.screen)) prefs.screen = "fit";
  prefs.brightness = clamp(Number(prefs.brightness) || 1, BRIGHT_MIN, BRIGHT_MAX);
  prefs.volume = clamp(Number.isFinite(Number(prefs.volume)) ? Number(prefs.volume) : 1, 0, 1);

  /* ---------- source url ---------- */
  function resumeSeconds(o, season, episode) {
    const fromApp = Number(o.resume);
    if (Number.isFinite(fromApp) && fromApp > 5) return Math.floor(fromApp);
    try {
      const key = `publicdrop_progress_${o.type}_${o.id}_${o.type === "movie" ? 0 : season}_${o.type === "movie" ? 0 : episode}`;
      const value = Number(localStorage.getItem(key));
      return Number.isFinite(value) && value > 5 ? Math.floor(value) : 0;
    } catch { return 0; }
  }

  const slugify = t => String(t || "").toLowerCase().replace(/['\u2019]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  function idsOf(o) {
    const m = o.metadata || {};
    const anime = o.type === "anime";
    return {
      tmdb: anime ? (o.isTmdb ? Number(o.id) : Number(m.tmdbId)) || 0 : Number(o.id) || 0,
      mal: Number(m.malId) || 0,
      anilist: anime ? (o.isTmdb ? Number(m.anilistId) : Number(m.anilistId || o.id)) || 0 : 0,
      title: m.titleEnglish || m.title || m.titleRomaji || "",
    };
  }
  /* each builder returns the path+query to append to the provider's base url, or null when it cannot play this title */
  const BUILD = {
    vidlink(o, x, s, e) {
      const q = new URLSearchParams({ primaryColor: ACCENT, autoplay: "true" });
      if (o.type === "anime") {
        if (!x.mal) return null;
        const ep = o.isTmdb && o.tmdbType === "movie" ? 1 : e;
        return `/anime/${x.mal}/${ep}/${o.dub === "dub" ? "dub" : "sub"}?fallback=true&${q}`;
      }
      if (!x.tmdb) return null;
      if (o.type === "tv") { q.set("nextbutton", "true"); return `/tv/${x.tmdb}/${s}/${e}?${q}`; }
      return `/movie/${x.tmdb}?${q}`;
    },
    vidstuck(o, x, s, e, start) {
      if (o.type === "anime" || !x.tmdb) return null;
      const path = o.type === "tv" ? `/embed/tv/${x.tmdb}/${s}/${e}` : `/embed/movie/${x.tmdb}`;
      const params = new URLSearchParams({ color: ACCENT, branding: BRAND, subtitle: o.subtitle || SUBTITLE });
      if (config.VIDSTUCK_SERVER) params.set("server", String(config.VIDSTUCK_SERVER));
      if (start) params.set("progress", String(start));
      if (o.type === "tv") { params.set("nextEpisode", "true"); params.set("autoplayNextEpisode", "true"); }
      return `${path}?${params}`;
    },
    nontongo(o, x, s, e) {
      /* documented: /embed/movie/{tmdb} · /embed/tv/{tmdb}/{s}/{e} · anime /anime/{anilist}/{ep}/play or /anime/stream?id={mal}&e={ep}&type=MAL_ID */
      if (o.type === "anime") {
        const ep = o.isTmdb && o.tmdbType === "movie" ? 1 : e;
        if (x.anilist) return `https://nontongo.win/anime/${x.anilist}/${ep}/play`;
        if (x.mal) return `https://nontongo.win/anime/stream?id=${x.mal}&e=${ep}&type=MAL_ID`;
        return null;
      }
      if (!x.tmdb) return null;
      return o.type === "tv" ? `/embed/tv/${x.tmdb}/${s}/${e}` : `/embed/movie/${x.tmdb}`;
    },
    vidfast(o, x, s, e, start) {
      const q = new URLSearchParams({ autoPlay: "true", theme: ACCENT });
      if (start) q.set("startAt", String(start));
      /* docs: /movie/{id} and /tv/{id}/{season}/{episode}; id = IMDB or TMDB. There is no anime route, so anime plays by its TMDB id. */
      if (!x.tmdb) return null;
      const isMovie = o.type === "movie" || (o.type === "anime" && o.isTmdb && o.tmdbType === "movie");
      if (!isMovie) { q.set("nextButton", "true"); q.set("autoNext", "true"); return `/tv/${x.tmdb}/${s}/${e}?${q}`; }
      return `/movie/${x.tmdb}?${q}`;
    },
    superembed(o, x, s, e) {
      /* VIP player only (directstream.php): multi quality, HLS, subtitles. Never the normal ad player. */
      if (o.type === "anime" || !x.tmdb) return null;
      const q = `video_id=${x.tmdb}&tmdb=1`;
      return o.type === "tv" ? `/directstream.php?${q}&s=${s}&e=${e}` : `/directstream.php?${q}`;
    },
    vumeto(o, x, s, e, start) {
      const params = new URLSearchParams({ autoplay: "1", muted: "0", autonext: "1", server: String(config.VUMETO_SERVER || "auto") });
      let path;
      if (o.type === "anime") {
        path = `/embed/anime/${o.isTmdb ? "tmdb" : "anilist"}/${encodeURIComponent(String(o.id))}/${o.isTmdb && o.tmdbType === "movie" ? 1 : e}`;
        if (o.isTmdb) { if (o.tmdbType === "movie") params.set("format", "movie"); else params.set("season", String(s)); }
        params.set("dub", o.dub === "dub" ? "dub" : "sub");
      } else {
        if (!x.tmdb) return null;
        path = o.type === "tv" ? `/embed/tv/${x.tmdb}/${s}/${e}` : `/embed/movie/${x.tmdb}`;
        if (start) params.set("start", String(start));
      }
      try { params.set("parentOrigin", location.origin); } catch {}
      return `${path}?${params}`;
    },
    smashy(o, x, s, e) {
      if (!x.tmdb) return null;
      const tv = o.type === "tv" || (o.type === "anime" && !(o.isTmdb && o.tmdbType === "movie"));
      return tv ? `/tv/${x.tmdb}?s=${s}&e=${e}` : `/movie/${x.tmdb}`;
    },
    twoembed(o, x, s, e) {
      /* title-slug bridge (Gogoanime/HiAnime). Anime only. */
      if (o.type !== "anime") return null;
      const slug = slugify(x.title);
      if (!slug) return null;
      const ep = o.isTmdb && o.tmdbType === "movie" ? 1 : e;
      return `/embedanime/${slug}${o.dub === "dub" ? "-dub" : ""}-episode-${ep}`;
    },
  };
  /* Admin > Servers > Custom addresses. Two ways to use it:
       1) just a new domain, e.g. https://newhost.example   -> the built-in paths are kept, only the host changes
       2) a full template, e.g. https://x.example/embed/{tmdb}[?s={season}&e={episode}]
          placeholders: {tmdb} {mal} {anilist} {slug} {season} {episode} {dub} {type}
          [ ... ] is only used for series/episodes and is dropped for movies */
  function fillTemplate(tpl, vals, isTv) {
    let bad = false;
    const flat = String(tpl).replace(/\[([^\]]*)\]/g, (m, inner) => (isTv ? inner : ""));
    const url = flat.replace(/\{(\w+)\}/g, (m, k) => {
      const v = vals[k];
      if (v === undefined || v === "" || v === 0) { bad = true; return ""; }
      return encodeURIComponent(String(v));
    });
    return bad ? null : url;
  }
  function buildFor(id, o) {
    if (!BUILD[id]) return null;
    const s = Math.max(1, Number(o.season) || 1), e = Math.max(1, Number(o.episode) || 1);
    const x = idsOf(o);
    let url = null, path;
    const tpl = (adminCfg().tpl || {})[id];
    if (tpl && /^https:\/\//i.test(tpl) && tpl.indexOf("{") >= 0) {
      const isTv = o.type === "tv" || (o.type === "anime" && !(o.isTmdb && o.tmdbType === "movie"));
      url = fillTemplate(tpl, { tmdb: x.tmdb, mal: x.mal, anilist: x.anilist, slug: slugify(x.title), season: s, episode: e, dub: o.dub === "dub" ? "dub" : "sub", type: o.type === "tv" ? "tv" : "movie" }, isTv);
    } else {
      path = BUILD[id](o, x, s, e, resumeSeconds(o, s, e));
      if (path && /^https:\/\//i.test(path)) {
        /* a builder may return a full address (NontonGo anime lives on another host); an admin domain override swaps only the host */
        if (tpl && /^https:\/\//i.test(tpl)) { try { const u = new URL(path); path = u.pathname + u.search; } catch { path = null; } url = path ? trimSlash(tpl) + path : null; }
        else url = path;
      } else url = path ? (tpl && /^https:\/\//i.test(tpl) ? trimSlash(tpl) : BASE[id]) + path : null;
    }
    if (!url) return null;
    try { return { url, origin: new URL(url).origin, provider: id }; } catch { return null; }
  }
  /* the servers that can play this title, in the admin's order (switched-off ones left out) */
  function list(o) {
    const g = groupOf(o), adm = adminCfg()[g] || {}, off = new Set(adm.off || []);
    const own = id => PROVIDERS[id] && PROVIDERS[id].groups.includes(g);
    const order = [...(adm.order || []).filter(own), ...DEFAULT_ORDER[g]].filter((id, i, a) => a.indexOf(id) === i);
    /* a server the admin switched off is never listed, never auto-switched to, never loaded */
    const out = order.filter(id => !off.has(id) && buildFor(id, o));
    return out.map(id => ({ id, label: PROVIDERS[id].label }));
  }

  /* ---------- health: admin ping test (server side) + what this visitor's browser saw ---------- */
  const BAD_KEY = "pd-srv-bad";
  const readBad = () => { try { return JSON.parse(sessionStorage.getItem(BAD_KEY) || "{}") || {}; } catch { return {}; } };
  function healthy(id) {
    const h = (adminCfg().health || {})[id];
    if (h && h.ok === false && (Date.now() / 1000 - (Number(h.at) || 0)) < 43200) return false;
    const t = readBad()[id];
    return !(t && Date.now() - t < 300000);
  }
  /* which server to open first: the viewer's saved one (always, even if the last ping failed), otherwise the first one that is up.
     Nothing here ever moves a viewer off the server they chose. */
  function pick(o, preferred) {
    const l = list(o);
    const pref = l.find(p => p.id === preferred);
    if (pref) return pref;
    return (adminCfg().auto === false ? l[0] : l.find(p => healthy(p.id)) || l[0]) || null;
  }
  /* "did the server answer at all?" from the visitor's own browser (a network error = the host is down or blocked) */
  function probe(id) {
    return new Promise(resolve => {
      const base = BASE[id];
      if (!base || !window.fetch) return resolve(true);
      const ctl = window.AbortController ? new AbortController() : null;
      const timer = setTimeout(() => { if (ctl) ctl.abort(); resolve(false); }, 6000);
      fetch(base, { mode: "no-cors", cache: "no-store", signal: ctl ? ctl.signal : undefined })
        .then(() => { clearTimeout(timer); resolve(true); }, () => { clearTimeout(timer); resolve(false); });
    });
  }

  function buildSource(o) {
    const l = list(o);
    let want = String(o.playbackServer || "");
    if (/^\d+$/.test(want)) want = (l[Number(want) - 1] || {}).id || "";
    let id = (l.find(p => p.id === want) || l[0] || {}).id;
    if (!id) return { url: "about:blank", origin: "null", provider: "none" };
    return buildFor(id, o) || { url: "about:blank", origin: "null", provider: id };
  }

  /* ---------- styles (injected once so no extra css file is needed) ---------- */
  function injectStyles() {
    if (document.getElementById("pd-player-css")) return;
    const style = document.createElement("style");
    style.id = "pd-player-css";
    style.textContent = `
.pd-player{--pd-accent:#${ACCENT};position:absolute;inset:0;overflow:hidden;background:#000;-webkit-tap-highlight-color:transparent;font-family:"DM Sans",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.pd-frame{position:absolute;inset:0;width:100%;height:100%;border:0;display:block;background:#000;transition:filter .1s linear,transform .18s ease;transform-origin:50% 50%;will-change:transform}
.pd-trap{position:absolute;inset:0;z-index:2;background:transparent;cursor:pointer;touch-action:manipulation;-webkit-tap-highlight-color:transparent}
.pd-trap[hidden]{display:none}
.pd-zone{position:absolute;top:16%;bottom:24%;width:28%;z-index:4;display:none;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}
.pd-zone-left{left:0}.pd-zone-right{right:0}
.pd-player.pd-gestures .pd-zone{display:block}
.pd-hud{position:absolute;z-index:7;left:50%;top:13%;transform:translate(-50%,-6px);display:flex;align-items:center;gap:10px;padding:10px 16px 10px 12px;border-radius:999px;background:rgba(10,10,14,.8);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);color:#fff;font-weight:600;font-size:13px;line-height:1;opacity:0;pointer-events:none;transition:opacity .18s ease,transform .18s ease}
.pd-hud.is-on{opacity:1;transform:translate(-50%,0)}
.pd-hud svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:none}
.pd-hud-bar{width:104px;height:4px;border-radius:2px;background:rgba(255,255,255,.24);overflow:hidden}
.pd-hud-fill{display:block;height:100%;width:50%;background:var(--pd-accent)}
.pd-hud-val{min-width:36px;text-align:right;font-variant-numeric:tabular-nums}
.pd-controls{position:absolute;z-index:8;top:calc(10px + env(safe-area-inset-top,0px));right:calc(10px + env(safe-area-inset-right,0px));display:flex;gap:8px;opacity:.55;transition:opacity .2s ease}
.pd-controls:hover,.pd-controls:focus-within,.pd-controls.is-awake{opacity:1}
.pd-btn{display:grid;place-items:center;width:40px;height:40px;padding:0;margin:0;border:1px solid rgba(255,255,255,.16);border-radius:12px;background:rgba(10,10,14,.66);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:#fff;cursor:pointer;touch-action:manipulation}
.pd-btn svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.pd-btn[aria-pressed="true"]{background:var(--pd-accent);border-color:transparent}
.pd-btn:focus-visible,.pd-banner button:focus-visible,.pd-unlock:focus-visible{outline:2px solid #fff;outline-offset:2px}
@media (pointer:coarse){.pd-btn{width:44px;height:44px}}
.pd-shield{position:absolute;inset:0;z-index:9;display:none;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}
.pd-player.is-locked .pd-shield{display:block}
.pd-player.is-locked .pd-controls,.pd-player.is-locked .pd-zone,.pd-player.is-locked .pd-banner{display:none}
.pd-unlock{position:absolute;left:calc(18px + env(safe-area-inset-left,0px));top:50%;width:60px;height:60px;padding:0;border:0;border-radius:50%;display:grid;place-items:center;background:rgba(10,10,14,.82);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:#fff;cursor:pointer;opacity:0;pointer-events:none;transform:translateY(-50%) scale(.9);transition:opacity .2s ease,transform .2s ease;touch-action:none}
.pd-shield.is-awake .pd-unlock{opacity:1;pointer-events:auto;transform:translateY(-50%) scale(1)}
.pd-unlock svg.pd-ico{position:relative;width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.pd-unlock svg.pd-ring{position:absolute;inset:0;width:100%;height:100%;transform:rotate(-90deg);fill:none;stroke:var(--pd-accent);stroke-width:3;stroke-dasharray:176;stroke-dashoffset:176}
.pd-unlock.is-holding svg.pd-ring{animation:pd-hold .7s linear forwards}
@keyframes pd-hold{to{stroke-dashoffset:0}}
.pd-shield-note{position:absolute;left:calc(90px + env(safe-area-inset-left,0px));top:50%;transform:translateY(-50%);max-width:calc(100% - 120px);color:#fff;font-size:13px;line-height:1.35;padding:8px 12px;border-radius:10px;background:rgba(10,10,14,.78);opacity:0;pointer-events:none;transition:opacity .2s ease}
.pd-shield.is-awake .pd-shield-note{opacity:1}
.pd-banner{position:absolute;z-index:8;left:calc(10px + env(safe-area-inset-left,0px));top:calc(10px + env(safe-area-inset-top,0px));max-width:calc(100% - 190px);display:flex;align-items:center;gap:8px;padding:8px 8px 8px 14px;border-radius:14px;background:rgba(10,10,14,.9);color:#fff;font-size:13px;line-height:1.3}
.pd-banner[hidden]{display:none}
.pd-banner button{flex:none;min-height:32px;padding:0 12px;border:0;border-radius:9px;background:rgba(255,255,255,.12);color:#fff;font:600 13px/1 inherit;cursor:pointer;touch-action:manipulation}
.pd-banner button.pd-primary{background:var(--pd-accent)}
.pd-pseudo-fs{position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;height:100dvh!important;max-width:none!important;margin:0!important;border:0!important;border-radius:0!important;aspect-ratio:auto!important;z-index:2147483000!important}
html.pd-no-scroll,html.pd-no-scroll body{overflow:hidden!important;overscroll-behavior:none}
.pd-loader{position:absolute;inset:0;z-index:3;display:grid;place-items:center;align-content:center;gap:16px;background:radial-gradient(circle at 50% 42%,rgba(255,255,255,.06),transparent 55%),#000;transition:opacity .5s ease,visibility .5s;pointer-events:none}
.pd-loader.is-done{opacity:0;visibility:hidden}
.pd-loader img{width:58px;height:58px;border-radius:16px;animation:pd-pulse 1.6s ease-in-out infinite}
.pd-loader i{width:128px;height:3px;border-radius:2px;background:rgba(255,255,255,.14);overflow:hidden;position:relative}
.pd-loader i::after{content:"";position:absolute;inset:0;width:40%;background:var(--pd-accent);border-radius:2px;animation:pd-slide 1.1s cubic-bezier(.4,0,.2,1) infinite}
@keyframes pd-pulse{0%,100%{transform:scale(1);opacity:.9}50%{transform:scale(1.06);opacity:1}}
@keyframes pd-slide{from{transform:translateX(-110%)}to{transform:translateX(260%)}}
.pd-btn{transition:background-color .2s,transform .15s,opacity .2s}.pd-btn:active{transform:scale(.92)}.pd-btn:hover{background:rgba(30,30,36,.85)}
@media (max-width:640px){.pd-controls{gap:6px}.pd-btn{width:38px;height:38px;border-radius:11px}.pd-banner{top:calc(58px + env(safe-area-inset-top,0px));right:calc(10px + env(safe-area-inset-right,0px));max-width:none}}
@media (prefers-reduced-motion:reduce){.pd-loader,.pd-loader img,.pd-loader i::after{animation:none;transition:none}}
@media (prefers-reduced-motion:reduce){.pd-hud,.pd-controls,.pd-unlock,.pd-shield-note,.pd-frame{transition:none}.pd-unlock.is-holding svg.pd-ring{animation-duration:.01s}}
`;
    document.head.append(style);
  }

  /* ---------- icons ---------- */
  const ICON = {
    lock: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
    unlock: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.4-2"/></svg>',
    enterFs: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
    exitFs: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>',
    gestures: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4v16M12 4v16M19 4v16"/><circle cx="5" cy="14" r="2"/><circle cx="12" cy="8" r="2"/><circle cx="19" cy="15" r="2"/></svg>',
    sun: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    volume: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/></svg>',
    prev: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5v14M19 5l-9 7 9 7z"/></svg>',
    next: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 5v14M5 5l9 7-9 7z"/></svg>',
    reload: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
    shield: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path d="M9 12l2 2 4-4"/></svg>',
    screen: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10l-2 2 2 2M17 10l2 2-2 2"/></svg>',
    mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/></svg>',
  };
  const el = (tag, className, html) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html) node.innerHTML = html;
    return node;
  };

  /* ---------- fullscreen helpers (shared) ---------- */
  const fsListeners = new Set();
  const nativeFsElement = () => document.fullscreenElement || document.webkitFullscreenElement || null;
  ["fullscreenchange", "webkitfullscreenchange"].forEach(name => document.addEventListener(name, () => fsListeners.forEach(fn => fn())));
  window.addEventListener("hashchange", () => setTimeout(() => {
    if (document.querySelector(".pd-player")) return;
    document.documentElement.classList.remove("pd-no-scroll");
    if (nativeFsElement()) (document.exitFullscreen || document.webkitExitFullscreen)?.call(document);
    try { screen.orientation?.unlock?.(); } catch {}
  }, 0));

  /* ---------- mount ---------- */
  function mount(container, rawOptions) {
    injectStyles();
    const options = rawOptions || {};
    const src = buildSource(options);
    const isTv = options.type === "tv";
    const touch = coarse();
    // On phones the embed's own fullscreen button would hide our lock + gestures, so we own fullscreen there.
    const customFs = config.PLAYER_CUSTOM_FULLSCREEN === true || (config.PLAYER_CUSTOM_FULLSCREEN !== false && touch);
    const target = container.closest(".watch-shell") || container;
    /* lastT/lastWall/acc: seconds that were REALLY played since the last report (a seek or resume jump is never counted) */
    const cur = { season: Math.max(1, Number(options.season) || 1), episode: Math.max(1, Number(options.episode) || 1), ratio: 0, signal: false, lastReport: 0, lastT: null, lastWall: 0, acc: 0 };
    let dead = false, hudTimer = 0, awakeTimer = 0, holdTimer = 0, ctlTimer = 0, reloadTimer = 0, wakeLock = null, trapLeft = 0;

    /* DOM */
    const wrapper = el("div", "pd-player");
    const frame = document.createElement("iframe");
    frame.className = "pd-frame";
    frame.title = `PublicDROP video player · ${(PROVIDERS[src.provider] || {}).label || "Server"}`;
    frame.allow = customFs ? "autoplay; encrypted-media; picture-in-picture" : "autoplay; fullscreen; encrypted-media; picture-in-picture";
    frame.allowFullscreen = !customFs;
    frame.referrerPolicy = "strict-origin-when-cross-origin";
    /* Ad shield (v6) - NO sandbox attribute any more, so no embed can ever say "Sandbox Detected".
       Cross-origin embeds cannot be filtered from our page (only the browser itself, like Brave Shields, can do that), so the shield
       works from above the frame instead: a transparent click-catcher swallows the first tap/click, which is the one that pop-up
       and redirect scripts hook into, then steps aside so playback, quality, subtitles and fullscreen work normally.
       Toggle with the shield button (or key A); the choice is remembered per server. */
    const shieldKey = src.provider;
    const TRAP_CLICKS = Number.isFinite(Number(config.PLAYER_SHIELD_CLICKS)) && config.PLAYER_SHIELD_CLICKS !== "" && config.PLAYER_SHIELD_CLICKS != null ? Math.max(0, Number(config.PLAYER_SHIELD_CLICKS)) : 1;
    const shieldOn = () => {
      if (prefs.shield === false) return false;
      return !(prefs.shieldOff && prefs.shieldOff[shieldKey]);
    };
    try {
      list(options).forEach(({ id }) => {
        const origin = BASE[id];
        if (!origin || document.querySelector(`link[rel="preconnect"][href="${origin}"]`)) return;
        const l = document.createElement("link"); l.rel = "preconnect"; l.href = origin; l.crossOrigin = ""; document.head.append(l);
      });
    } catch {}

    const zoneLeft = el("div", "pd-zone pd-zone-left");
    const zoneRight = el("div", "pd-zone pd-zone-right");
    zoneLeft.dataset.zone = "volume";
    zoneRight.dataset.zone = "brightness";

    const hud = el("div", "pd-hud");
    hud.setAttribute("role", "status");
    hud.setAttribute("aria-live", "polite");
    const hudIcon = el("span");
    const hudBar = el("span", "pd-hud-bar", '<span class="pd-hud-fill"></span>');
    const hudFill = hudBar.firstChild;
    const hudVal = el("span", "pd-hud-val");
    hud.append(hudIcon, hudBar, hudVal);

    const controls = el("div", "pd-controls");
    const btn = (label, html) => { const b = el("button", "pd-btn", html); b.type = "button"; b.setAttribute("aria-label", label); b.title = label; return b; };
    const gestureBtn = btn("Swipe gestures", ICON.gestures);
    const lockBtn = btn("Lock screen", ICON.lock);
    const fsBtn = btn("Fullscreen", ICON.enterFs);
    const hasEps = options.type === "tv" || options.type === "anime";
    const prevBtn = btn("Previous episode (P)", ICON.prev), nextBtn = btn("Next episode (N)", ICON.next);
    const reloadBtn = btn("Reload video (R)", ICON.reload);
    const shieldBtn = btn("Ad shield (A)", ICON.shield);
    const screenBtn = btn("Screen size (W)", ICON.screen);
    controls.append(...(hasEps ? [prevBtn, nextBtn] : []), reloadBtn, shieldBtn, screenBtn, gestureBtn, lockBtn, fsBtn);
    lockBtn.title = "Lock screen (L)"; gestureBtn.title = "Swipe gestures (G)"; fsBtn.title = "Fullscreen (F)";
    const loader = el("div", "pd-loader", '<img src="/assets/publicdrop-favicon.png" alt="" width="58" height="58"><i></i>');

    const banner = el("div", "pd-banner");
    banner.hidden = true;

    const shield = el("div", "pd-shield");
    const unlockBtn = el("button", "pd-unlock", `${ICON.unlock.replace("<svg ", '<svg class="pd-ico" ')}<svg class="pd-ring" viewBox="0 0 60 60" aria-hidden="true"><circle cx="30" cy="30" r="28"/></svg>`);
    unlockBtn.type = "button";
    unlockBtn.setAttribute("aria-label", "Hold to unlock screen");
    const shieldNote = el("div", "pd-shield-note", "Screen locked.<br>Hold the lock to unlock.");
    shield.append(shieldNote, unlockBtn);

    const trap = el("div", "pd-trap");
    trap.hidden = true;
    wrapper.append(frame, trap, loader, zoneLeft, zoneRight, hud, controls, banner, shield);
    container.replaceChildren(wrapper);
    frame.src = src.url;

    const nativeWide = !!NATIVE_WIDE[src.provider];
    /* state sync */
    const isFs = () => nativeFsElement() === target || target.classList.contains("pd-pseudo-fs");
    const isLocked = () => target.dataset.pdLocked === "1";
    const gesturesOn = () => prefs.gestures === "on" || (prefs.gestures === "auto" && touch && isFs());
    function sync() {
      if (dead) return;
      const fs = isFs(), locked = isLocked(), gestures = gesturesOn();
      wrapper.classList.toggle("is-locked", locked);
      wrapper.classList.toggle("pd-gestures", gestures && !locked);
      gestureBtn.setAttribute("aria-pressed", String(gestures));
      fsBtn.innerHTML = fs ? ICON.exitFs : ICON.enterFs;
      fsBtn.setAttribute("aria-label", fs ? "Exit fullscreen" : "Fullscreen");
      fsBtn.title = fsBtn.getAttribute("aria-label") + " (F)";
      lockBtn.setAttribute("aria-pressed", String(locked));
      shieldBtn.setAttribute("aria-pressed", String(shieldOn()));
      shieldBtn.title = shieldOn() ? "Ad shield is ON (A)" : "Ad shield is OFF (A)";
      const mode = screenMode();
      screenBtn.setAttribute("aria-pressed", String(!nativeWide && mode.id !== "fit"));
      screenBtn.title = "Screen: " + mode.label + " (W)";
    }
    fsListeners.add(sync);
    /* fullscreen left with Esc / the system back gesture: give back the screen lock, wake lock and scroll */
    const onFsExit = () => {
      if (dead || isFs()) return;
      document.documentElement.classList.remove("pd-no-scroll");
      try { screen.orientation?.unlock?.(); } catch {}
      if (wakeLock) { try { wakeLock.release(); } catch {} wakeLock = null; }
    };
    fsListeners.add(onFsExit);

    /* brightness + volume */
    function applyBrightness() { frame.style.filter = Math.abs(prefs.brightness - 1) < 0.01 ? "" : `brightness(${prefs.brightness.toFixed(2)})`; }
    function showHud(kind, level, percentText) {
      hudIcon.innerHTML = kind === "brightness" ? ICON.sun : (prefs.volume <= 0.001 ? ICON.mute : ICON.volume);
      hudFill.style.width = `${Math.round(level * 100)}%`;
      hudVal.textContent = percentText;
      hud.classList.add("is-on");
      clearTimeout(hudTimer);
      hudTimer = setTimeout(() => hud.classList.remove("is-on"), 900);
    }
    function setBrightness(value) {
      prefs.brightness = clamp(value, BRIGHT_MIN, BRIGHT_MAX);
      applyBrightness();
      showHud("brightness", (prefs.brightness - BRIGHT_MIN) / (BRIGHT_MAX - BRIGHT_MIN), `${Math.round(prefs.brightness * 100)}%`);
    }
    /*
      Volume: a page cannot read or change the audio of a cross-origin iframe. This sends a best-effort
      postMessage; it only has an effect if the embed implements it. To use a different message format set
      PUBLICDROP_CONFIG.PLAYER_VOLUME_MESSAGE = volume01 => ({ ... }) in js/config.js.
    */
    function sendVolume(value) {
      const win = frame.contentWindow;
      if (!win) return;
      const custom = typeof config.PLAYER_VOLUME_MESSAGE === "function" ? config.PLAYER_VOLUME_MESSAGE : null;
      const messages = custom ? [custom(value)] : [{ type: "setVolume", volume: value }, { type: "volume", volume: value }];
      messages.filter(Boolean).forEach(message => {
        try { win.postMessage(message, src.origin); win.postMessage(JSON.stringify(message), src.origin); } catch {}
      });
    }
    function setVolume(value) {
      prefs.volume = clamp(value, 0, 1);
      sendVolume(prefs.volume);
      showHud("volume", prefs.volume, `${Math.round(prefs.volume * 100)}%`);
    }
    applyBrightness();
    /* our own screen size: works on every server (the embed's own wide-screen button only exists on some). Scales the frame from the centre. */
    function screenMode() { return SCREEN_MODES.find(m => m.id === prefs.screen) || SCREEN_MODES[0]; }
    screenBtn.hidden = nativeWide;
    function applyScreen() {
      const m = screenMode();
      frame.style.transform = nativeWide || m.id === "fit" ? "" : `scale(${m.sx}, ${m.sy})`;
    }
    function cycleScreen() {
      if (nativeWide) return;
      const i = SCREEN_MODES.findIndex(m => m.id === prefs.screen);
      prefs.screen = SCREEN_MODES[(i + 1) % SCREEN_MODES.length].id;
      savePrefs(); applyScreen(); sync();
      showBanner("Screen: " + screenMode().label + (prefs.screen === "fit" ? "" : " \u2014 the edges of the video player may be cropped; tap again to cycle."), [], 3200);
    }
    applyScreen();
    /* shield click-catcher */
    function armTrap() {
      trapLeft = shieldOn() ? TRAP_CLICKS : 0;
      trap.hidden = trapLeft <= 0;
    }
    trap.addEventListener("click", event => {
      event.preventDefault(); event.stopPropagation();
      trapLeft -= 1;
      if (trapLeft <= 0) trap.hidden = true;
      showBanner("Ad click blocked \u2014 tap again to use the player.", [], 1800);
    });
    armTrap();
    let loaderTimer = 0;
    const hideLoader = () => { clearTimeout(loaderTimer); loader.classList.add("is-done"); };
    const showLoader = () => { loader.classList.remove("is-done"); clearTimeout(loaderTimer); loaderTimer = setTimeout(hideLoader, 15000); };
    showLoader();
    frame.addEventListener("load", () => { if (frame.src && frame.src !== "about:blank" && !/^about:/.test(frame.src)) setTimeout(hideLoader, 350); if (prefs.volume < 1) sendVolume(prefs.volume); });

    /* swipe zones */
    function bindZone(zone, kind) {
      let active = null;
      zone.addEventListener("pointerdown", event => {
        if (isLocked() || !gesturesOn()) return;
        try { zone.setPointerCapture(event.pointerId); } catch {}
        active = { id: event.pointerId, y: event.clientY, start: kind === "volume" ? prefs.volume : prefs.brightness, moved: false };
      });
      zone.addEventListener("pointermove", event => {
        if (!active || event.pointerId !== active.id) return;
        const dy = active.y - event.clientY;
        if (!active.moved && Math.abs(dy) < 8) return;
        active.moved = true;
        event.preventDefault();
        const height = wrapper.getBoundingClientRect().height || 1;
        const span = kind === "volume" ? 1 : BRIGHT_MAX - BRIGHT_MIN;
        const next = active.start + (dy / (height * 0.7)) * span;
        if (kind === "volume") setVolume(next); else setBrightness(next);
      });
      const end = event => {
        if (!active || event.pointerId !== active.id) return;
        if (active.moved) savePrefs();
        active = null;
      };
      zone.addEventListener("pointerup", end);
      zone.addEventListener("pointercancel", end);
      zone.addEventListener("contextmenu", event => event.preventDefault());
      zone.addEventListener("wheel", event => {
        if (isLocked() || !gesturesOn()) return;
        event.preventDefault();
        const step = -Math.sign(event.deltaY) * (kind === "volume" ? 0.05 : 0.06);
        if (kind === "volume") setVolume(prefs.volume + step); else setBrightness(prefs.brightness + step);
        savePrefs();
      }, { passive: false });
    }
    bindZone(zoneLeft, "volume");
    bindZone(zoneRight, "brightness");

    /* lock */
    const buzz = ms => { try { navigator.vibrate?.(ms); } catch {} };
    function wakeShield() {
      shield.classList.add("is-awake");
      clearTimeout(awakeTimer);
      awakeTimer = setTimeout(() => shield.classList.remove("is-awake"), 3000);
    }
    function setLocked(value) {
      if (value) target.dataset.pdLocked = "1"; else delete target.dataset.pdLocked;
      sync();
      buzz(value ? 20 : [12, 40, 12]);
      if (value) wakeShield(); else { shield.classList.remove("is-awake"); unlockBtn.classList.remove("is-holding"); }
    }
    lockBtn.addEventListener("click", () => setLocked(true));
    shield.addEventListener("pointerdown", wakeShield);
    shield.addEventListener("contextmenu", event => event.preventDefault());
    shield.addEventListener("touchmove", event => event.preventDefault(), { passive: false });
    unlockBtn.addEventListener("pointerdown", event => {
      event.stopPropagation();
      wakeShield();
      unlockBtn.classList.add("is-holding");
      clearTimeout(holdTimer);
      holdTimer = setTimeout(() => setLocked(false), 700);
    });
    ["pointerup", "pointercancel", "pointerleave"].forEach(name => unlockBtn.addEventListener(name, () => {
      clearTimeout(holdTimer);
      unlockBtn.classList.remove("is-holding");
    }));
    unlockBtn.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); setLocked(false); } });

    /* gestures toggle + fullscreen */
    gestureBtn.addEventListener("click", () => {
      prefs.gestures = gesturesOn() ? "off" : "on";
      savePrefs();
      sync();
      showBanner(prefs.gestures === "on"
        ? "Swipe the left edge for volume, the right edge for brightness."
        : "Swipe gestures off.", [], 2600);
    });
    async function keepAwake(on) {
      try {
        if (on && navigator.wakeLock && !wakeLock) {
          wakeLock = await navigator.wakeLock.request("screen");
          wakeLock.addEventListener("release", () => { wakeLock = null; });
        } else if (!on && wakeLock) { await wakeLock.release(); wakeLock = null; }
      } catch {}
    }
    async function enterFs() {
      const request = target.requestFullscreen || target.webkitRequestFullscreen;
      if (request) {
        try {
          await request.call(target);
          try { await screen.orientation?.lock?.("landscape"); } catch {}
          keepAwake(true);
          sync();
          return;
        } catch {}
      }
      // iPhone Safari (no element fullscreen): fill the viewport instead.
      target.classList.add("pd-pseudo-fs");
      document.documentElement.classList.add("pd-no-scroll");
      keepAwake(true);
      sync();
    }
    async function exitFs() {
      if (nativeFsElement()) { try { await (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch {} }
      target.classList.remove("pd-pseudo-fs");
      document.documentElement.classList.remove("pd-no-scroll");
      try { screen.orientation?.unlock?.(); } catch {}
      keepAwake(false);
      sync();
    }
    fsBtn.addEventListener("click", () => { if (isFs()) exitFs(); else enterFs(); });
    function stepEpisode(dir) {
      const links = [...document.querySelectorAll("#watch-navigator-footer a")];
      const link = links.find(a => new RegExp(dir < 0 ? "Previous" : "Next", "i").test(a.textContent));
      if (link) link.click(); else showBanner(dir < 0 ? "This is the first episode." : "No next episode available.", [], 2200);
    }
    prevBtn.addEventListener("click", () => stepEpisode(-1));
    nextBtn.addEventListener("click", () => stepEpisode(1));
    function toggleShield() {
      const turnOff = shieldOn();
      prefs.shieldOff = Object.assign({}, prefs.shieldOff, { [shieldKey]: turnOff });
      savePrefs(); armTrap(); sync();
      showBanner(turnOff ? "Ad shield OFF for this server \u2014 pop-up ads may appear." : "Ad shield ON \u2014 the first tap is absorbed so ad pop-ups cannot start.", [], 3400);
    }
    screenBtn.addEventListener("click", cycleScreen);
    shieldBtn.addEventListener("click", toggleShield);
    reloadBtn.addEventListener("click", () => { reload(); showBanner("Reloading the video\u2026", [], 1800); });
    const onKey = event => {
      if (event.key === "Escape" && target.classList.contains("pd-pseudo-fs") && !isLocked()) { exitFs(); return; }
      if (event.ctrlKey || event.metaKey || event.altKey || isLocked()) return;
      if (document.querySelector("dialog[open], .pd-screen.is-open, #pd-audio-pop")) return;
      const t = event.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      const k = String(event.key || "").toLowerCase();
      if (k === "f") fsBtn.click();
      else if (k === "l") setLocked(true);
      else if (k === "r") reloadBtn.click();
      else if (k === "g") gestureBtn.click();
      else if (k === "a") toggleShield();
      else if (k === "w") cycleScreen();
      else if (k === "s") nextServer();
      else if (k === "n" && hasEps) stepEpisode(1);
      else if (k === "p" && hasEps) stepEpisode(-1);
      else if (k === "?" || k === "/") showBanner("Keys: F fullscreen \u00b7 L lock \u00b7 R reload \u00b7 S next server" + (hasEps ? " \u00b7 N / P next / previous episode" : "") + " \u00b7 G gestures \u00b7 A ad shield \u00b7 W screen size", [], 8000);
      else return;
      event.preventDefault();
    };
    document.addEventListener("keydown", onKey);
    /* the screen wake-lock is dropped by the browser when the tab is hidden: take it again when the viewer comes back in fullscreen */
    const onVisible = () => { if (!document.hidden && isFs() && !wakeLock) keepAwake(true); };
    document.addEventListener("visibilitychange", onVisible);

    /* controls fade a little when idle */
    const wakeControls = () => {
      controls.classList.add("is-awake");
      clearTimeout(ctlTimer);
      ctlTimer = setTimeout(() => controls.classList.remove("is-awake"), 3000);
    };
    wrapper.addEventListener("pointermove", wakeControls, { passive: true });
    wrapper.addEventListener("pointerdown", wakeControls, { passive: true });

    /* banner (hints + "not playing" help) */
    let bannerTimer = 0;
    function showBanner(text, actions, autoHideMs) {
      banner.replaceChildren(el("span", "", ""));
      banner.firstChild.textContent = text;
      (actions || []).forEach(action => {
        const button = el("button", action.primary ? "pd-primary" : "");
        button.type = "button";
        button.textContent = action.label;
        button.addEventListener("click", () => { action.run(); });
        banner.append(button);
      });
      banner.hidden = false;
      clearTimeout(bannerTimer);
      if (autoHideMs) bannerTimer = setTimeout(() => { banner.hidden = true; }, autoHideMs);
    }
    const hideBanner = () => { clearTimeout(bannerTimer); banner.hidden = true; };
    function reload() {
      hideBanner(); showLoader(); armTrap(); cur.lastT = null;
      clearTimeout(reloadTimer);
      frame.src = "about:blank";
      reloadTimer = setTimeout(() => { if (!dead) frame.src = src.url; }, 60);
    }
    function switchTo(id) {
      const button = document.querySelector(`[data-watch-server="${id}"]`);
      if (button) { button.click(); return true; }
      return false;
    }
    function nextServer() {
      hideBanner();
      const l = list(options);
      if (l.length < 2) { reload(); return; }
      const i = l.findIndex(p => p.id === src.provider);
      if (!switchTo(l[(i + 1) % l.length].id)) reload();
    }
    /* NO automatic server switching, ever: the viewer picks the server (Server buttons, or key S for the next one). */
    if (src.url === "about:blank") showBanner("No server is switched on for this title right now.", [], 0);

    if (touch && customFs && !prefs.hinted) {
      prefs.hinted = true;
      savePrefs();
      showBanner("Tip: fullscreen enables swipe brightness; the lock stops accidental touches.", [], 6000);
    }

    /* messages from the embed (vidstuck: JSON string · vumeto: object with gaia:/publicdrop: type) */
    function parseMessage(event) {
      let data = event.data;
      if (typeof data === "string") { try { data = JSON.parse(data); } catch { return null; } }
      if (!data || typeof data !== "object") return null;
      const type = String(data.type || "");
      /* VidLink (documented): PLAYER_EVENT {event,currentTime,duration,season,episode} while playing, MEDIA_DATA with saved progress */
      if (type === "PLAYER_EVENT" && data.data && typeof data.data === "object") {
        const d = data.data;
        return { kind: "progress", currentTime: Number(d.currentTime), duration: Number(d.duration), season: d.season, episode: d.episode, completed: d.event === "ended" };
      }
      if (type === "MEDIA_DATA") return { kind: "signal" };
      if (/embed-episode-change$/.test(type) && data.payload) return { kind: "episode", ...data.payload };
      if (/playback-progress$/.test(type) && data.payload) return { kind: "progress", ...data.payload };
      if ("currentTime" in data && "duration" in data) {
        return { kind: "progress", currentTime: Number(data.currentTime), duration: Number(data.duration), season: data.season, episode: data.episode };
      }
      if ("timestamp" in data || "duration" in data) {
        return { kind: "progress", currentTime: Number(data.timestamp), duration: Number(data.duration), season: data.season, episode: data.episode };
      }
      return null;
    }
    const validInt = value => Number.isInteger(Number(value)) && Number(value) >= 1;
    function episodeMoved(season, episode) {
      if (!isTv || !validInt(season) || !validInt(episode)) return;
      season = Number(season); episode = Number(episode);
      if (season === cur.season && episode === cur.episode) return;
      const automatic = season === cur.season && episode === cur.episode + 1 && cur.ratio >= 0.85;
      cur.season = season; cur.episode = episode; cur.ratio = 0; cur.lastReport = 0; cur.lastT = null; cur.acc = 0;
      window.dispatchEvent(new CustomEvent("publicdrop:player-episode-change", {
        cancelable: true,
        detail: { id: String(options.id), type: options.type, season, episode, automatic, dub: options.dub },
      }));
    }
    function onMessage(event) {
      if (dead || (event.source !== frame.contentWindow && event.origin !== src.origin)) return;
      const message = parseMessage(event);
      if (!message) return;
      cur.signal = true;
      if (message.kind === "signal") return;
      if (message.kind === "episode") { episodeMoved(message.season, message.episode); return; }
      const currentTime = Number(message.currentTime), duration = Number(message.duration);
      if (isTv) episodeMoved(message.season, message.episode);
      if (!Number.isFinite(currentTime) || !Number.isFinite(duration) || duration <= 0) return;
      cur.ratio = currentTime / duration; cur.everProg = true;
      const now = Date.now();
      /* count playback only: the position must advance about as fast as the clock (up to 2x speed). Jumping to 89%, resuming or seeking adds nothing. */
      if (cur.lastT !== null) {
        const moved = currentTime - cur.lastT, wall = (now - cur.lastWall) / 1000;
        if (moved > 0 && moved <= Math.min(30, wall * 2.5 + 1)) cur.acc += moved;
      }
      cur.lastT = currentTime; cur.lastWall = now;
      const nearEnd = cur.ratio >= 0.9 || message.completed;
      if (!message.completed && now - cur.lastReport < (nearEnd ? 1500 : 4000)) return;
      cur.lastReport = now;
      if (typeof options.onProgress === "function") {
        const movie = options.type === "movie";
        options.onProgress({
          type: options.type, id: String(options.id),
          season: movie ? 0 : (validInt(message.season) ? Number(message.season) : cur.season),
          episode: movie ? 0 : (validInt(message.episode) ? Number(message.episode) : cur.episode),
          currentTime, duration, completed: Boolean(message.completed), metadata: options.metadata,
          watchedDelta: Math.round(cur.acc * 10) / 10,
        });
        cur.acc = 0;
      }
    }
    window.addEventListener("message", onMessage);

    /* FALLBACK: some servers never report their position. Then count the time the viewer really spends watching (tab visible, page open)
       so Watch History and Watch Time still work. Real reports from the embed always win: as soon as one arrives this stops. */
    const fbT0 = Date.now();
    let fbLast = Date.now(), fbSec = 0, fbSent = 0, fbReportedAt = 0;
    const fbTimer = setInterval(() => {
      if (dead) { clearInterval(fbTimer); return; }
      const now = Date.now(), dt = Math.min(6, (now - fbLast) / 1000); fbLast = now;
      if (cur.everProg || document.hidden || src.url === "about:blank") return;   /* servers that report real progress are counted exactly; everything else by time spent */
      if (now - fbT0 < 20000) return;                       /* give the embed time to start and to report */
      fbSec += dt;
      if (fbSec < 20 || now - fbReportedAt < 30000 || typeof options.onProgress !== "function") return;
      fbReportedAt = now;
      const movie = options.type === "movie";
      const runtime = (Number(options.metadata && options.metadata.runtime) || (movie ? 120 : 45)) * 60;
      options.onProgress({
        type: options.type, id: String(options.id),
        season: movie ? 0 : cur.season, episode: movie ? 0 : cur.episode,
        currentTime: fbSec, duration: Math.max(runtime, fbSec + 600), completed: false, estimated: true, metadata: options.metadata,
        watchedDelta: Math.round((fbSec - fbSent) * 10) / 10,
      });
      fbSent = fbSec;
    }, 5000);

    /* A cross-origin embed can try to send the WHOLE page somewhere else (usually an ad) right after a click inside it.
       Browsers allow that only after a real click, so for a few seconds after the viewer clicks inside the video the page asks
       "Leave site?" instead of silently leaving. Normal tab closing / navigation is never blocked at any other time. */
    let guardUntil = 0;
    const onBlur = () => { try { if (document.activeElement === frame) guardUntil = Date.now() + 6000; } catch {} };
    const guardLeave = event => { if (Date.now() < guardUntil && !dead) { event.preventDefault(); event.returnValue = ""; return ""; } };
    window.addEventListener("blur", onBlur);
    window.addEventListener("beforeunload", guardLeave);

    sync();

    return function cleanup() {
      dead = true; clearInterval(fbTimer);
      [hudTimer, awakeTimer, holdTimer, ctlTimer, bannerTimer, loaderTimer, reloadTimer].forEach(clearTimeout);
      window.removeEventListener("message", onMessage);
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("visibilitychange", onVisible);
      if (wakeLock) { try { wakeLock.release(); } catch {} wakeLock = null; }
      fsListeners.delete(sync); fsListeners.delete(onFsExit);
      window.removeEventListener("beforeunload", guardLeave); window.removeEventListener("blur", onBlur);
      wrapper.remove();
      // Fullscreen + lock belong to the .watch-shell, so they carry over to the next episode on purpose.
    };
  }

  window.PublicDROPStaticPlayer = Object.freeze({ mount, list, pick, groupOf, healthy, probe, labels: Object.fromEntries(Object.keys(PROVIDERS).map(k => [k, PROVIDERS[k].label])), version: "6.0.0" });
})();
