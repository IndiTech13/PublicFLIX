/* PublicDROP audio language: default Hindi. Saved with the account through the existing settings sync (auth.js). */
(function () {
  "use strict";
  var KEY = "publicdrop-audio-lang";
  var LANGS = [
    { code: "hi", name: "Hindi", native: "हिन्दी", sub: "hindi" }, { code: "en", name: "English", native: "English", sub: "english" },
    { code: "ta", name: "Tamil", native: "தமிழ்", sub: "tamil" }, { code: "te", name: "Telugu", native: "తెలుగు", sub: "telugu" },
    { code: "ml", name: "Malayalam", native: "മലയാളം", sub: "malayalam" }, { code: "kn", name: "Kannada", native: "ಕನ್ನಡ", sub: "kannada" },
    { code: "bn", name: "Bengali", native: "বাংলা", sub: "bengali" }, { code: "mr", name: "Marathi", native: "मराठी", sub: "marathi" },
    { code: "pa", name: "Punjabi", native: "ਪੰਜਾਬੀ", sub: "punjabi" }
  ];
  function info(code) { for (var i = 0; i < LANGS.length; i++) if (LANGS[i].code === code) return LANGS[i]; return { code: code, name: String(code || "").toUpperCase(), native: "", sub: "english" }; }
  function get() { var v = ""; try { v = localStorage.getItem(KEY) || ""; } catch (e) {} return LANGS.some(function (l) { return l.code === v; }) ? v : "hi"; }
  function set(code) {
    if (!LANGS.some(function (l) { return l.code === code; }) || code === get()) return;
    try { localStorage.setItem(KEY, code); } catch (e) {}
    window.dispatchEvent(new CustomEvent("publicdrop:audio-changed", { detail: { code: code } }));
  }
  /* true = the title is in this language, false = it is not, null = we cannot tell yet (TMDB only knows the original + spoken languages) */
  function originalOf(x) { return x ? String(x.originalLanguage || x.original_language || "") : ""; }
  function supports(x, code) {
    code = code || get(); if (!x) return null;
    var o = originalOf(x), sp = x.spokenLanguages || (x.spoken_languages || []).map(function (l) { return l && l.iso_639_1; });
    if (x.dubbed === true || x.audioDubbed === true) return true;
    if (o === code || (sp || []).indexOf(code) >= 0) return true;
    var tr = x.translations && x.translations.translations;
    if (tr && tr.some(function (t) { return t && t.iso_639_1 === code; })) return true;
    var rel = x.release_dates && x.release_dates.results;
    if (code === "hi" && rel && rel.some(function (r) { return r && r.iso_3166_1 === "IN"; })) return true;
    if (!o && !(sp && sp.length)) return null;
    return false;
  }
  function options(selected) { return LANGS.map(function (l) { return '<option value="' + l.code + '"' + (l.code === selected ? " selected" : "") + ">" + l.name + (l.native && l.native !== l.name ? " (" + l.native + ")" : "") + "</option>"; }).join(""); }

  /* popup: shown when the chosen audio language is probably not available for the title being played */
  function notice(opts) {
    if (document.getElementById("pd-audio-pop")) return;
    if (!document.getElementById("pd-audio-css")) {
      var st = document.createElement("style"); st.id = "pd-audio-css";
      st.textContent = "#pd-audio-pop{position:fixed;inset:0;z-index:2000;display:grid;place-items:center;padding:18px;background:rgba(0,0,0,.62);backdrop-filter:blur(6px)}#pd-audio-pop .b{width:100%;max-width:420px;background:var(--surface,#14161c);color:var(--text,#fff);border:1px solid rgba(255,255,255,.14);border-radius:22px;padding:24px;box-shadow:0 30px 80px rgba(0,0,0,.6)}#pd-audio-pop h3{margin:0 0 8px;font-size:1.15rem}#pd-audio-pop p{margin:0 0 18px;color:var(--muted,#aab);line-height:1.5;font-size:.93rem}#pd-audio-pop .r{display:flex;gap:10px;flex-wrap:wrap}#pd-audio-pop button{flex:1;min-height:44px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:transparent;color:inherit;font:700 .9rem inherit;cursor:pointer}#pd-audio-pop button.p{background:var(--accent,#e50914);border-color:transparent;color:#fff}#pd-audio-pop select{width:100%;min-height:44px;margin:0 0 14px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:inherit;padding:0 10px;font:inherit}#pd-audio-pop select option{color:#000}";
      document.head.appendChild(st);
    }
    var d = document.createElement("div"); d.id = "pd-audio-pop"; d.setAttribute("role", "dialog"); d.setAttribute("aria-modal", "true");
    d.innerHTML = '<div class="b"><h3></h3><p></p><select aria-label="Audio language"></select><div class="r"><button type="button" data-a="stay"></button><button type="button" class="p" data-a="change">Change language</button></div></div>';
    d.querySelector("h3").textContent = info(opts.code).name + " audio may not be available";
    d.querySelector("p").textContent = (opts.title ? "\u201C" + opts.title + "\u201D" : "This title") + " looks like a " + info(opts.original).name + " title, so " + info(opts.code).name + " audio may not be available. You can play it anyway, or pick another audio language.";
    d.querySelector("select").innerHTML = options(opts.original && info(opts.original).name !== String(opts.original).toUpperCase() ? opts.original : "en");
    d.querySelector('[data-a="stay"]').textContent = "Play anyway";
    function close() { d.remove(); }
    d.querySelector('[data-a="stay"]').onclick = close;
    d.querySelector('[data-a="change"]').onclick = function () { var v = d.querySelector("select").value; close(); set(v); };
    d.addEventListener("click", function (e) { if (e.target === d) close(); });
    document.body.appendChild(d); d.querySelector("button.p").focus();
  }

  /* settings drawer (works for guests too) */
  function bindSelect() {
    var s = document.getElementById("audio-select"); if (!s) return;
    s.innerHTML = options(get()); s.onchange = function () { set(s.value); };
    window.addEventListener("publicdrop:audio-changed", function () { s.value = get(); });
    window.addEventListener("publicdrop:settings-loaded", function () { s.value = get(); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bindSelect); else bindSelect();

  window.PublicDROPAudio = Object.freeze({ get: get, set: set, info: info, langs: LANGS, supports: supports, originalOf: originalOf, options: options, notice: notice });
})();
