/* Streaming-app filter chip (top bar, next to the language chip). */
(function () {
  "use strict";
  var KEY = "pd-provider";
  var LIST = [
    { id: "all", name: "All apps", short: "ALL", ids: "" },
    { id: "netflix", name: "Netflix", short: "NF", ids: "8" },
    { id: "hotstar", name: "JioHotstar", short: "JH", ids: "122|2336|970" },
    { id: "prime", name: "Amazon Prime Video", short: "PV", ids: "119|9" },
    { id: "zee5", name: "ZEE5", short: "Z5", ids: "232" },
    { id: "sonyliv", name: "SonyLIV", short: "SL", ids: "237" },
    { id: "apple", name: "Apple TV+", short: "TV+", ids: "350" },
    { id: "sunnxt", name: "Sun NXT", short: "SN", ids: "309" },
    { id: "aha", name: "aha", short: "AH", ids: "532" },
    { id: "hoichoi", name: "Hoichoi", short: "HC", ids: "315" },
    { id: "lionsgate", name: "Lionsgate Play", short: "LG", ids: "561" }
  ];
  function info(id) { for (var i = 0; i < LIST.length; i++) if (LIST[i].id === id) return LIST[i]; return LIST[0]; }
  function get() { try { return info(localStorage.getItem(KEY) || "all").id; } catch (e) { return "all"; } }
  function set(id) {
    try { localStorage.setItem(KEY, id); } catch (e) {}
    window.dispatchEvent(new CustomEvent("publicdrop:provider-changed", { detail: { id: id } }));
  }
  function paint() {
    var c = document.getElementById("provider-button"); if (!c) return;
    var p = info(get()); c.textContent = p.short; c.classList.toggle("is-on", p.id !== "all");
    c.title = "Streaming app: " + p.name;
    var a = document.getElementById("audio-button");
    if (a) { a.style.display = p.id === "all" ? "" : "none"; }
  }
  function pick() {
    if (document.getElementById("pd-audio-pick")) return;
    var d = document.createElement("div"); d.id = "pd-audio-pop"; d.setAttribute("role", "dialog"); d.setAttribute("aria-modal", "true");
    d.innerHTML = '<div class="b"><h3>Streaming app</h3><p>Show only titles available on one app (India).</p><div class="pd-ap-list"></div></div>';
    var list = d.querySelector(".pd-ap-list");
    LIST.forEach(function (l) {
      var b = document.createElement("button"); b.type = "button";
      b.style.cssText = "width:100%;display:flex;align-items:center;margin:0 0 8px;padding:0 14px;text-align:left";
      b.className = l.id === get() ? "p" : ""; b.textContent = l.name;
      b.onclick = function () { set(l.id); d.remove(); }; list.appendChild(b);
    });
    d.addEventListener("click", function (e) { if (e.target === d) d.remove(); });
    document.body.appendChild(d);
  }
  function bind() {
    var a = document.getElementById("audio-button"); if (!a || document.getElementById("provider-button")) return;
    var c = document.createElement("button"); c.type = "button"; c.id = "provider-button"; c.className = "icon-button lang-chip provider-chip";
    c.setAttribute("aria-label", "Streaming app filter"); a.parentNode.insertBefore(c, a);
    c.onclick = pick; paint(); window.addEventListener("publicdrop:provider-changed", paint);
  }
  window.PublicDROPProvider = { get: get, set: set, info: info, list: LIST,
    active: function () { var p = info(get()); return p.id === "all" ? null : p; } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind); else bind();
})();
