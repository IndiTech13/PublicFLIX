(function () {
  "use strict";
  const key = "publicdrop-service-restored-2026-10-05-v1";
  // Fixed site-wide expiry: visits and reloads must never restart the two-day window.
  const expiresAt = Date.parse("2026-10-07T03:59:42Z");
  let shown = false;
  function showServiceNotice() {
    if (shown || Date.now() >= expiresAt) return;
    try { if (sessionStorage.getItem(key) === "dismissed") return; } catch {}
    shown = true;
    const dialog = document.createElement("dialog");
    dialog.id = "service-notice";
    dialog.setAttribute("aria-labelledby", "service-notice-title");
    dialog.setAttribute("aria-describedby", "service-notice-message");
    dialog.innerHTML = `<form method="dialog">
      <span class="service-notice-eyebrow">Service update</span>
      <h2 id="service-notice-title">We're back!</h2>
      <div id="service-notice-message">
        <p>Maintenance is complete, and multi-audio tracks are back. Choose your preferred audio language in the player and enjoy watching!</p>
        <p>Thank you for your patience and support.</p>
      </div>
      <button type="submit" autofocus>Got it</button>
    </form>`;
    const expiryTimer = setTimeout(() => dialog.close(), expiresAt - Date.now());
    dialog.addEventListener("close", () => {
      clearTimeout(expiryTimer);
      try { sessionStorage.setItem(key, "dismissed"); } catch {}
      dialog.remove();
    }, { once: true });
    document.body.append(dialog);
    dialog.showModal();
  }
  window.addEventListener("publicdrop:critical-ui-ready", showServiceNotice, { once: true });
  if (window.PUBLICDROP_CRITICAL_UI_READY) showServiceNotice();
})();
