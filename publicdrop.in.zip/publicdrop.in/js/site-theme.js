/* PublicDROP site theme: the admin picks the DEFAULT look (dark/light + accent colour) in the admin panel.
   Visitors who never chose their own look get the admin default; "apply to everyone" overrides personal choices.
   Runs in <head> before the first paint so there is no colour flash. Never throws. */
(function () {
  "use strict";
  var KEY = "pd_admin_theme";
  var HEX = /^#[0-9a-f]{6}$/i;
  var root = document.documentElement;

  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function parse(v) { try { return JSON.parse(v); } catch (e) { return null; } }

  function clean(t) {
    t = t && typeof t === "object" ? t : {};
    return {
      mode: t.mode === "light" ? "light" : "dark",
      accent: HEX.test(String(t.accent || "")) ? String(t.accent).toLowerCase() : "#e50914",
      force: !!t.force
    };
  }
  function admin() { return clean(parse(lsGet(KEY))); }
  function userTheme() { var v = parse(lsGet("publicdrop-theme")); return v === "light" || v === "dark" ? v : null; }
  function userAccent() { var v = parse(lsGet("publicdrop-accent")); return typeof v === "string" && HEX.test(v) ? v : null; }

  function effective() {
    var a = admin();
    if (a.force) return { theme: a.mode, accent: a.accent };
    return { theme: userTheme() || a.mode, accent: userAccent() || a.accent };
  }

  function apply() {
    var e = effective();
    root.dataset.theme = e.theme;
    root.style.setProperty("--accent", e.accent);
    try {
      var meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute("content", e.theme === "light" ? "#fafbfe" : "#08090c");
    } catch (err) {}
  }

  function setAdmin(cfg) {
    var next = clean(cfg), prev = lsGet(KEY);
    var json = JSON.stringify(next);
    if (prev === json) return;
    lsSet(KEY, json);
    apply();
    try { window.dispatchEvent(new CustomEvent("pd:theme", { detail: effective() })); } catch (e) {}
  }

  window.PDTheme = { effective: effective, apply: apply, setAdmin: setAdmin, locked: function () { return admin().force; } };
  apply();
})();
