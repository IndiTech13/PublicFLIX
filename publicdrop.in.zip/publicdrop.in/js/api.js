(function () {
  "use strict";

  const config = window.PUBLICDROP_CONFIG;

  async function fetchJson(url, options = {}, timeoutMs = config.CATALOG_REQUEST_TIMEOUT_MS || 15000) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        cache: "no-store",
        ...options,
        headers: { Accept: "application/json", ...(options.headers || {}) },
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`API request failed (${response.status})`);
      return await response.json();
    } finally {
      clearTimeout(timeout);
    }
  }

  // Some networks block api.themoviedb.org; api.tmdb.org is TMDB's official alias. Remember whichever host answers.
  const tmdbBases = [...new Set([config.TMDB_BASE_URL, ...(config.TMDB_FALLBACK_BASE_URLS || [])].filter(Boolean))];
  let preferredBase = 0;

  /* Two TMDB keys: the one built into config.js ("main") and an optional extra one set in Admin > API keys.
     Mode "auto" = use whichever answers fastest, "main"/"extra" = that one first. Either way, a key that is slow,
     rate-limited, rejected or down is skipped for a while and the other key is used, so visitors never notice. */
  const TMDB_SLOW_MS = config.TMDB_SLOW_MS || 6000;
  const keyHealth = new Map(); // key -> { until: timestamp it is skipped until, avg: average response ms }
  const healthOf = key => keyHealth.get(key) || { until: 0, avg: 0 };

  function tmdbKeys() {
    const live = window.PUBLICDROP_TMDB || {};
    const main = config.TMDB_API_KEY;
    const extra = live.extraKey && live.extraKey !== main ? live.extraKey : "";
    const list = [main];
    if (extra) list.push(extra);
    if (list.length < 2) return list;
    const mode = live.mode || "auto";
    if (mode === "extra") list.reverse();
    const now = Date.now();
    return list.sort((a, b) => {
      const ha = healthOf(a), hb = healthOf(b);
      const cooling = (ha.until > now) - (hb.until > now); // resting keys go last, but are still a last resort
      if (cooling) return cooling;
      return mode === "auto" ? ha.avg - hb.avg : 0;
    });
  }
  function keySucceeded(key, ms) {
    const h = healthOf(key);
    keyHealth.set(key, { until: 0, avg: h.avg ? Math.round(h.avg * 0.7 + ms * 0.3) : ms });
  }
  function keyFailed(key, restMs) {
    keyHealth.set(key, { ...healthOf(key), until: Date.now() + restMs });
  }

  async function tmdbRequest(path, params) {
    let lastError;
    const keys = tmdbKeys();
    const multi = keys.length > 1;
    const attempts = [];
    for (let round = 0; round < (multi ? 1 : 2); round += 1) {
      keys.forEach(key => {
        for (let b = 0; b < tmdbBases.length; b += 1) attempts.push({ key, base: (preferredBase + b) % tmdbBases.length });
      });
    }
    const hostFails = new Map();
    const rejected = new Set();
    for (let i = 0; i < attempts.length; i += 1) {
      const { key, base } = attempts[i];
      if (rejected.has(key)) continue;
      const url = new URL(`${tmdbBases[base]}${path}`);
      Object.entries(params || {}).forEach(([name, value]) => {
        if (value !== undefined && value !== null && value !== "") url.searchParams.set(name, String(value));
      });
      url.searchParams.set("api_key", key);
      // With a spare key, give the first one only a short time before moving on; the last attempt gets the full time.
      const timeout = multi && i < attempts.length - 1 ? Math.min(TMDB_SLOW_MS, config.CATALOG_REQUEST_TIMEOUT_MS || 15000) : undefined;
      const started = Date.now();
      try {
        // Let the browser HTTP cache honour TMDB's own Cache-Control headers instead of re-downloading on every visit.
        const data = await fetchJson(url.href, { cache: "default" }, timeout);
        preferredBase = base;
        if (multi) keySucceeded(key, Date.now() - started);
        return data;
      } catch (error) {
        lastError = error;
        const message = String(error?.message);
        // A 404 means "no such title/season" — another host or key will say the same.
        if (/\(404\)/.test(message)) throw error;
        if (/\((?:401|403)\)/.test(message)) { // this key is refused: stop using it for a while
          rejected.add(key);
          keyFailed(key, 10 * 60 * 1000);
          continue;
        }
        if (/\(429\)/.test(message)) { keyFailed(key, 60 * 1000); rejected.add(key); continue; } // rate limited: rest this key
        const fails = (hostFails.get(key) || 0) + 1;
        hostFails.set(key, fails);
        if (multi && fails >= tmdbBases.length) keyFailed(key, 60 * 1000); // slow or down on every host: rest this key
        if (!multi && i === tmdbBases.length - 1) await new Promise(resolve => setTimeout(resolve, 350));
      }
    }
    throw lastError || new Error("API request failed");
  }

  async function availableResults(requests) {
    const settled = await Promise.allSettled(requests);
    if (settled.every(item => item.status === "rejected")) throw settled[0].reason;
    return settled.map(item => item.status === "fulfilled" ? item.value : { results: [] });
  }

  function joinedGenres(...ids) {
    return [...new Set(ids.map(Number).filter(Number.isFinite).filter(Boolean))].join(",");
  }

  async function publicSeries({ type, page = 1, language = "en-US", genre = null }) {
    if (type === "anime") {
      const [series, movies] = await availableResults([
        tmdbRequest("/discover/tv", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.tv), with_original_language: "ja" }),
        tmdbRequest("/discover/movie", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.movie), with_original_language: "ja" }),
      ]);
      return { results: [
        ...(series.results || []).map(item => ({ ...item, media_type: "tv", isJapaneseAnime: true })),
        ...(movies.results || []).map(item => ({ ...item, media_type: "movie", isJapaneseAnime: true })),
      ] };
    }
    if (type === "cartoon") {
      const [series, movies] = await availableResults([
        tmdbRequest("/discover/tv", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.tv), with_original_language: "en" }),
        tmdbRequest("/discover/movie", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.movie), with_original_language: "en" }),
      ]);
      return { results: [
        ...(series.results || []).map(item => ({ ...item, media_type: "tv", isCartoon: true })),
        ...(movies.results || []).map(item => ({ ...item, media_type: "movie", isCartoon: true })),
      ] };
    }
    const mediaType = type === "tv" ? "tv" : "movie";
    return tmdbRequest(`/discover/${mediaType}`, { language, page, sort_by: "popularity.desc", include_adult: false, without_genres: 16, with_genres: genre?.[mediaType] || "" });
  }

  const publicImages = ({ id, type, language = "en" }) =>
    tmdbRequest(`/${type}/${id}/images`, { include_image_language: `${language},null` });
  const publicSearch = ({ q, page = 1, language = "en-US" }) =>
    tmdbRequest("/search/multi", { query: q, page, language, include_adult: false });
  const publicDetails = ({ id, type, language = "en-US" }) => tmdbRequest(`/${type}/${id}`, {
    language,
    append_to_response: "credits,images,release_dates,content_ratings,external_ids,alternative_titles",
    include_image_language: "en,null",
  });
  const publicRelated = ({ id, type, page = 1, language = "en-US" }) =>
    tmdbRequest(`/${type}/${id}/recommendations`, { page, language });
  const publicEpisodes = ({ id, season = 1, language = "en-US" }) =>
    tmdbRequest(`/tv/${id}/season/${season}`, { language });
  const watchProviders = ({ type, language = "en-US" }) =>
    tmdbRequest(`/watch/providers/${type}`, { language });
  const providerCatalog = ({ id, type, page = 1, region = "US", language = "en-US" }) =>
    tmdbRequest(`/discover/${type}`, {
      language,
      page,
      include_adult: false,
      sort_by: "popularity.desc",
      watch_region: region,
      with_watch_providers: id,
    });

  async function animeSearch({ title }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-search?title=${encodeURIComponent(title)}`);
  }

  async function animeDetails({ anilistId }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-anime?anilistId=${encodeURIComponent(anilistId)}`);
  }

  async function animeEpisodes({ id }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-episodes?id=${encodeURIComponent(id)}`);
  }

  window.PublicDROPAPI = Object.freeze({
    animeDetails,
    publicSeries,
    publicImages,
    series: publicSeries,
    search: publicSearch,
    details: publicDetails,
    images: publicImages,
    related: publicRelated,
    episodes: publicEpisodes,
    watchProviders,
    providerCatalog,
    animeSearch,
    animeEpisodes,
  });
})();
