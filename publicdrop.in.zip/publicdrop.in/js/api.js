(function () {
  "use strict";

  const config = window.PUBLICDROP_CONFIG;

  async function fetchJson(url, options = {}, timeoutMs = config.CATALOG_REQUEST_TIMEOUT_MS || 15000) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        cache: "no-store",
        ...options,
        headers: { Accept: "application/json", ...(options.headers || {}) },
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`API request failed (${response.status})`);
      return await response.json();
    } finally {
      clearTimeout(timeout);
    }
  }

  // Some networks block api.themoviedb.org; api.tmdb.org is TMDB's official alias. Remember whichever host answers.
  const tmdbBases = [...new Set([config.TMDB_BASE_URL, ...(config.TMDB_FALLBACK_BASE_URLS || [])].filter(Boolean))];
  let preferredBase = 0;

  /* Two TMDB keys: the one built into config.js ("main") and an optional extra one set in Admin > API keys.
     Mode "auto" = use whichever answers fastest, "main"/"extra" = that one first. Either way, a key that is slow,
     rate-limited, rejected or down is skipped for a while and the other key is used, so visitors never notice. */
  const TMDB_SLOW_MS = config.TMDB_SLOW_MS || 6000;
  const keyHealth = new Map(); // key -> { until: timestamp it is skipped until, avg: average response ms }
  const healthOf = key => keyHealth.get(key) || { until: 0, avg: 0 };

  function tmdbKeys() {
    const live = window.PUBLICDROP_TMDB || {};
    const main = config.TMDB_API_KEY;
    const extra = live.extraKey && live.extraKey !== main ? live.extraKey : "";
    const list = [main];
    if (extra) list.push(extra);
    if (list.length < 2) return list;
    const mode = live.mode || "auto";
    if (mode === "extra") list.reverse();
    const now = Date.now();
    return list.sort((a, b) => {
      const ha = healthOf(a), hb = healthOf(b);
      const cooling = (ha.until > now) - (hb.until > now); // resting keys go last, but are still a last resort
      if (cooling) return cooling;
      return mode === "auto" ? ha.avg - hb.avg : 0;
    });
  }
  /* Anonymous key-health counters for Admin > API keys. Only the labels "main"/"extra" are ever sent, never a key. */
  const health = { main: { ok: 0, fail: 0, slow: 0, ms: 0, n: 0 }, extra: { ok: 0, fail: 0, slow: 0, ms: 0, n: 0 }, sw: 0 };
  let healthDirty = false;
  const keyLabel = key => (key === config.TMDB_API_KEY ? "main" : "extra");
  function track(key, ok, ms, slow) {
    const row = health[keyLabel(key)];
    if (ok) { row.ok += 1; row.ms += ms; row.n += 1; } else { row.fail += 1; if (slow) row.slow += 1; }
    healthDirty = true;
  }
  function flushHealth() {
    if (!healthDirty) return;
    const body = JSON.stringify(health);
    healthDirty = false;
    ["main", "extra"].forEach(k => { health[k] = { ok: 0, fail: 0, slow: 0, ms: 0, n: 0 }; });
    health.sw = 0;
    try { if (navigator.sendBeacon && navigator.sendBeacon("/pd-api/tmdb-report", new Blob([body], { type: "text/plain" }))) return; } catch (e) {}
    try { fetch("/pd-api/tmdb-report", { method: "POST", body, keepalive: true, headers: { "Content-Type": "text/plain" } }).catch(() => {}); } catch (e) {}
  }
  setInterval(flushHealth, 60000);
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") flushHealth(); });
  window.addEventListener("pagehide", flushHealth);

  function keySucceeded(key, ms) {
    const h = healthOf(key);
    keyHealth.set(key, { until: 0, avg: h.avg ? Math.round(h.avg * 0.7 + ms * 0.3) : ms });
  }
  function keyFailed(key, restMs) {
    keyHealth.set(key, { ...healthOf(key), until: Date.now() + restMs });
  }

  async function tmdbRequest(path, params) {
    let lastError;
    const keys = tmdbKeys();
    const multi = keys.length > 1;
    const attempts = [];
    for (let round = 0; round < (multi ? 1 : 2); round += 1) {
      keys.forEach(key => {
        for (let b = 0; b < tmdbBases.length; b += 1) attempts.push({ key, base: (preferredBase + b) % tmdbBases.length });
      });
    }
    const hostFails = new Map();
    const rejected = new Set();
    let previousKey = "";
    for (let i = 0; i < attempts.length; i += 1) {
      const { key, base } = attempts[i];
      if (rejected.has(key)) continue;
      const url = new URL(`${tmdbBases[base]}${path}`);
      Object.entries(params || {}).forEach(([name, value]) => {
        if (value !== undefined && value !== null && value !== "") url.searchParams.set(name, String(value));
      });
      url.searchParams.set("api_key", key);
      // With a spare key, give the first one only a short time before moving on; the last attempt gets the full time.
      const timeout = multi && i < attempts.length - 1 ? Math.min(TMDB_SLOW_MS, config.CATALOG_REQUEST_TIMEOUT_MS || 15000) : undefined;
      const started = Date.now();
      if (multi && previousKey && previousKey !== key) health.sw += 1; // moved on to the other key within this request
      previousKey = key;
      try {
        // Let the browser HTTP cache honour TMDB's own Cache-Control headers instead of re-downloading on every visit.
        const data = await fetchJson(url.href, { cache: "default" }, timeout);
        preferredBase = base;
        if (multi) keySucceeded(key, Date.now() - started);
        track(key, true, Date.now() - started);
        return data;
      } catch (error) {
        lastError = error;
        const message = String(error?.message);
        if (!/\(404\)/.test(message)) track(key, false, Date.now() - started, error?.name === "AbortError");
        // A 404 means "no such title/season" — another host or key will say the same.
        if (/\(404\)/.test(message)) throw error;
        if (/\((?:401|403)\)/.test(message)) { // this key is refused: stop using it for a while
          rejected.add(key);
          keyFailed(key, 10 * 60 * 1000);
          continue;
        }
        if (/\(429\)/.test(message)) { keyFailed(key, 60 * 1000); rejected.add(key); continue; } // rate limited: rest this key
        const fails = (hostFails.get(key) || 0) + 1;
        hostFails.set(key, fails);
        if (multi && fails >= tmdbBases.length) keyFailed(key, 60 * 1000); // slow or down on every host: rest this key
        if (!multi && i === tmdbBases.length - 1) await new Promise(resolve => setTimeout(resolve, 350));
      }
    }
    throw lastError || new Error("API request failed");
  }

  async function availableResults(requests) {
    const settled = await Promise.allSettled(requests);
    if (settled.every(item => item.status === "rejected")) throw settled[0].reason;
    return settled.map(item => item.status === "fulfilled" ? item.value : { results: [] });
  }

  function joinedGenres(...ids) {
    return [...new Set(ids.map(Number).filter(Number.isFinite).filter(Boolean))].join(",");
  }

  async function publicSeries({ type, page = 1, language = "en-US", genre = null }) {
    if (type === "anime") {
      const [series, movies] = await availableResults([
        tmdbRequest("/discover/tv", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.tv), with_original_language: "ja" }),
        tmdbRequest("/discover/movie", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.movie), with_original_language: "ja" }),
      ]);
      return { results: [
        ...(series.results || []).map(item => ({ ...item, media_type: "tv", isJapaneseAnime: true })),
        ...(movies.results || []).map(item => ({ ...item, media_type: "movie", isJapaneseAnime: true })),
      ] };
    }
    if (type === "cartoon") {
      const [series, movies] = await availableResults([
        tmdbRequest("/discover/tv", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.tv), with_original_language: "en" }),
        tmdbRequest("/discover/movie", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.movie), with_original_language: "en" }),
      ]);
      return { results: [
        ...(series.results || []).map(item => ({ ...item, media_type: "tv", isCartoon: true })),
        ...(movies.results || []).map(item => ({ ...item, media_type: "movie", isCartoon: true })),
      ] };
    }
    const mediaType = type === "tv" ? "tv" : "movie";
    const audio = window.PublicDROPAudio ? window.PublicDROPAudio.get() : "";
    if (DUBBED_LANGS.includes(audio)) return audioDiscover({ type: mediaType, page, language, lang: audio, genre: genre?.[mediaType] || "" });
    return tmdbRequest(`/discover/${mediaType}`, { language, page, sort_by: "popularity.desc", include_adult: false, without_genres: 16, with_genres: genre?.[mediaType] || "", with_original_language: audio, region: audio === "hi" ? "IN" : "", "vote_count.gte": audio ? 30 : "" });
  }

  const publicImages = ({ id, type, language = "en" }) =>
    tmdbRequest(`/${type}/${id}/images`, { include_image_language: `${language},null` });
  const publicSearch = ({ q, page = 1, language = "en-US" }) =>
    tmdbRequest("/search/multi", { query: q, page, language, include_adult: false });
  const publicDetails = ({ id, type, language = "en-US" }) => tmdbRequest(`/${type}/${id}`, {
    language,
    append_to_response: "credits,images,release_dates,content_ratings,external_ids,alternative_titles,translations,watch/providers",
    include_image_language: "en,null",
  });
  const publicRelated = ({ id, type, page = 1, language = "en-US" }) =>
    tmdbRequest(`/${type}/${id}/recommendations`, { page, language });
  const publicEpisodes = ({ id, season = 1, language = "en-US" }) =>
    tmdbRequest(`/tv/${id}/season/${season}`, { language });
  const watchProviders = ({ type, language = "en-US" }) =>
    tmdbRequest(`/watch/providers/${type}`, { language });
  const providerCatalog = ({ id, type, page = 1, region = "US", language = "en-US" }) =>
    tmdbRequest(`/discover/${type}`, {
      language,
      page,
      include_adult: false,
      sort_by: "popularity.desc",
      watch_region: region,
      with_watch_providers: id,
    });

  /* Titles for an audio language.
     1) titles originally made in that language (Bollywood for Hindi), and
     2) for Hindi / Tamil / Telugu: Hollywood titles officially released in India (cinemas or digital) or streaming in India
        (Netflix, Prime Video, Hotstar). Those are normally released with a dub. TMDB has no "audio track" field, so this is the closest signal.
     recent = released in roughly the last 5 months (the "trending now" rails). */
  const DUBBED_LANGS = config.INCLUDE_DUBBED_TITLES ? ["hi", "ta", "te"] : []; /* off: every server plays the original audio, so only titles made in the chosen language are listed */
  function audioDiscover({ type = "movie", page = 1, language = "en-US", lang = "hi", recent = false, genre = "", sort = "popularity.desc" }) {
    const mediaType = type === "tv" ? "tv" : "movie", day = 86400000, iso = ms => new Date(ms).toISOString().slice(0, 10);
    const field = mediaType === "tv" ? "first_air_date" : "primary_release_date";
    const base = { language, page, include_adult: false, sort_by: sort, without_genres: 16, with_genres: genre || "" };
    /* HITS ONLY: strict vote-count and rating floors, so only well-known titles appear.
       Big hits are the ones that get a Hindi dub, so this also keeps the Hollywood rows to titles that are very likely dubbed. */
    const hitOriginal = DUBBED_LANGS.includes(lang) ? 80 : 30;
    const original = { ...base, with_original_language: lang, region: lang === "hi" ? "IN" : "", "vote_count.gte": recent ? 10 : hitOriginal, "vote_average.gte": recent ? 5 : 5.8 };
    const dubbed = mediaType === "tv"
      ? { ...base, with_original_language: "en", watch_region: "IN", with_watch_providers: "8|119|122", with_watch_monetization_types: "flatrate", "vote_count.gte": recent ? 120 : 500, "vote_average.gte": 6.5 }
      : { ...base, with_original_language: "en", region: "IN", with_release_type: "3", "vote_count.gte": recent ? 200 : 1000, "vote_average.gte": 6.3 };
    if (recent) {
      const from = iso(Date.now() - 150 * day), to = iso(Date.now());
      original[`${field}.gte`] = from; original[`${field}.lte`] = to;
      if (mediaType === "tv") { dubbed[`${field}.gte`] = from; dubbed[`${field}.lte`] = to; } else { dubbed["release_date.gte"] = from; dubbed["release_date.lte"] = to; }
    }
    const wantDubs = DUBBED_LANGS.includes(lang);
    return availableResults([
      tmdbRequest(`/discover/${mediaType}`, original),
      wantDubs ? tmdbRequest(`/discover/${mediaType}`, dubbed) : Promise.resolve({ results: [] }),
    ]).then(([own, dub]) => {
      const a = (own.results || []), b = (dub.results || []).map(item => ({ ...item, audioDubbed: true })), seen = new Set(), out = [];
      for (let i = 0; i < Math.max(a.length, b.length); i += 1) [a[i], b[i]].forEach(item => { if (item && !seen.has(item.id)) { seen.add(item.id); out.push(item); } });
      return { ...own, results: out };
    });
  }
  const discoverAudio = args => audioDiscover({ ...args });

  /* Hollywood candidates that could have a Hindi dub: made in English, released / streaming in India, well liked. Proven afterwards by dubEvidence(). */
  function dubCandidates({ type = "movie", language = "en-US", sort = "popularity.desc" }) {
    const mediaType = type === "tv" ? "tv" : "movie";
    const base = { language, page: 1, include_adult: false, sort_by: sort, without_genres: 16, with_original_language: "en" };
    const params = mediaType === "tv"
      ? { ...base, watch_region: "IN", with_watch_providers: "8|119|122|2336", with_watch_monetization_types: "flatrate", "vote_count.gte": 300, "vote_average.gte": 6.3 }
      : { ...base, region: "IN", with_release_type: "3|4", "vote_count.gte": 500, "vote_average.gte": 6 };
    return tmdbRequest(`/discover/${mediaType}`, params).then(d => d.results || []).catch(() => []);
  }
  /* the facts used to judge one title: India release dates, Hindi/Tamil/Telugu listing, India streaming, votes, revenue */
  function dubEvidence({ id, type = "movie", language = "en-US" }) {
    return tmdbRequest(`/${type === "tv" ? "tv" : "movie"}/${id}`, { language, append_to_response: "release_dates,translations,watch/providers" });
  }

  async function animeSearch({ title }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-search?title=${encodeURIComponent(title)}`);
  }

  async function animeDetails({ anilistId }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-anime?anilistId=${encodeURIComponent(anilistId)}`);
  }

  async function animeEpisodes({ id }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-episodes?id=${encodeURIComponent(id)}`);
  }

  window.PublicDROPAPI = Object.freeze({
    animeDetails,
    publicSeries,
    publicImages,
    series: publicSeries,
    search: publicSearch,
    details: publicDetails,
    images: publicImages,
    related: publicRelated,
    episodes: publicEpisodes,
    watchProviders,
    providerCatalog,
    discoverAudio,
    dubCandidates,
    dubEvidence,
    animeSearch,
    animeEpisodes,
  });
})();
