(function () {
  "use strict";

  const config = window.PUBLICDROP_CONFIG || {};
  const sdkUrl = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";
  const guestBackupKey = "publicdrop-auth-guest-data";
  const returnRouteKey = "publicdrop-auth-return-route";
  const providerAttemptKey = "publicdrop-auth-provider-attempt";
  const profileCacheKey = "publicdrop-auth-profile";
  const initialQuery = new URLSearchParams(location.search);
  const initialHash = new URLSearchParams(location.hash.startsWith("#") ? location.hash.slice(1) : "");
  const initialAuthErrorCode = initialQuery.get("error_code") || initialHash.get("error_code") || initialQuery.get("error") || initialHash.get("error") || "";
  const initialAuthError = initialQuery.get("error_description") || initialHash.get("error_description") || initialQuery.get("error") || initialHash.get("error") || "";
  const authCallbackPending = initialQuery.has("code") || initialQuery.has("error") || initialHash.has("access_token") || initialHash.has("error");
  window.PUBLICDROP_AUTH_CALLBACK_PENDING = authCallbackPending;
  const dialog = document.querySelector("#auth-dialog");
  const accountButton = document.querySelector("#account-button");
  const accountAvatar = document.querySelector("#account-avatar");
  const guestView = document.querySelector("#auth-guest-view");
  const userView = document.querySelector("#auth-user-view");
  const form = document.querySelector("#auth-form");
  const emailInput = document.querySelector("#auth-email");
  const passwordInput = document.querySelector("#auth-password");
  const passwordToggle = document.querySelector("#auth-password-toggle");
  const forgotPasswordButton = document.querySelector("#auth-forgot-password");
  const submitButton = document.querySelector("#auth-submit");
  const modeToggle = document.querySelector("#auth-mode-toggle");
  const statusNode = document.querySelector("#auth-status");
  const profileAvatar = document.querySelector("#auth-profile-avatar");
  const profileName = document.querySelector("#auth-profile-name");
  const profileEmail = document.querySelector("#auth-profile-email");
  const signOutButton = document.querySelector("#auth-signout");
  const recoveryView = document.querySelector("#auth-recovery-view");
  const recoveryForm = document.querySelector("#auth-recovery-form");
  const recoveryInput = document.querySelector("#auth-new-password");
  const inlineActions = document.querySelector("#auth-inline-actions");

  let authMode = "signin";
  let recoveryMode = false;
  let client = null;
  let clientPromise = null;
  let currentSession = null;
  let lastSyncedUserId = "";
  let syncPromise = null;
  const progressTimers = new Map();
  const pendingProgress = new Map();

  function readArray(key) {
    try {
      const value = JSON.parse(localStorage.getItem(key) || "[]");
      return Array.isArray(value) ? value : [];
    } catch {
      return [];
    }
  }

  function setStatus(message = "", tone = "") {
    if (!statusNode) return;
    statusNode.textContent = message;
    statusNode.dataset.tone = tone;
  }

  function providerName(value) {
    const names = { google: "Google", discord: "Discord", github: "GitHub" };
    return names[String(value || "").toLowerCase()] || "Social sign-in";
  }

  /* ---------- password rules ---------- */
  const PW_RULES = [
    { label: "At least 8 characters", test: value => value.length >= 8 },
    { label: "A letter", test: value => /[A-Za-z]/.test(value) },
    { label: "A number", test: value => /\d/.test(value) },
    { label: "A special character (! @ # $ % & * …)", test: value => /[^A-Za-z0-9\s]/.test(value) },
  ];
  const passwordProblems = value => PW_RULES.filter(rule => !rule.test(String(value || ""))).map(rule => rule.label);

  function paintRules(list, value) {
    if (!list) return;
    if (!list.children.length) {
      PW_RULES.forEach(rule => { const item = document.createElement("li"); item.textContent = rule.label; list.append(item); });
    }
    [...list.children].forEach((item, index) => item.classList.toggle("is-ok", PW_RULES[index].test(String(value || ""))));
  }

  const signupRules = document.createElement("ul");
  signupRules.className = "auth-pw-rules";
  signupRules.id = "auth-pw-rules";
  signupRules.hidden = true;
  passwordInput?.closest(".auth-field")?.after(signupRules);
  paintRules(signupRules, "");
  paintRules(document.querySelector("#auth-recovery-rules"), "");
  passwordInput?.addEventListener("input", () => paintRules(signupRules, passwordInput.value));
  recoveryInput?.addEventListener("input", () => paintRules(document.querySelector("#auth-recovery-rules"), recoveryInput.value));

  function showInlineActions(actions) {
    if (!inlineActions) return;
    inlineActions.replaceChildren();
    (actions || []).forEach(action => {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = action.label;
      button.addEventListener("click", action.run);
      inlineActions.append(button);
    });
    inlineActions.hidden = !(actions && actions.length);
  }

  function friendlyAuthError(error, provider = sessionStorage.getItem(providerAttemptKey)) {
    const message = String(error?.message || error || "").replace(/\+/g, " ");
    let decoded = message;
    try {
      decoded = decodeURIComponent(message);
    } catch {
      // Keep the original provider message if it was not URI encoded.
    }
    if (/code verifier|verifier/i.test(decoded)) {
      return "Your email is verified. Please sign in with your email and password.";
    }
    if (/unable to exchange external code/i.test(decoded)) {
      return `${providerName(provider)} reached the provider, but Supabase could not exchange the login code. Re-save the matching Client ID and Client Secret in Supabase, then try again.`;
    }
    if (/access_denied|cancelled|canceled/i.test(`${initialAuthErrorCode} ${decoded}`)) {
      return `${providerName(provider)} sign-in was cancelled.`;
    }
    if (/rate limit|too many|over_email_send_rate_limit|security purposes/i.test(decoded)) {
      return "Too many attempts. Please wait a few minutes and try again.";
    }
    return decoded || "Sign-in failed. Please try again.";
  }

  /* turn a password sign-in / sign-up error into a clear message + helpful buttons */
  function explainPasswordError(error) {
    const text = String(error?.message || error || "");
    const email = emailInput.value.trim();
    if (/email not confirmed|not confirmed/i.test(text)) {
      setStatus("Please verify your email first. Open the link we sent you, then sign in.", "warning");
      showInlineActions([{ label: "Resend verification email", run: () => resendVerification(email) }]);
      return;
    }
    if (/invalid login credentials|invalid credentials/i.test(text)) {
      setStatus("That email or password is not correct. New here? Create an account.", "error");
      showInlineActions([
        { label: "Create an account", run: () => { setMode("signup"); setStatus("Fill in the details to create your account.", ""); } },
        { label: "Forgot password?", run: () => forgotPasswordButton?.click() },
      ]);
      return;
    }
    if (/already registered|already been registered|already exists/i.test(text)) {
      setMode("signin");
      setStatus("This email already has an account. Please sign in.", "warning");
      return;
    }
    if (/password/i.test(text) && /(should|least|weak|characters)/i.test(text)) {
      setStatus("Password is too weak. Use 8+ characters with a letter, a number and a special character.", "error");
      return;
    }
    setStatus(friendlyAuthError(error), "error");
  }

  async function resendVerification(email) {
    if (!email) { setStatus("Enter your email address first.", "warning"); return; }
    setBusy(true);
    setStatus("Sending a new verification email…");
    try {
      const authClient = await ensureClient();
      const { error } = await authClient.auth.resend({ type: "signup", email, options: { emailRedirectTo: redirectUrl() } });
      if (error) throw error;
      setStatus("Verification email sent. Check your inbox (and spam folder).", "success");
      showInlineActions([]);
    } catch (error) {
      setStatus(friendlyAuthError(error), "error");
    } finally {
      setBusy(false);
    }
  }

  function setBusy(busy) {
    dialog?.classList.toggle("is-busy", busy);
    dialog?.querySelectorAll("button, input").forEach(element => {
      if (!element.matches("[data-auth-close]")) {
        element.disabled = busy || (element.matches("[data-auth-provider]") && element.dataset.configured === "false");
      }
    });
  }

  async function refreshProviderAvailability() {
    try {
      const response = await fetch(`${config.SUPABASE_URL}/auth/v1/settings`, {
        headers: { apikey: config.SUPABASE_PUBLISHABLE_KEY },
      });
      if (!response.ok) return;
      const settings = await response.json();
      let enabledCount = 0;
      dialog?.querySelectorAll("[data-auth-provider]").forEach(button => {
        const enabled = Boolean(settings.external?.[button.dataset.authProvider]);
        if (enabled) enabledCount += 1;
        button.dataset.configured = String(enabled);
        button.disabled = !enabled;
        button.title = enabled ? "" : `Enable ${button.dataset.authProvider} in Supabase Authentication first`;
      });
      const hint = document.querySelector("#auth-provider-hint");
      if (hint) hint.hidden = true;
      dialog?.querySelectorAll(".auth-divider, .auth-social-grid").forEach(node => { node.hidden = enabledCount === 0; });
    } catch {
      // A settings check must never prevent email authentication.
    }
  }

  function loadSdk() {
    if (window.supabase?.createClient) return Promise.resolve(window.supabase);
    if (clientPromise) return clientPromise;
    const urls = [sdkUrl, "https://unpkg.com/@supabase/supabase-js@2/dist/umd/supabase.js", "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js"];
    const tryLoad = index => new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = urls[index];
      script.async = true;
      script.crossOrigin = "anonymous";
      script.dataset.publicdropSupabaseSdk = "true";
      script.addEventListener("load", () => (window.supabase?.createClient ? resolve(window.supabase) : reject(new Error("bad sdk"))), { once: true });
      script.addEventListener("error", () => { script.remove(); reject(new Error("load failed")); }, { once: true });
      document.head.append(script);
    });
    clientPromise = (async () => {
      for (let i = 0; i < urls.length; i += 1) {
        try { return await tryLoad(i); } catch { /* try the next host */ }
      }
      clientPromise = null;
      throw new Error("The sign-in service could not be loaded. Check your internet connection and try again.");
    })();
    return clientPromise;
  }

  function redirectUrl() {
    return `${location.origin}${location.pathname}`;
  }

  function rememberGuestData() {
    if (localStorage.getItem(guestBackupKey)) return;
    localStorage.setItem(guestBackupKey, JSON.stringify({
      favorites: readArray("publicdrop-favorites"),
      progress: readArray("publicdrop-continue-watching"),
    }));
  }

  function restoreGuestData() {
    try {
      const backup = JSON.parse(localStorage.getItem(guestBackupKey) || "null");
      if (backup) {
        localStorage.setItem("publicdrop-favorites", JSON.stringify(Array.isArray(backup.favorites) ? backup.favorites : []));
        localStorage.setItem("publicdrop-continue-watching", JSON.stringify(Array.isArray(backup.progress) ? backup.progress : []));
      } else {
        localStorage.setItem("publicdrop-favorites", "[]");
        localStorage.setItem("publicdrop-continue-watching", "[]");
      }
    } catch {
      localStorage.setItem("publicdrop-favorites", "[]");
      localStorage.setItem("publicdrop-continue-watching", "[]");
    }
    localStorage.removeItem(guestBackupKey);
    window.dispatchEvent(new CustomEvent("publicdrop:data-synced"));
  }

  function displayName(user) {
    const metadata = user?.user_metadata || {};
    return metadata.display_name || metadata.full_name || metadata.name || metadata.user_name || user?.email?.split("@")[0] || "PublicDROP viewer";
  }

  function initials(value) {
    return String(value || "G").trim().split(/\s+/).slice(0, 2).map(word => word[0]).join("").toUpperCase() || "G";
  }

  function avatarUrl(user) {
    const chosen = String(user?.user_metadata?.avatar_id || "");
    if (/^a[1-8]$/.test(chosen)) return `/assets/avatars/${chosen}.svg`;
    const value = String(user?.user_metadata?.avatar_url || user?.user_metadata?.picture || "");
    return /^https:\/\//i.test(value) ? value : "";
  }

  function paintAvatar(target, name, avatar) {
    if (!target) return;
    target.textContent = initials(name);
    if (!avatar) return;
    const image = document.createElement("img");
    image.src = avatar;
    image.alt = "";
    image.decoding = "async";
    target.replaceChildren(image);
  }

  function renderCachedProfile() {
    try {
      const profile = JSON.parse(localStorage.getItem(profileCacheKey) || "null");
      if (!profile?.name) return;
      accountButton.classList.add("is-signed-in");
      accountButton.setAttribute("aria-label", `Account: ${profile.name}`);
      accountButton.title = profile.name;
      paintAvatar(accountAvatar, profile.name, profile.avatar);
      guestView.hidden = true;
      userView.hidden = false;
      paintAvatar(profileAvatar, profile.name, profile.avatar);
      profileName.textContent = profile.name;
      profileEmail.textContent = "Restoring secure session…";
    } catch {
      localStorage.removeItem(profileCacheKey);
    }
  }

  function renderSession(session) {
    currentSession = session || null;
    const user = session?.user;
    guestView.hidden = Boolean(user);
    userView.hidden = !user || recoveryMode;
    if (recoveryView) {
      recoveryView.hidden = !(user && recoveryMode);
      if (user && recoveryMode) guestView.hidden = true;
    }
    accountButton.classList.toggle("is-signed-in", Boolean(user));
    accountButton.setAttribute("aria-label", user ? `Account: ${displayName(user)}` : "Sign in");
    accountButton.title = user ? displayName(user) : "Sign in";

    if (!user) {
      localStorage.removeItem(profileCacheKey);
      accountAvatar.innerHTML = '<svg aria-hidden="true"><use href="#i-user"></use></svg>';
      return;
    }

    const name = displayName(user);
    const avatar = avatarUrl(user);
    localStorage.setItem(profileCacheKey, JSON.stringify({ name, avatar }));
    paintAvatar(accountAvatar, name, avatar);
    paintAvatar(profileAvatar, name, avatar);
    profileName.textContent = name;
    profileEmail.textContent = user.email || "Signed in";
  }

  function restoreReturnRoute() {
    const savedRoute = sessionStorage.getItem(returnRouteKey);
    if (!savedRoute && !authCallbackPending) return;
    const url = new URL(location.href);
    ["code", "error", "error_code", "error_description"].forEach(key => url.searchParams.delete(key));
    const route = savedRoute || "#/";
    sessionStorage.removeItem(returnRouteKey);
    history.replaceState(null, "", `${url.pathname}${url.search}${route}`);
    window.PUBLICDROP_AUTH_CALLBACK_PENDING = false;
    window.dispatchEvent(new Event("hashchange"));
  }

  function mediaKey(item) {
    return `${item?.type || "movie"}:${item?.id || ""}`;
  }

  function progressKey(item) {
    return String(item?.key || `${item?.type || "movie"}:${item?.id || ""}`);
  }

  async function syncCloudData(session) {
    if (!client || !session?.user?.id) return;
    if (syncPromise) return syncPromise;
    const userId = session.user.id;
    syncPromise = (async () => {
      const [favoriteResult, progressResult] = await Promise.all([
        client.from("favorites").select("media_key,media_data"),
        client.from("watch_progress").select("media_key,progress_data,updated_at"),
      ]);
      if (favoriteResult.error) throw favoriteResult.error;
      if (progressResult.error) throw progressResult.error;

      const favoriteMap = new Map();
      (favoriteResult.data || []).forEach(row => {
        if (row.media_data) favoriteMap.set(row.media_key || mediaKey(row.media_data), row.media_data);
      });
      readArray("publicdrop-favorites").forEach(item => favoriteMap.set(mediaKey(item), item));
      const favorites = [...favoriteMap.values()].slice(0, 250);
      localStorage.setItem("publicdrop-favorites", JSON.stringify(favorites));

      const progressMap = new Map();
      (progressResult.data || []).forEach(row => {
        if (row.progress_data) progressMap.set(row.media_key || progressKey(row.progress_data), row.progress_data);
      });
      readArray("publicdrop-continue-watching").forEach(item => {
        const key = progressKey(item);
        const current = progressMap.get(key);
        if (!current || Number(item.updatedAt || 0) >= Number(current.updatedAt || 0)) progressMap.set(key, item);
      });
      const progress = [...progressMap.values()].sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0)).slice(0, 20);
      localStorage.setItem("publicdrop-continue-watching", JSON.stringify(progress));

      const favoriteRows = favorites.map(item => ({ user_id: userId, media_key: mediaKey(item), media_data: item }));
      const progressRows = progress.map(item => ({
        user_id: userId,
        media_key: progressKey(item),
        progress_data: item,
        updated_at: new Date(Number(item.updatedAt) || Date.now()).toISOString(),
      }));
      const writes = [];
      if (favoriteRows.length) writes.push(client.from("favorites").upsert(favoriteRows, { onConflict: "user_id,media_key" }));
      if (progressRows.length) writes.push(client.from("watch_progress").upsert(progressRows, { onConflict: "user_id,media_key" }));
      const results = await Promise.all(writes);
      const writeError = results.find(result => result.error)?.error;
      if (writeError) throw writeError;

      lastSyncedUserId = userId;
      window.dispatchEvent(new CustomEvent("publicdrop:data-synced"));
      setStatus("My List and Continue Watching are synced.", "success");
    })().catch(error => {
      console.warn("PublicDROP cloud sync is not ready:", error.message || error);
      setStatus("Signed in. Run the PublicDROP database setup to enable cloud sync.", "warning");
    }).finally(() => {
      syncPromise = null;
    });
    return syncPromise;
  }

  /* ---------- profile: display name, random username, avatar ---------- */
  const ADJECTIVES = ["Swift", "Brave", "Lucky", "Cosmic", "Neon", "Crimson", "Silent", "Golden", "Wild", "Mighty", "Frosty", "Turbo", "Shadow", "Sunny", "Epic", "Rapid"];
  const NOUNS = ["Falcon", "Panda", "Tiger", "Ninja", "Rocket", "Wolf", "Phoenix", "Comet", "Dragon", "Otter", "Raven", "Viper", "Voyager", "Lynx", "Pixel", "Hero"];
  const profileChecked = new Set();
  let profileBusy = false;

  function randomUsername() {
    const pick = list => list[Math.floor(Math.random() * list.length)];
    return `${pick(ADJECTIVES)}${pick(NOUNS)}${Math.floor(100 + Math.random() * 900)}`;
  }

  function cleanName(value) {
    return String(value || "").replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 30);
  }

  async function ensureProfile(session) {
    const user = session?.user;
    if (!client || !user?.id || profileBusy || profileChecked.has(user.id)) return;
    profileChecked.add(user.id);
    const meta = user.user_metadata || {};
    const patch = {};
    if (!/^[A-Za-z0-9_]{3,24}$/.test(String(meta.username || ""))) patch.username = randomUsername();
    if (!/^a[1-8]$/.test(String(meta.avatar_id || ""))) patch.avatar_id = `a${1 + Math.floor(Math.random() * 8)}`;
    if (!cleanName(meta.display_name)) {
      const base = cleanName(meta.full_name || meta.name || meta.user_name || (user.email || "").split("@")[0]) || patch.username || "Viewer";
      patch.display_name = base;
      if (!meta.full_name) patch.full_name = base;
    }
    if (!Object.keys(patch).length) return;
    profileBusy = true;
    try {
      const { error } = await client.auth.updateUser({ data: patch });
      if (error) throw error;
    } catch (error) {
      console.warn("PublicDROP profile setup skipped:", error.message || error);
    } finally {
      profileBusy = false;
    }
  }

  async function updateProfile(changes) {
    const authClient = await ensureClient();
    const data = {};
    if (changes && "name" in changes) {
      const name = cleanName(changes.name);
      if (name.length < 2) throw new Error("Please enter a name with at least 2 characters.");
      data.display_name = name;
      data.full_name = name;
    }
    if (changes && "avatar" in changes) {
      if (!/^a[1-8]$/.test(String(changes.avatar))) throw new Error("Please choose one of the avatars.");
      data.avatar_id = changes.avatar;
    }
    if (!Object.keys(data).length) return currentSession;
    const { data: result, error } = await authClient.auth.updateUser({ data });
    if (error) throw error;
    const { data: fresh } = await authClient.auth.getSession();
    if (fresh?.session) { renderSession(fresh.session); window.dispatchEvent(new CustomEvent("publicdrop:authchange", { detail: { user: fresh.session.user } })); }
    return result;
  }

  /* people who signed up with email + password must have verified their email */
  function needsVerification(user) {
    const provider = String(user?.app_metadata?.provider || "email");
    return provider === "email" && !user?.email_confirmed_at && !user?.confirmed_at;
  }

  function handleAuthEvent(event, session) {
    const wasSignedIn = Boolean(currentSession?.user);
    if (session?.user && needsVerification(session.user)) {
      currentSession = null;
      renderSession(null);
      setTimeout(() => client?.auth.signOut().catch(() => {}), 0);
      if (!dialog.open) dialog.showModal();
      setStatus("Please verify your email first. Open the link we sent you, then sign in.", "warning");
      showInlineActions([{ label: "Resend verification email", run: () => resendVerification(session.user.email) }]);
      return;
    }
    if (event === "PASSWORD_RECOVERY") {
      recoveryMode = true;
      setTimeout(() => { if (!dialog.open) dialog.showModal(); setStatus("Choose a new password to finish resetting.", "success"); }, 0);
    }
    renderSession(session);
    window.dispatchEvent(new CustomEvent("publicdrop:authchange", { detail: { user: session?.user || null } }));
    if (session?.user) {
      sessionStorage.removeItem(providerAttemptKey);
      if (event === "SIGNED_IN" || session.user.id !== lastSyncedUserId) setTimeout(() => syncCloudData(session), 0);
      setTimeout(() => ensureProfile(session), 300);
      if (authCallbackPending || sessionStorage.getItem(returnRouteKey)) setTimeout(restoreReturnRoute, 0);
    } else if (event === "SIGNED_OUT" && wasSignedIn) {
      lastSyncedUserId = "";
      restoreGuestData();
    }
  }

  async function ensureClient() {
    if (client) return client;
    const sdk = await loadSdk();
    if (client) return client;
    if (!sdk?.createClient) throw new Error("The sign-in service is unavailable.");
    client = sdk.createClient(config.SUPABASE_URL, config.SUPABASE_PUBLISHABLE_KEY, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
        flowType: "pkce",
      },
    });
    client.auth.onAuthStateChange((event, session) => handleAuthEvent(event, session));
    const { data, error } = await client.auth.getSession();
    if (error) throw error;
    renderSession(data.session);
    if (initialAuthError && !data.session) {
      restoreReturnRoute();
      if (!dialog.open) dialog.showModal();
      setStatus(friendlyAuthError(initialAuthError), "error");
      sessionStorage.removeItem(providerAttemptKey);
    }
    return client;
  }

  function setMode(mode) {
    authMode = mode === "signup" ? "signup" : "signin";
    const signingUp = authMode === "signup";
    document.querySelector("#auth-title").textContent = signingUp ? "Create your account" : "Sign in";
    submitButton.textContent = signingUp ? "Create account" : "Sign in";
    document.querySelector("#auth-switch-copy").textContent = signingUp ? "Already have an account?" : "New to PublicDROP?";
    modeToggle.textContent = signingUp ? "Sign in" : "Create an account";
    passwordInput.autocomplete = signingUp ? "new-password" : "current-password";
    signupRules.hidden = !signingUp;
    passwordInput.minLength = signingUp ? 8 : 6;
    showInlineActions([]);
    const nameField = document.querySelector("#auth-name-field");
    if (nameField) nameField.hidden = !signingUp;
    if (forgotPasswordButton) forgotPasswordButton.hidden = signingUp;
    setStatus();
  }

  async function openDialog() {
    if (!dialog.open) dialog.showModal();
    setStatus("Loading secure sign-in…");
    try {
      await ensureClient();
      await refreshProviderAvailability();
      setStatus(currentSession?.user ? "My List and Continue Watching sync automatically." : "");
      if (!currentSession?.user) setTimeout(() => emailInput.focus(), 40);
    } catch (error) {
      setStatus(error.message || "Sign-in is temporarily unavailable.", "error");
    }
  }

  async function saveFavoriteChange(detail) {
    if (!client || !currentSession?.user || !detail?.movie) return;
    const key = mediaKey(detail.movie);
    const query = client.from("favorites");
    const result = detail.saved
      ? await query.upsert({ user_id: currentSession.user.id, media_key: key, media_data: detail.movie }, { onConflict: "user_id,media_key" })
      : await query.delete().eq("user_id", currentSession.user.id).eq("media_key", key);
    if (result.error) console.warn("Favorite cloud sync failed:", result.error.message);
  }

  async function flushProgress(key) {
    progressTimers.delete(key);
    const detail = pendingProgress.get(key);
    pendingProgress.delete(key);
    if (!client || !currentSession?.user || !detail) return;
    const query = client.from("watch_progress");
    const result = detail.removed
      ? await query.delete().eq("user_id", currentSession.user.id).eq("media_key", key)
      : await query.upsert({
        user_id: currentSession.user.id,
        media_key: key,
        progress_data: detail.entry,
        updated_at: new Date(Number(detail.entry?.updatedAt) || Date.now()).toISOString(),
      }, { onConflict: "user_id,media_key" });
    if (result.error) console.warn("Watch progress cloud sync failed:", result.error.message);
  }

  accountButton?.addEventListener("click", openDialog);
  dialog?.querySelector("[data-auth-close]")?.addEventListener("click", () => dialog.close());
  dialog?.addEventListener("click", event => {
    if (event.target === dialog) dialog.close();
  });
  modeToggle?.addEventListener("click", () => setMode(authMode === "signin" ? "signup" : "signin"));
  passwordToggle?.addEventListener("click", () => {
    const showing = passwordInput.type === "text";
    passwordInput.type = showing ? "password" : "text";
    passwordToggle.setAttribute("aria-pressed", String(!showing));
    passwordToggle.setAttribute("aria-label", showing ? "Show password" : "Hide password");
  });
  forgotPasswordButton?.addEventListener("click", async () => {
    const email = emailInput.value.trim();
    if (!email || !emailInput.checkValidity()) {
      setStatus("Enter your email address first, then choose Forgot password.", "warning");
      emailInput.focus();
      return;
    }
    setBusy(true);
    setStatus("Preparing your secure reset link…");
    try {
      const authClient = await ensureClient();
      const { error } = await authClient.auth.resetPasswordForEmail(email, { redirectTo: redirectUrl() });
      if (error) throw error;
      setStatus("If an account exists for this email, a password reset link is on its way. Check your inbox and spam folder.", "success");
    } catch (error) {
      setStatus(error.message || "Could not send the reset email.", "error");
    } finally {
      setBusy(false);
    }
  });

  form?.addEventListener("submit", async event => {
    event.preventDefault();
    showInlineActions([]);
    if (authMode === "signup") {
      const problems = passwordProblems(passwordInput.value);
      if (problems.length) {
        setStatus(`Choose a stronger password. Missing: ${problems.join(", ").toLowerCase()}.`, "error");
        passwordInput.focus();
        return;
      }
    }
    setBusy(true);
    setStatus(authMode === "signup" ? "Creating your account…" : "Signing you in…");
    try {
      rememberGuestData();
      const authClient = await ensureClient();
      const credentials = { email: emailInput.value.trim(), password: passwordInput.value };
      const typedName = String(document.querySelector("#auth-name")?.value || "").trim().replace(/\s+/g, " ").slice(0, 30);
      const signUpData = typedName ? { full_name: typedName, display_name: typedName } : {};
      const result = authMode === "signup"
        ? await authClient.auth.signUp({ ...credentials, options: { emailRedirectTo: redirectUrl(), data: signUpData } })
        : await authClient.auth.signInWithPassword(credentials);
      if (result.error) throw result.error;
      if (authMode === "signup" && result.data.user && Array.isArray(result.data.user.identities) && result.data.user.identities.length === 0) {
        localStorage.removeItem(guestBackupKey);
        setMode("signin");
        setStatus("This email already has an account. Please sign in.", "warning");
      } else if (authMode === "signup" && !result.data.session) {
        localStorage.removeItem(guestBackupKey);
        setStatus("Account created! We sent a verification link to your email. Open it to activate your account, then sign in.", "success");
        showInlineActions([{ label: "Resend verification email", run: () => resendVerification(credentials.email) }]);
        passwordInput.value = "";
        paintRules(signupRules, "");
      } else {
        setStatus("Signed in. Your library is syncing now.", "success");
        form.reset();
      }
    } catch (error) {
      if (!currentSession?.user) localStorage.removeItem(guestBackupKey);
      explainPasswordError(error);
    } finally {
      setBusy(false);
    }
  });

  /* choose a new password after clicking the reset link in the email */
  recoveryForm?.addEventListener("submit", async event => {
    event.preventDefault();
    const problems = passwordProblems(recoveryInput.value);
    if (problems.length) {
      setStatus(`Choose a stronger password. Missing: ${problems.join(", ").toLowerCase()}.`, "error");
      return;
    }
    setBusy(true);
    setStatus("Saving your new password…");
    try {
      const authClient = await ensureClient();
      const { error } = await authClient.auth.updateUser({ password: recoveryInput.value });
      if (error) throw error;
      recoveryMode = false;
      recoveryForm.reset();
      renderSession(currentSession);
      setStatus("Password updated. You are signed in.", "success");
    } catch (error) {
      setStatus(friendlyAuthError(error), "error");
    } finally {
      setBusy(false);
    }
  });

  dialog?.querySelectorAll("[data-auth-provider]").forEach(button => {
    button.addEventListener("click", async () => {
      setBusy(true);
      setStatus(`Opening ${button.textContent.replace("Continue with ", "").trim()}…`);
      try {
        rememberGuestData();
        sessionStorage.setItem(returnRouteKey, location.hash || "#/");
        sessionStorage.setItem(providerAttemptKey, button.dataset.authProvider);
        const authClient = await ensureClient();
        const { error } = await authClient.auth.signInWithOAuth({
          provider: button.dataset.authProvider,
          options: { redirectTo: redirectUrl() },
        });
        if (error) throw error;
      } catch (error) {
        if (!currentSession?.user) localStorage.removeItem(guestBackupKey);
        setStatus(friendlyAuthError(error, button.dataset.authProvider), "error");
        sessionStorage.removeItem(providerAttemptKey);
        setBusy(false);
      }
    });
  });

  signOutButton?.addEventListener("click", async () => {
    setBusy(true);
    setStatus("Signing out…");
    try {
      const authClient = await ensureClient();
      const { error } = await authClient.auth.signOut({ scope: "local" });
      if (error) throw error;
      dialog.close();
    } catch (error) {
      setStatus(error.message || "Could not sign out.", "error");
    } finally {
      setBusy(false);
    }
  });

  window.addEventListener("publicdrop:favoritechange", event => saveFavoriteChange(event.detail));
  window.addEventListener("publicdrop:progresschange", event => {
    if (!currentSession?.user || !event.detail?.key) return;
    const key = String(event.detail.key);
    pendingProgress.set(key, event.detail);
    clearTimeout(progressTimers.get(key));
    if (event.detail.removed) flushProgress(key);
    else progressTimers.set(key, setTimeout(() => flushProgress(key), 12000));
  });
  window.addEventListener("publicdrop:progress-flush", () => [...pendingProgress.keys()].forEach(flushProgress));
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") [...pendingProgress.keys()].forEach(flushProgress);
  });

  window.PublicDROPAuth = Object.freeze({
    open: openDialog,
    getSession: () => currentSession,
    sync: () => syncCloudData(currentSession),
    getClient: ensureClient,
    updateProfile,
    displayName,
    avatarUrl,
  });

  renderCachedProfile();
  setMode("signin");
  if (authCallbackPending) {
    ensureClient().catch(error => {
      restoreReturnRoute();
      openDialog();
      setStatus(friendlyAuthError(error), error && /verifier/i.test(String(error.message || error)) ? "success" : "error");
    });
  } else {
    let authWarmupStarted = false;
    const warmAuth = () => {
      if (authWarmupStarted) return;
      authWarmupStarted = true;
      ensureClient().catch(() => {});
    };
    if (location.hash.startsWith("#/watch/")) {
      window.addEventListener("load", () => setTimeout(warmAuth, 10000), { once: true });
    } else {
      const warmAfterUi = () => {
        // Leave the network and main thread entirely to the first hero/card paint.
        // Cached identity keeps the account indicator immediate during this pause.
        setTimeout(() => {
          if ("requestIdleCallback" in window) window.requestIdleCallback(warmAuth, { timeout: 1000 });
          else warmAuth();
        }, 1200);
      };
      if (window.PUBLICDROP_CRITICAL_UI_READY) warmAfterUi();
      else window.addEventListener("publicdrop:critical-ui-ready", warmAfterUi, { once: true });
      // Recovery path if a catalog request hangs or the route cannot render.
      window.addEventListener("load", () => setTimeout(warmAuth, 3000), { once: true });
    }
  }
})();
