(function () {
  "use strict";

  const app = document.querySelector("#app");
  const api = window.PublicDROPAPI;
  const config = window.PUBLICDROP_CONFIG;
  const image = (path, size = "w500") => path ? `${config.IMAGE_BASE_URL}/${size}${path}` : "";
  const accents = ["#e50914", "#2fd072", "#3b82f6", "#8b5cf6", "#ec4899", "#f97316", "#eab308", "#06b6d4"];
  const localeMap = { en: "en-US", es: "es-ES", fr: "fr-FR", de: "de-DE", hi: "hi-IN", ja: "ja-JP", ko: "ko-KR" };
  const genreMap = { 28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy", 80: "Crime", 99: "Documentary", 18: "Drama", 10751: "Family", 14: "Fantasy", 36: "History", 27: "Horror", 10402: "Music", 9648: "Mystery", 10749: "Romance", 878: "Sci-Fi", 53: "Thriller", 10752: "War", 37: "Western", 10759: "Action & Adventure", 10765: "Sci-Fi & Fantasy" };
  const genreFilters = Object.freeze([
    {key:"action",label:"Action",movie:[28],tv:[28,10759]},
    {key:"adventure",label:"Adventure",movie:[12],tv:[10759]},
    {key:"animation",label:"Animation",movie:[16],tv:[16]},
    {key:"comedy",label:"Comedy",movie:[35],tv:[35]},
    {key:"crime",label:"Crime",movie:[80],tv:[80]},
    {key:"documentary",label:"Documentary",movie:[99],tv:[99]},
    {key:"drama",label:"Drama",movie:[18],tv:[18]},
    {key:"family",label:"Family",movie:[10751],tv:[10751]},
    {key:"fantasy",label:"Fantasy",movie:[14],tv:[10765]},
    {key:"history",label:"History",movie:[36],tv:[]},
    {key:"horror",label:"Horror",movie:[27],tv:[]},
    {key:"music",label:"Music",movie:[10402],tv:[]},
    {key:"mystery",label:"Mystery",movie:[9648],tv:[9648]},
    {key:"romance",label:"Romance",movie:[10749],tv:[]},
    {key:"scifi",label:"Sci-Fi",movie:[878],tv:[10765]},
    {key:"thriller",label:"Thriller",movie:[53],tv:[53]},
    {key:"war",label:"War",movie:[10752],tv:[10768]},
    {key:"western",label:"Western",movie:[37],tv:[37]},
    {key:"reality",label:"Reality",movie:[],tv:[10764]},
    {key:"kids",label:"Kids",movie:[],tv:[10762]},
    {key:"news",label:"News",movie:[],tv:[10763]},
    {key:"soap",label:"Soap",movie:[],tv:[10766]},
    {key:"talk",label:"Talk",movie:[],tv:[10767]},
  ]);
  const categoryIcons = { Movies: "🎬", Series: "📺", Anime: "🌊", Cartoons: "✨", Action: "⚡", Comedy: "😄", Horror: "◉", "Sci-Fi": "✦", Romance: "♥" };
  const promoScriptUrl = "//nb.sepoygalliot.com/r3ibxTQLWhTm/141505";
  // Promo pop-ups are OFF by default; they only run if the visitor turns them on this session.
  const promoOnKey = "publicdrop-promo-on";
  let promoEnabled = sessionStorage.getItem(promoOnKey) === "1";
  let promoRuntimeLoaded = false;

  function syncPromoRoute() {
    loadPromoScript();
    return true;
  }

  function loadPromoScript() {
    // The vendor removes its own script tag after loading. Track the runtime
    // too, so navigating between pages does not install duplicate ad handlers.
    if (!promoEnabled || promoRuntimeLoaded || document.querySelector("#publicdrop-promo-script")) return;
    const script = document.createElement("script");
    script.id = "publicdrop-promo-script";
    script.dataset.cfasync = "false";
    script.async = true;
    script.type = "text/javascript";
    script.src = promoScriptUrl;
    promoRuntimeLoaded = true;
    (document.body || document.documentElement).appendChild(script);
  }

  const storage = {
    get(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } },
    set(key, value) { localStorage.setItem(key, JSON.stringify(value)); },
  };

  const state = {
    theme: window.PDTheme ? window.PDTheme.effective().theme : storage.get("publicdrop-theme", "dark"),
    accent: window.PDTheme ? window.PDTheme.effective().accent : storage.get("publicdrop-accent", "#e50914"),
    language: storage.get("publicdrop-language", config.DEFAULT_LANGUAGE),
    favorites: storage.get("publicdrop-favorites", []),
    history: storage.get("publicdrop-history", []),
    cache: new Map(),
    logoCache: new Map(Object.entries(storage.get("publicdrop-logo-cache", {}))),
    logoRequests: new Map(),
    animeEntries: new Map(),
    playbackMetadata: new Map(),
  };
  let heroSliderTimer;
  let playerBridgeCleanup;
  let watchPlayerToken=0;
  let watchPlaybackServer=1;
  let watchPlaybackContext=null;
  let watchPythonFrame=null;
  let playerScriptPromise;

  function ensurePlayerScript() {
    if (window.PublicDROPStaticPlayer) return Promise.resolve(window.PublicDROPStaticPlayer);
    if (playerScriptPromise) return playerScriptPromise;
    playerScriptPromise = new Promise((resolve, reject) => {
      const script=document.createElement("script");
      script.src="./js/player.js?v=hi2";
      script.async=true;
      script.dataset.publicdropPlayerScript="true";
      script.addEventListener("load",()=>window.PublicDROPStaticPlayer?resolve(window.PublicDROPStaticPlayer):reject(new Error("The video player could not initialize.")),{once:true});
      script.addEventListener("error",()=>reject(new Error("The video player could not be loaded.")),{once:true});
      document.head.append(script);
    }).catch(error=>{
      playerScriptPromise=null;
      throw error;
    });
    return playerScriptPromise;
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
  }

  function mediaType(item, fallback = "movie") {
    if(item.media_type==="movie"||item.media_type==="tv")return item.media_type;
    if(fallback==="movie"||fallback==="tv")return fallback;
    if(item.type==="movie"||item.type==="tv")return item.type;
    return item.name?"tv":"movie";
  }
  function sizedArtwork(url, size = "w500") {
    const value=String(url||"");
    if(!value)return "";
    const tmdbPrefix=`${config.IMAGE_BASE_URL}/`;
    if(!value.startsWith(tmdbPrefix))return value;
    return value.replace(new RegExp(`^${tmdbPrefix.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?:original|w\\d+)/`),`${tmdbPrefix}${size}/`);
  }
  function normalize(item, fallback) {
    const type = mediaType(item, fallback);
    const key = `${type}:${Number(item.id)}`;
    const logoPath = item.logo_path || window.PUBLICDROP_LOGOS?.[key];
    const poster=item.poster||image(item.poster_path);
    const backdrop=item.backdrop||image(item.backdrop_path,"w1280");
    const normalizedGenres=(item.genre_ids||item.genres||[]).map(genre=>Number(genre.id??genre)).filter(Number.isFinite);
    return {
      id: Number(item.id), type, title: item.title || item.name || "Untitled",
      tmdbId: Number(item.tmdbId || item.tmdb_id || (!item.anilistId ? item.id : 0)) || 0,
      anilistId: Number(item.anilistId || item.anilist_id || 0) || 0,
      malId: Number(item.malId || item.mal_id || 0) || 0,
      anidapId: item.anidapId || item.anidap_id || "",
      poster, backdrop,
      cardArtwork:item.cardArtwork||(item.backdrop_path?image(item.backdrop_path,"w500"):sizedArtwork(backdrop,"w500"))||sizedArtwork(poster,"w500"),
      year: item.year || (item.release_date || item.first_air_date || "").slice(0, 4) || "—",
      rating: Number(item.vote_average ?? item.rating ?? 0), overview: item.overview || "",
      popularity: Number(item.popularity || 0),
      originalLanguage: item.original_language || item.originalLanguage || "",
      dubbed: Boolean(item.audioDubbed || item.dubbed),
      spokenLanguages: (item.spoken_languages || item.spokenLanguages || []).map(l => (l && l.iso_639_1) || l).filter(Boolean),
      genres: normalizedGenres,
      isAnime: Boolean(item.isJapaneseAnime || item.isAnime || (normalizedGenres.includes(16) && (item.original_language === "ja" || (item.origin_country || []).includes("JP")))),
      isCartoon: Boolean(item.isCartoon || (normalizedGenres.includes(16) && !(item.isJapaneseAnime || item.isAnime || item.original_language === "ja" || (item.origin_country || []).includes("JP")))),
      runtime: Number(item.runtime || (item.episode_run_time || [])[0] || 0),
      seasons: Number(item.number_of_seasons || item.seasons || 0), episodes: Number(item.number_of_episodes || item.episodes || 0),
      status: item.status || "", tagline: item.tagline || "",
      logo: item.logo || state.logoCache.get(key) || (logoPath ? image(logoPath, "w300") : ""),
    };
  }
  function watchLink(movie, options = {}) {
    const m=normalize(movie,movie.type);
    const isAnime=Boolean(m.isAnime);
    const type=isAnime?"anime":m.type;
    const id=isAnime?(m.anilistId||m.tmdbId||m.id):(m.tmdbId||m.id);
    const query=new URLSearchParams();
    if(type!=="movie"){
      query.set("season",String(options.season||1));
      query.set("episode",String(options.episode||1));
    }
    if(type==="anime"){
      query.set("dub",options.dubType==="dub"?"dub":"sub");
      if(!m.anilistId){
        query.set("isTmdb","1");
        query.set("tmdbType",m.type);
      }
    }
    const suffix=query.toString();
    return `#/watch/${type}/${encodeURIComponent(id)}${suffix?`?${suffix}`:""}`;
  }
  function playbackMetadataKey(type,id){return `${type}:${String(id)}`;}
  function rememberPlaybackMetadata(raw,movie,type,id,logo){
    if(type!=="movie"&&type!=="tv")return;
    const playerType=movie.isAnime?"anime":type;
    const playbackId=movie.isAnime?(Number(movie.anilistId)||Number(movie.tmdbId)||Number(id)):(Number(movie.tmdbId)||Number(id));
    const tmdbId=Number(movie.tmdbId||(movie.isAnime?raw.tmdbId:0)||id)||0;
    if(!playbackId)return;
    const alternativeTitles=[...(raw.alternative_titles?.titles||[]),...(raw.alternative_titles?.results||[])].map(item=>item?.title).filter(Boolean);
    const originalTitle=raw.original_title||raw.original_name||movie.title;
    const allTitles=[...new Set([movie.title,originalTitle,...alternativeTitles].filter(Boolean))];
    const metadata={
      title:movie.title,
      originalTitle,
      allTitles,
      year:movie.year,
      tmdbId,
      anilistId:Number(movie.anilistId||raw.anilistId)||0,
      malId:Number(movie.malId||raw.malId)||0,
      anidapId:movie.anidapId||raw.anidapId||"",
      imdbId:raw.imdb_id||raw.external_ids?.imdb_id||null,
      poster:movie.poster||null,
      backdrop:movie.backdrop||null,
      logo:logo||movie.logo||null,
      overview:movie.overview||raw.overview||"",
      genres:(raw.genres||[]).map(genre=>genre.name).filter(Boolean),
      genreIds:(raw.genres||[]).map(genre=>Number(genre.id)).filter(Number.isFinite),
      isCartoon:Boolean(movie.isCartoon),
      rating:Number(movie.rating||raw.vote_average||0),
      runtime:Number(movie.runtime||raw.runtime||(raw.episode_run_time||[])[0]||0),
      seasons:Number(movie.seasons||raw.number_of_seasons||0),
      episodes:Number(movie.episodes||raw.number_of_episodes||0),
      type:playerType,
    };
    state.playbackMetadata.set(playbackMetadataKey(playerType,playbackId),metadata);
    try{sessionStorage.setItem(`publicdrop-player-meta:${playbackMetadataKey(playerType,playbackId)}`,JSON.stringify(metadata));}catch{}
  }
  function clearPlayerBridge(){
    if(typeof playerBridgeCleanup==="function")playerBridgeCleanup();
    playerBridgeCleanup=undefined;
    watchPythonFrame=null;
  }
  function pythonEmbedOrigin(){
    try{return new URL(String(config.VUMETO_EMBED_BASE_URL||config.PYTHON_EMBED_BASE_URL||""),location.href).origin;}catch{return "";}
  }
  function embeddedProgressKey(type,id,season,episode){
    return `publicdrop_progress_${type}_${id}_${type==="movie"?0:season}_${type==="movie"?0:episode}`;
  }
  function embeddedResumePosition(context){
    if(!context)return 0;
    const key=embeddedProgressKey(context.type,context.id,context.season,context.episode);
    const direct=Number(localStorage.getItem(key));
    if(direct>5)return direct;
    const entry=continueWatchingEntries().find(item=>item.key===`${context.type}:${context.id}`
      && Number(item.season||0)===Number(context.type==="movie"?0:context.season)
      && Number(item.episode||0)===Number(context.type==="movie"?0:context.episode));
    return Number(entry?.currentTime)||0;
  }
  function persistEmbeddedProgress(payload){
    const context=watchPlaybackContext;
    if(!context||!payload)return;
    const season=context.type==="movie"?0:Number(context.season)||1;
    const episode=context.type==="movie"?0:Number(context.episode)||1;
    if(String(payload.type)!==String(context.type)||String(payload.id)!==String(context.id)
      ||Number(payload.season||0)!==season||Number(payload.episode||0)!==episode)return;
    const currentTime=Number(payload.currentTime);
    const duration=Number(payload.duration);
    if(!Number.isFinite(currentTime)||!Number.isFinite(duration)||duration<=0)return;
    const key=`${context.type}:${context.id}`;
    const progressKey=embeddedProgressKey(context.type,context.id,season,episode);
    const entries=storage.get("publicdrop-continue-watching",[]);
    const remaining=Array.isArray(entries)?entries.filter(item=>item?.key!==key):[];
    if(payload.completed||duration-currentTime<=15||currentTime/duration>=.98){
      localStorage.removeItem(progressKey);
      storage.set("publicdrop-continue-watching",remaining);
      window.dispatchEvent(new CustomEvent("publicdrop:progresschange",{detail:{key,removed:true}}));
      return;
    }
    if(currentTime<5)return;
    const metadata={...(payload.metadata||{}),...(context.metadata||{}),type:context.type};
    const entry={
      key,type:context.type,id:String(context.id),season,episode,
      dub:context.search?.get?.("dub")==="dub"?"dub":"sub",
      isTmdb:context.search?.get?.("isTmdb")==="1",
      tmdbType:context.search?.get?.("tmdbType")||"tv",
      title:metadata.title||"Continue watching",year:metadata.year||"",
      poster:metadata.poster||"",backdrop:metadata.backdrop||"",logo:metadata.logo||"",
      currentTime,duration,updatedAt:Date.now(),metadata,
    };
    localStorage.setItem(progressKey,String(currentTime));
    storage.set("publicdrop-continue-watching",[entry,...remaining].slice(0,20));
    window.dispatchEvent(new CustomEvent("publicdrop:progresschange",{detail:{key,entry,removed:false}}));
  }
  window.addEventListener("message",event=>{
    if(!watchPythonFrame||event.source!==watchPythonFrame.contentWindow||event.origin!==pythonEmbedOrigin())return;
    // Vumeto documents "gaia:" event names; older builds used "publicdrop:". Accept both.
    const messageType=String(event.data?.type||"").replace(/^gaia:/,"publicdrop:");
    if(messageType==="publicdrop:embed-episode-change"&&event.data?.version===1){
      const payload=event.data.payload,context=watchPlaybackContext;
      if(!context||context.type!=="tv"||String(payload?.id)!==String(context.id)||payload?.type!==context.type)return;
      if(!Number.isInteger(payload.season)||payload.season<1||!Number.isInteger(payload.episode)||payload.episode<1)return;
      switchWatchEpisode(payload.season,payload.episode);
      return;
    }
    if(messageType!=="publicdrop:playback-progress"||event.data?.version!==1)return;
    persistEmbeddedProgress(event.data.payload);
  });
  function movieKey(movie) { return `${movie.type}:${movie.id}`; }
  // Only successful catalogue responses may supply recommendation fallbacks.
  function cachedCatalogItems() {
    return [...new Map([...state.cache.entries()]
      .filter(([key,value])=>key.startsWith("catalog:") && Array.isArray(value))
      .flatMap(([,value])=>value).map(item=>[movieKey(item),item])).values()];
  }

  function isSaved(movie) { return state.favorites.some(item => movieKey(item) === movieKey(movie)); }
  function audioCode() { return window.PublicDROPAudio ? window.PublicDROPAudio.get() : "en"; }
  function locale() { return localeMap[state.language] || "en-US"; }

  async function cached(key, loader) {
    if (state.cache.has(key)) return state.cache.get(key);
    const promise = loader().catch(error => { state.cache.delete(key); throw error; });
    state.cache.set(key, promise);
    return promise;
  }
  function genreOptionsFor(type) {
    const mediaTypes=type==="movie"?["movie"]:type==="tv"?["tv"]:["movie","tv"];
    const options=genreFilters.filter(option=>(type!=="movie"&&type!=="tv"||option.key!=="animation")
      && mediaTypes.some(mediaType=>option[mediaType].length));
    return type==="tv"?options.filter(option=>option.key==="action"||option.key==="thriller"):options;
  }
  function selectedGenreFor(type, value) {
    const requested=String(value||"").toLowerCase();
    if(!requested)return null;
    return genreOptionsFor(type).find(option=>option.key===requested
      || [...option.movie,...option.tv].some(id=>String(id)===requested))||null;
  }
  function itemMatchesGenre(item,genre) {
    if(!genre)return true;
    const ids=item.type==="tv"?genre.tv:genre.movie;
    return ids.some(id=>item.genres.includes(id));
  }
  function genreApiFilter(type,genre) {
    if(!genre)return null;
    return type==="movie"?{movie:genre.movie[0]||0,tv:0}
      :type==="tv"?{movie:0,tv:genre.tv[0]||0}
      :{movie:genre.movie[0]||0,tv:genre.tv[0]||0};
  }
  async function catalog(type, page = 1, genre = null) {
    const genreKey=genre?.key||"all";
    const cacheKey=`catalog:${type}:${genreKey}:${page}:${locale()}:${audioCode()}`;
    if(state.cache.has(cacheKey)) return state.cache.get(cacheKey);
    let data;
    try {
      data = await api.publicSeries({ type, page, language: locale(), genre:genreApiFilter(type,genre) });
    } catch {
      try { data = await api.series({ type, page, language: locale(), genre:genreApiFilter(type,genre) }); }
      catch {
        throw new Error("The catalogue is temporarily unavailable. Please try again.");
      }
    }
    const normalized=(data.results || [])
      .filter(item => item.poster_path || item.poster)
      .map(item => normalize(item, type === "anime" || type === "cartoon" ? undefined : type))
      .filter(item => matchesCatalog(item, type)&&itemMatchesGenre(item,genre));
    state.cache.set(cacheKey,normalized);
    return normalized;
  }
  async function catalogBatch(type, pages = 5, genre = null) {
    const results = await Promise.allSettled(Array.from({length:pages},(_,index)=>catalog(type,index+1,genre)));
    const items=results.filter(result=>result.status==="fulfilled").flatMap(result=>result.value);
    if(!items.length){const failure=results.find(result=>result.status==="rejected");if(failure)throw failure.reason;}
    return [...new Map(items.map(item=>[movieKey(item),item])).values()];
  }

  function hydrateCardLogo(cardElement) {
    const logo=cardElement?.querySelector(".card-logo.fallback-logo");
    if(!logo||cardElement.dataset.logoRequested==="1")return;
    cardElement.dataset.logoRequested="1";
    let item;
    try{item=normalize(JSON.parse(cardElement.dataset.preview),JSON.parse(cardElement.dataset.preview).type);}catch{return;}
    const key=movieKey(item);
    const cachedLogo=state.logoCache.get(key);
    const request=cachedLogo
      ?Promise.resolve(cachedLogo)
      :state.logoRequests.get(key)||api.publicImages({id:item.id,type:item.type,language:"en"}).then(data=>{
        const logos=(data.logos||[]).sort((a,b)=>(b.vote_average||0)-(a.vote_average||0));
        const selected=logos.find(entry=>entry.iso_639_1==="en")||logos[0];
        if(!selected)return "";
        const url=image(selected.file_path,"w300");
        state.logoCache.set(key,url);
        storage.set("publicdrop-logo-cache",Object.fromEntries(state.logoCache));
        return url;
      }).catch(()=>"").finally(()=>state.logoRequests.delete(key));
    if(!cachedLogo&&!state.logoRequests.has(key))state.logoRequests.set(key,request);
    request.then(url=>{
      if(!url)return;
      document.querySelectorAll(`.media-card[data-key="${CSS.escape(key)}"] .card-logo`).forEach(node=>{
        node.dataset.fallbackLogo=node.dataset.fallbackLogo||node.src;
        node.src=url;
        node.classList.remove("fallback-logo");
        node.classList.add("official-logo");
      });
    });
  }

  function svg(id) { return `<svg aria-hidden="true"><use href="#${id}"></use></svg>`; }
  function titleLogoData(movie) {
    const words=String(movie.title||"Untitled").trim().split(/\s+/);
    const pivot=words.length>2?Math.ceil(words.length/2):words.length;
    const lines=words.length>2?[words.slice(0,pivot).join(" "),words.slice(pivot).join(" ")]:[words.join(" ")];
    const accent=["#ffffff","#f5d06f","#ff4458","#b9e6ff"][Math.abs(Number(movie.id)||0)%4];
    const family=["Arial Black,Arial,sans-serif","Impact,Arial,sans-serif","Georgia,serif"][Math.abs(Number(movie.id)||0)%3];
    const text=lines.map((line,index)=>`<text x="12" y="${lines.length===1?72:46+index*43}" fill="${accent}" font-family="${family}" font-size="${lines.length===1?48:38}" font-weight="900" letter-spacing="-1.5" paint-order="stroke" stroke="rgba(0,0,0,.72)" stroke-width="4">${escapeHTML(line.toUpperCase())}</text>`).join("");
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="430" height="105" viewBox="0 0 430 105">${text}</svg>`)}`;
  }
  function cardPlaceholderData(movie) {
    const title=String(movie.title||"PublicDROP").replace(/[&<>"']/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}[char]));
    const hue=Math.abs(Number(movie.id)||0)%360;
    const artwork=`<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360"><defs><linearGradient id="g" x1="0" y1="1" x2="1" y2="0"><stop stop-color="#07080b"/><stop offset=".65" stop-color="hsl(${hue} 38% 18%)"/><stop offset="1" stop-color="#32070c"/></linearGradient><radialGradient id="r"><stop stop-color="#e50914" stop-opacity=".28"/><stop offset="1" stop-color="#e50914" stop-opacity="0"/></radialGradient></defs><rect width="640" height="360" fill="url(#g)"/><circle cx="510" cy="55" r="250" fill="url(#r)"/><path d="M-30 340 260 20 690 310" fill="none" stroke="#fff" stroke-opacity=".06" stroke-width="44"/><text x="320" y="174" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif" font-size="34" font-weight="800">${title}</text><text x="320" y="211" text-anchor="middle" fill="#e50914" font-family="Arial,sans-serif" font-size="15" font-weight="900" letter-spacing="5">PUBLICDROP</text></svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(artwork)}`;
  }
  function card(movie, compact = false, options = {}) {
    const m = normalize(movie, movie.type);
    const saved=isSaved(m);
    const duration = m.type === "movie" && m.runtime ? `${Math.floor(m.runtime / 60)}h ${m.runtime % 60}m` : m.type === "tv" && m.seasons ? `${m.seasons} season${m.seasons===1?"":"s"}` : m.isAnime ? "Japanese Anime" : m.isCartoon ? "Cartoon" : m.type === "tv" ? "Series" : "Movie";
    const fallbackLogo=titleLogoData(m);
    const displayLogo=m.logo||fallbackLogo;
    const fallbackArtwork=sizedArtwork(m.poster,"w500");
    const placeholderArtwork=cardPlaceholderData(m);
    const phoneLayout=window.matchMedia?.("(max-width: 520px)").matches;
    const primaryArtwork=(phoneLayout?sizedArtwork(m.poster,"w342"):m.cardArtwork)||fallbackArtwork||placeholderArtwork;
    const priority=Boolean(options.priority);
    return `<article class="media-card" data-key="${movieKey(m)}" data-preview="${escapeHTML(JSON.stringify(m))}">
      <a href="#/detail/${m.type}/${m.id}" aria-label="View ${escapeHTML(m.title)}">
        <div class="poster-shell card-art-shell">
          <img class="card-art" src="${escapeHTML(primaryArtwork)}" data-fallback-src="${escapeHTML(primaryArtwork!==fallbackArtwork?fallbackArtwork:"")}" data-placeholder-src="${escapeHTML(placeholderArtwork)}" alt="${escapeHTML(m.title)}" loading="${priority?"eager":"lazy"}" fetchpriority="${priority?"high":"auto"}" decoding="async">
          <span class="poster-shade"></span>
          ${compact ? "" : `<span class="quality-badge">HD</span>`}
          <img class="card-logo ${m.logo?"official-logo":"fallback-logo"}" src="${escapeHTML(displayLogo)}" data-fallback-logo="${escapeHTML(m.logo?fallbackLogo:"")}" alt="${escapeHTML(m.title)} logo" loading="${priority?"eager":"lazy"}" decoding="async">
          <div class="card-copy"><span class="card-meta"><span>${escapeHTML(m.year)} · ${escapeHTML(duration)}</span><span class="card-rating">${svg("i-star")}${m.rating.toFixed(1)}</span></span></div>
        </div>
      </a>
      ${compact ? "" : `<button class="favorite-button ${saved ? "saved" : ""}" data-favorite='${escapeHTML(JSON.stringify(m))}' aria-label="${saved ? "Remove from favorites" : "Add to favorites"}" aria-pressed="${saved}" title="${saved ? "Saved to My List" : "Add to My List"}">${svg("i-heart")}</button>`}
    </article>`;
  }
  function continueTime(value) {
    const total=Math.max(0,Math.floor(Number(value)||0));
    const hours=Math.floor(total/3600);
    const minutes=Math.floor((total%3600)/60);
    const seconds=total%60;
    return hours?`${hours}:${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`:`${minutes}:${String(seconds).padStart(2,"0")}`;
  }
  function continueWatchingEntries() {
    const entries=storage.get("publicdrop-continue-watching",[]);
    if(!Array.isArray(entries))return [];
    return entries
      .filter(entry=>entry&&["movie","tv","anime"].includes(entry.type)&&entry.id&&entry.title
        &&Number.isFinite(Number(entry.currentTime))&&Number(entry.currentTime)>=5
        &&Number.isFinite(Number(entry.duration))&&Number(entry.duration)>=0
        &&(Number(entry.duration)===0||Number(entry.duration)>Number(entry.currentTime)))
      .sort((a,b)=>Number(b.updatedAt||0)-Number(a.updatedAt||0))
      .slice(0,20);
  }
  function continueWatchingHref(entry) {
    const type=["movie","tv","anime"].includes(entry.type)?entry.type:"movie";
    const query=new URLSearchParams();
    if(type!=="movie"){
      query.set("season",String(Math.max(1,Number(entry.season)||1)));
      query.set("episode",String(Math.max(1,Number(entry.episode)||1)));
    }
    if(type==="anime"){
      query.set("dub",entry.dub==="dub"?"dub":"sub");
      if(entry.isTmdb)query.set("isTmdb","1");
      if(entry.tmdbType)query.set("tmdbType",entry.tmdbType);
    }
    const suffix=query.toString();
    return `#/watch/${type}/${encodeURIComponent(entry.id)}${suffix?`?${suffix}`:""}`;
  }
  function continueWatchingCard(entry) {
    const current=Number(entry.currentTime)||0;
    const duration=Number(entry.duration)||0;
    const progress=Math.max(0,Math.min(100,duration?current/duration*100:0));
    const episodeLabel=entry.type==="movie"?"Movie":`S${Math.max(1,Number(entry.season)||1)} E${Math.max(1,Number(entry.episode)||1)}`;
    const fallback=cardPlaceholderData({id:entry.id,title:entry.title});
    const phoneLayout=window.matchMedia?.("(max-width: 520px)").matches;
    const artwork=(phoneLayout?sizedArtwork(entry.poster,"w342")||entry.backdrop:entry.backdrop||entry.poster)||fallback;
    const fallbackLogo=titleLogoData(entry);
    const officialLogo=entry.logo||entry.metadata?.logo||"";
    const displayLogo=officialLogo||fallbackLogo;
    const previewItem=normalize({...entry.metadata,...entry,id:entry.id,type:entry.type},entry.type);
    return `<article class="media-card continue-card" data-key="${escapeHTML(entry.key)}" data-preview="${escapeHTML(JSON.stringify(previewItem))}">
      <a href="${continueWatchingHref(entry)}" aria-label="Continue ${escapeHTML(entry.title)} from ${escapeHTML(continueTime(current))}">
        <div class="poster-shell card-art-shell">
          <img class="card-art" src="${escapeHTML(artwork)}" data-fallback-src="${escapeHTML(fallback)}" data-placeholder-src="${escapeHTML(fallback)}" alt="${escapeHTML(entry.title)}" loading="eager" decoding="async">
          <span class="poster-shade"></span>
          <span class="continue-play">${svg("i-play")}</span>
          <img class="card-logo continue-card-logo ${officialLogo?"official-logo":"fallback-logo"}" src="${escapeHTML(displayLogo)}" data-fallback-logo="${escapeHTML(officialLogo?fallbackLogo:"")}" alt="${escapeHTML(entry.title)} logo" loading="eager" decoding="async">
          <div class="continue-card-copy"><span>${escapeHTML(episodeLabel)} · ${duration>0?`${escapeHTML(continueTime(current))} / ${escapeHTML(continueTime(duration))}`:`Watched ${escapeHTML(continueTime(current))}`}</span></div>
          ${duration>0?`<span class="continue-progress" aria-label="${Math.round(progress)} percent watched"><i style="width:${progress.toFixed(2)}%"></i></span>`:""}
        </div>
      </a>
      <button type="button" class="continue-remove" data-continue-remove="${escapeHTML(entry.key)}" aria-label="Remove ${escapeHTML(entry.title)} from Continue Watching" title="Remove from Continue Watching">${svg("i-close")}</button>
    </article>`;
  }
  function removeContinueWatchingEntry(key) {
    const entries=storage.get("publicdrop-continue-watching",[]);
    const target=Array.isArray(entries)?entries.find(entry=>entry?.key===key):null;
    storage.set("publicdrop-continue-watching",Array.isArray(entries)?entries.filter(entry=>entry?.key!==key):[]);
    if(target){
      const prefix=`publicdrop_progress_${target.type}_${target.id}_`;
      for(let index=localStorage.length-1;index>=0;index-=1){
        const storageKey=localStorage.key(index);
        if(storageKey?.startsWith(prefix))localStorage.removeItem(storageKey);
      }
    }
    window.dispatchEvent(new CustomEvent("publicdrop:progresschange",{detail:{key,removed:true}}));
  }
  function continueWatchingRail(entries=continueWatchingEntries()) {
    if(!entries.length)return "";
    return `<section class="rail-section continue-watching-section"><div class="section-heading"><h2>Continue Watching</h2><div class="rail-heading-actions"><button class="rail-arrow" data-rail-scroll="left" aria-label="Scroll Continue Watching left">${svg("i-back")}</button><button class="rail-arrow" data-rail-scroll="right" aria-label="Scroll Continue Watching right">${svg("i-arrow")}</button></div></div><div class="media-rail">${entries.map(continueWatchingCard).join("")}</div></section>`;
  }

  function refreshContinueWatchingRail() {
    if ((parseRoute().parts[0] || "home") !== "home") return;
    const content=document.querySelector("#home-content");
    if (!content) return;
    const existing=content.querySelector(".continue-watching-section");
    const markup=continueWatchingRail();
    if (existing) { if (markup) existing.outerHTML=markup; else existing.remove(); }
    else if (markup) {
      content.insertAdjacentHTML("afterbegin",markup);
    }
    const row=content.querySelector(".continue-watching-section");
    if(row)content.prepend(row);
  }
  function rail(title, items, options = {}) {
    if (!items.length) return "";
    const cards = options.topTen ? items.slice(0, 10).map((m, index) => `<a class="rank-card" href="#/detail/${m.type}/${m.id}" aria-label="Number ${index + 1}: ${escapeHTML(m.title)}"><span class="rank-number">${index + 1}</span><div class="poster-shell"><img src="${escapeHTML(sizedArtwork(m.poster,"w500"))}" alt="${escapeHTML(m.title)}" loading="lazy" decoding="async"><span class="poster-shade"></span></div></a>`).join("") : items.map((m,index)=>card(m,false,{priority:Boolean(options.priority)&&index<6})).join("");
    return `<section class="rail-section"><div class="section-heading"><h2>${escapeHTML(title)}</h2><div class="rail-heading-actions">${options.more ? `<a href="${options.more}">View all</a>` : ""}<button class="rail-arrow" data-rail-scroll="left" aria-label="Scroll ${escapeHTML(title)} left">${svg("i-back")}</button><button class="rail-arrow" data-rail-scroll="right" aria-label="Scroll ${escapeHTML(title)} right">${svg("i-arrow")}</button></div></div><div class="media-rail ${options.topTen ? "top-ten-rail" : ""}">${cards}</div></section>`;
  }
  function balanced(items, pool, offset = 0) {
    const rotated=[...pool.slice(offset),...pool.slice(0,offset)];
    return [...new Map([...items,...rotated].map(item=>[movieKey(item),item])).values()].slice(0,12);
  }
  function matchesCatalog(item, type) {
    const animated=item.genres.includes(16)||item.isAnime||item.isCartoon;
    if(type==="anime")return item.isAnime;
    if(type==="cartoon")return item.isCartoon&&!item.isAnime;
    if(type==="tv")return item.type==="tv"&&!animated;
    if(type==="movie")return item.type==="movie"&&!animated;
    return true;
  }
  function takeUnused(source, used, count = 10, predicate = () => true) {
    const selected=[];
    for(const item of source){const key=movieKey(item);if(!used.has(key)&&predicate(item)){used.add(key);selected.push(item);if(selected.length===count)break;}}
    return selected;
  }
  function fillRow(source, selected, count = 10, predicate = () => true) {
    const rowKeys=new Set(selected.map(movieKey));
    for(const item of source){
      const key=movieKey(item);
      if(!rowKeys.has(key)&&predicate(item)){
        rowKeys.add(key);
        selected.push(item);
        if(selected.length===count)break;
      }
    }
    return selected;
  }
  function uniqueRails(definitions, pool, count = 10, options = {}) {
    const used=new Set();
    const rows=[];
    for(const definition of definitions){
      const source=definition.source||pool;
      const targetCount=definition.count||count;
      const predicate=definition.predicate||(()=>true);
      const selectionUsed=options.reuseRows?new Set():used;
      const items=takeUnused(source,selectionUsed,targetCount,predicate);
      if(items.length<targetCount)fillRow(source,items,targetCount,predicate);
      if(items.length<targetCount&&source===pool&&!options.strict)fillRow(pool,items,targetCount);
      if(options.repeatRows&&items.length&&items.length<targetCount){
        const repeatable=source.filter(predicate);
        for(let index=0;items.length<targetCount;index++)items.push(repeatable[index%repeatable.length]);
      }
      items.forEach(item=>used.add(movieKey(item)));
      if(items.length)rows.push([definition.title,items,definition.more]);
    }
    while(rows.length<(options.maxRows??5)){
      const items=takeUnused(pool,used,count);
      if(!items.length)break;
      rows.push([`More to explore ${rows.length+1}`,items]);
    }
    return rows.map(([title,items,more],index)=>{
      const markup=rail(title,items,{more,fill:true,priority:Boolean(options.priorityFirst)&&index===0});
      return markup+(options.afterTitle===title?options.afterMarkup||"":"");
    }).join("");
  }
  function sectionMasthead({kicker,title,description,item,id="section-masthead"}) {
    const featured=item?normalize(item,item.type):null;
    const artwork=featured?.backdrop||featured?.poster||"";
    return `<header class="section-masthead ${artwork?"has-art":"is-loading"}" id="${id}">${artwork?`<img class="section-masthead-art" src="${escapeHTML(artwork)}" alt="" aria-hidden="true">`:`<span class="section-masthead-placeholder skeleton"></span>`}<div class="section-masthead-copy"><span class="eyebrow">${escapeHTML(kicker)}</span><h1>${escapeHTML(title)}</h1><p>${escapeHTML(description)}</p>${featured?`<span class="section-masthead-featured">Trending now <b>${escapeHTML(featured.title)}</b></span>`:""}</div></header>`;
  }
  function refreshSectionMasthead(config,items) {
    const target=document.querySelector("#section-masthead");
    const featured=(items||[]).find(item=>item.backdrop||item.poster);
    if(target&&featured)target.outerHTML=sectionMasthead({...config,item:featured});
  }
  function skeletonRail() { return `<div class="media-rail">${Array.from({length:8},()=>`<div><div class="poster-shell skeleton"></div><div class="skeleton" style="height:12px;margin-top:12px;border-radius:6px"></div></div>`).join("")}</div>`; }
  function errorView(title, error) { return `<section class="error-state"><div><span class="eyebrow">Connection issue</span><h2>${escapeHTML(title)}</h2><p>${escapeHTML(error.message || "The catalog service could not be reached.")}</p><button class="primary-button" data-retry>Try again</button></div></section>`; }

  function setDocumentTitle(label) { document.title = label ? `${label} — PublicDROP` : "PublicDROP — Beyond a Stream"; }
  function setActiveRoute(route) {
    const key=({movie:"movies",tv:"series",cartoon:"cartoons"})[route]||route;
    document.querySelectorAll("[data-route]").forEach(el => el.classList.toggle("active", el.dataset.route === key));
    document.body.classList.toggle("has-hero-nav", route === "home");
  }
  function showToast(message) { const node = document.createElement("div"); node.className="toast"; node.textContent=message; document.querySelector("#toast-region").append(node); setTimeout(()=>node.remove(),2600); }

  // The hero banner is a CSS background, so the browser finds it late. Preload it with high priority.
  function preloadHeroImage(url) {
    if(!url||document.querySelector(`link[data-hero-preload][href="${CSS.escape(url)}"]`))return;
    const link=document.createElement("link");
    link.rel="preload";link.as="image";link.href=url;link.setAttribute("fetchpriority","high");link.dataset.heroPreload="1";
    document.head.append(link);
  }

  function heroSlide(item, items, activeIndex = 0) {
    const typeLabel=item.isAnime?"Japanese Anime":item.isCartoon?"Cartoon":item.type==="tv"?"TV Series":"Movie";
    const genres=item.genres.map(id=>genreMap[id]).filter(Boolean).slice(0,3);
    const logo=item.logo||titleLogoData(item);
    if(activeIndex===0)preloadHeroImage(item.backdrop||item.poster);
    return `<div class="hero-media" style="background-image:url('${escapeHTML(item.backdrop || item.poster)}')"></div><div class="hero-mobile-badge"><b><img src="/assets/publicdrop-favicon.png" alt="" width="22" height="22" decoding="async"></b><span>#${activeIndex+1} featured</span></div><div class="hero-content"><div class="hero-kicker">Featured today</div><img class="hero-title-logo ${item.logo?"official-logo":"fallback-logo"}" src="${escapeHTML(logo)}" alt="${escapeHTML(item.title)}"><div class="hero-meta"><span class="hero-rating">★ ${item.rating.toFixed(1)}</span><span class="hero-dot">•</span><span>${escapeHTML(item.year)}</span><span class="hero-dot">•</span><span>${escapeHTML(typeLabel)}</span>${genres.map(genre=>`<span class="hero-dot">•</span><span>${escapeHTML(genre)}</span>`).join("")}</div><p class="hero-overview">${escapeHTML(item.overview || "Discover this featured title and thousands more on PublicDROP.")}</p><div class="button-row hero-actions"><a class="primary-button" href="${watchLink(item,{season:1,episode:1})}"><span class="hero-play-icon">${svg("i-play")}</span> Play</a><a class="secondary-button" href="#/detail/${item.type}/${item.id}">${svg("i-info")} More info</a></div></div><div class="hero-thumbs">${items.slice(0,7).map((entry,index)=>`<button class="hero-thumb ${index===activeIndex?"active":""}" data-hero-index="${index}" aria-label="Show ${escapeHTML(entry.title)}"><img src="${escapeHTML(entry.backdrop||entry.poster)}" alt="" loading="lazy"></button>`).join("")}</div>`;
  }

  function homeFooter() {
    const year=new Date().getFullYear();
    return `<footer class="home-footer">
      <div class="home-footer-glow" aria-hidden="true"></div>
      <div class="home-footer-main">
        <div class="home-footer-brand">
          <a href="#/" aria-label="PublicDROP home"><img src="./assets/publicdrop-wordmark.png" alt="PublicDROP"></a>
          <p>Your screen for movies, series, Japanese anime and cartoons—all organized in one cinematic library.</p>
          <div class="home-footer-tags"><span>Movies</span><span>Series</span><span>Anime</span><span>Cartoons</span></div>
        </div>
        <section class="home-footer-contact" aria-labelledby="footer-contact-title">
          <div class="home-footer-contact-head">
            <span class="home-footer-contact-seal" aria-hidden="true"><i>P</i><b>EST. 2026</b></span>
            <div><span class="home-footer-contact-kicker">Contact us · The PublicDROP society</span><h2 id="footer-contact-title">Enter the members’ lounge</h2></div>
          </div>
          <div class="home-footer-contact-rule"><span>Private channels · Open community</span></div>
          <p>Continue the story beyond the screen—requests, release notes and conversations with fellow viewers.</p>
          <div class="home-footer-socials">
            <a class="home-footer-social is-telegram" href="https://t.me/PublicDROPflix" target="_blank" rel="noopener noreferrer" aria-label="Join PublicDROP on Telegram">
              <b class="home-footer-social-index">01</b>
              <span class="home-footer-social-mark" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M21.6 3.4 18.4 20c-.2 1.2-.9 1.5-1.9.9l-4.9-3.6-2.4 2.3c-.3.3-.5.5-1 .5l.4-5 9-8.1c.4-.4-.1-.6-.6-.2L5.8 13.9 1 12.4c-1.1-.3-1.1-1 .2-1.5L20 3.7c.9-.3 1.7.2 1.6-.3Z"/></svg></span>
              <span><strong>Telegram</strong><small>Join the community</small></span>
              ${svg("i-arrow")}
            </a>
            <a class="home-footer-social is-whatsapp" href="https://whatsapp.com/channel/0029Vb9CSbC0bIdvhZbGNS0h" target="_blank" rel="noopener noreferrer" aria-label="Join the PublicDROP WhatsApp Channel">
              <b class="home-footer-social-index">02</b>
              <span class="home-footer-social-mark" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg></span>
              <span><strong>WhatsApp</strong><small>Join WhatsApp Channel</small></span>
              ${svg("i-arrow")}
            </a>
          </div>
        </section>
        <button class="home-footer-top" type="button" data-scroll-top aria-label="Back to top">${svg("i-arrow")}<span>Top</span></button>
      </div>
      <div class="home-footer-bottom"><p>PublicDROP does not host or upload media. Titles are indexed from public metadata and third-party sources.</p><span>© ${year} PublicDROP</span></div>
    </footer>`;
  }

  async function renderHome() {
    setDocumentTitle(""); setActiveRoute("home");
    app.innerHTML = `<div class="page with-hero"><section class="hero skeleton" id="hero"></section><div class="content" id="home-content">${continueWatchingRail()}<section class="rail-section"><div class="section-heading"><h2>Top Searches</h2></div>${skeletonRail()}</section></div>${homeFooter()}</div>`;
    try {
      const A = window.PublicDROPAudio, audio = audioCode(), indian = audio !== "en", L = A ? A.info(audio).name : "";
      const audioRail = (type, recent) => cached(`audiorail:${type}:${audio}:${recent}:${locale()}`, () => api.discoverAudio({ type, lang: audio, recent, language: locale() })).then(d => (d.results || []).filter(i => i.poster_path).map(i => normalize(i, type))).catch(() => []);
      const [movies, series, anime, cartoons, freshMovies, freshSeries] = await Promise.all([catalog("movie"), catalogBatch("tv",5), indian ? [] : catalog("anime"), indian ? [] : catalog("cartoon"), indian ? audioRail("movie", true) : [], indian ? audioRail("tv", true) : []]);
      const curatedSeries = indian ? series : series.filter(isActionThrillerSeries);
      const trending = [...freshMovies, ...freshSeries].sort((a, b) => b.popularity - a.popularity);
      const mixed = [...movies, ...curatedSeries].sort((a,b)=>b.rating-a.rating);
      const heroItems = indian && (trending.length || mixed.length) ? [...trending.slice(0,4), ...mixed.slice(0,2)].filter((x,i,arr)=>arr.findIndex(y=>movieKey(y)===movieKey(x))===i) : [...mixed.slice(0,3), ...anime.slice(0,3)];
      const all = [...new Map([...trending, ...movies, ...curatedSeries, ...(indian ? [] : [...anime, ...cartoons])].map(item=>[movieKey(item),item])).values()];
      const hero = heroItems[0] || movies[0];
      document.querySelector("#hero").classList.remove("skeleton");
      const heroNode=document.querySelector("#hero");
      let activeHeroIndex=0;
      const selectHero=index=>{activeHeroIndex=(index+heroItems.length)%heroItems.length;heroNode.innerHTML=heroSlide(heroItems[activeHeroIndex],heroItems,activeHeroIndex);};
      selectHero(0);
      heroNode.addEventListener("click", event => {
        const thumb = event.target.closest("[data-hero-index]");
        if (!thumb) return;
        selectHero(Number(thumb.dataset.heroIndex));
      });
      const startHeroSlider=()=>{clearInterval(heroSliderTimer);heroSliderTimer=setInterval(()=>selectHero(activeHeroIndex+1),5000);};
      let heroTouchX=null;
      heroNode.addEventListener("touchstart",event=>{heroTouchX=event.changedTouches[0]?.clientX??null;clearInterval(heroSliderTimer);},{passive:true});
      heroNode.addEventListener("touchend",event=>{const endX=event.changedTouches[0]?.clientX;if(heroTouchX!==null&&Number.isFinite(endX)&&Math.abs(endX-heroTouchX)>42)selectHero(activeHeroIndex+(endX<heroTouchX?1:-1));heroTouchX=null;startHeroSlider();},{passive:true});
      heroNode.addEventListener("mouseenter",()=>clearInterval(heroSliderTimer));
      heroNode.addEventListener("mouseleave",startHeroSlider);
      startHeroSlider();
      const homeDefinitions=[];
      if (indian) homeDefinitions.push(
        {title:audio==="hi"?"Trending in India":`Trending in ${L}`,source:trending.length?trending:mixed,count:10},
        {title:`Latest ${L} Movies`,source:freshMovies.length?freshMovies:movies,count:10,more:"#/movies"},
        ...(["hi","ta","te"].includes(audio)?[{title:`Hollywood in ${L}`,source:[...freshMovies,...movies].filter(i=>i.dubbed),count:10,more:"#/movies"}]:[]),
        {title:`Popular ${L} Movies`,source:movies,count:10,more:"#/movies"},
        {title:`${L} Web Series`,source:curatedSeries,count:10,more:"#/series"},
        {title:"Critically Rated",source:[...all].sort((a,b)=>b.rating-a.rating),count:10}
      ); else homeDefinitions.push(
        {title:"Top Searches",source:mixed,count:10},
        {title:"Popular Movies",source:movies,count:10,more:"#/movies"},
        {title:"Action & Thriller Series",source:curatedSeries,count:10,more:"#/series"},
        {title:"Japanese Anime",source:anime,count:10,predicate:item=>item.isAnime,more:"#/anime"},
        {title:"Cartoons",source:cartoons,count:10,predicate:item=>item.isCartoon,more:"#/cartoons"},
        {title:"Critically Rated",source:[...all].sort((a,b)=>b.rating-a.rating),count:10}
      );
      document.querySelector("#home-content").innerHTML=continueWatchingRail()+uniqueRails(homeDefinitions,all,10);
    } catch (error) { document.querySelector("#home-content").innerHTML = continueWatchingRail()+errorView("Unable to load PublicDROP", error); }
  }

  /* the page address of each catalogue: movie -> #/movies, tv -> #/series, anime -> #/anime, cartoon -> #/cartoons */
  function catalogRoute(type) { return ({movie:"movies",tv:"series",anime:"anime",cartoon:"cartoons"})[type]||type; }
  function catalogGenreFilters(type,selected) {
    const route=catalogRoute(type);
    const options=genreOptionsFor(type);
    return `<section class="catalog-genre-bar" aria-label="Filter by genre"><div class="catalog-genre-heading"><div><span class="eyebrow">Browse by genre</span><strong>${selected?escapeHTML(selected.label):"All genres"}</strong></div>${selected?`<a href="#/${route}" class="catalog-filter-clear">Clear filter</a>`:""}</div><div class="filters" role="list"><a class="filter-chip ${selected?"":"active"}" href="#/${route}" ${selected?"":'aria-current="page"'}>All</a>${options.map(option=>`<a class="filter-chip ${selected?.key===option.key?"active":""}" href="#/${route}?genre=${encodeURIComponent(option.key)}" ${selected?.key===option.key?'aria-current="page"':""}>${escapeHTML(option.label)}</a>`).join("")}</div></section>`;
  }

  async function renderCatalog(type,requestedGenre="") {
    const route = catalogRoute(type);
    const label = type === "tv" ? "Series" : type[0].toUpperCase()+type.slice(1);
    const selectedGenre=selectedGenreFor(type,requestedGenre);
    const masthead={
      kicker:type==="anime"?"Japanese animation":type==="cartoon"?"Animation destination":"Curated catalog",
      title:label,
      description:type==="movie"
        ?"Live-action blockbusters, new releases and stories worth the big screen."
        :type==="tv"
          ?"Live-action, binge-worthy worlds, one episode at a time."
          :type==="anime"
            ?"Japanese anime series and movies, kept separate from Western cartoons."
            :"Western animated series and movies for every age."
    };
    const pageLabel=selectedGenre?`${selectedGenre.label} ${label}`:label;
    setDocumentTitle(pageLabel); setActiveRoute(route);
    app.innerHTML = `<div class="page">${sectionMasthead({...masthead,title:pageLabel,description:selectedGenre?`Explore ${selectedGenre.label.toLowerCase()} titles across the ${label.toLowerCase()} catalog.`:masthead.description})}${catalogGenreFilters(type,selectedGenre)}<div id="catalog-grid">${skeletonRail()}</div></div>`;
    try {
      const pageResults=await Promise.allSettled(Array.from({length:type==="tv"?8:3},(_,index)=>catalog(type,index+1,selectedGenre)));
      const pages=pageResults.filter(result=>result.status==="fulfilled").map(result=>result.value);
      if(!pages.length)throw pageResults[0].reason;
      const items=[...new Map(pages.flat().map(item=>[movieKey(item),item])).values()];
      refreshSectionMasthead({...masthead,title:pageLabel,description:selectedGenre?`Explore ${selectedGenre.label.toLowerCase()} titles across the ${label.toLowerCase()} catalog.`:masthead.description},items);
      const preview=selectedGenre?[]:cachedCatalogItems().map(item=>normalize(item)).filter(item=>matchesCatalog(item,type));
      const pool=[...new Map([...items,...preview].map(item=>[movieKey(item),item])).values()]
        .filter(item=>matchesCatalog(item,type)&&itemMatchesGenre(item,selectedGenre))
        .filter(item=>type!=="tv"||isActionThrillerSeries(item));
      const definitions=type==="movie"?[
        {title:"Popular Movies",source:pool},
        {title:"Action & Adventure",source:pool,predicate:item=>item.type==="movie"&&(item.genres.includes(28)||item.genres.includes(12))},
        {title:"Drama & Romance",source:pool,predicate:item=>item.type==="movie"&&(item.genres.includes(18)||item.genres.includes(10749))},
        {title:"Crime & Thriller",source:pool,predicate:item=>item.genres.includes(80)||item.genres.includes(53)},
        {title:"Sci-Fi & Fantasy",source:pool,predicate:item=>item.genres.includes(878)||item.genres.includes(14)},
        {title:"More Movies",source:pool,predicate:item=>item.type==="movie"}
      ]:type==="tv"?[
        {title:"Action Series",source:pool,predicate:item=>item.genres.includes(28)||item.genres.includes(10759)},
        {title:"Thriller Series",source:pool,predicate:item=>item.genres.includes(53)},
        {title:"Action & Thriller Series",source:pool,predicate:item=>(item.genres.includes(28)||item.genres.includes(10759))&&item.genres.includes(53)},
        {title:"Popular Action & Thriller",source:[...pool].sort((a,b)=>b.rating-a.rating)},
        {title:"More Action & Thriller",source:[...pool].sort((a,b)=>(b.popularity||0)-(a.popularity||0))}
      ]:type==="anime"?[
        {title:"Popular Anime",source:pool},
        {title:"Anime Series",source:pool,predicate:item=>item.type==="tv"},
        {title:"Anime Movies",source:pool,predicate:item=>item.type==="movie"},
        {title:"Action & Adventure Anime",source:pool,predicate:item=>item.genres.includes(28)||item.genres.includes(12)||item.genres.includes(10759)},
        {title:"Fantasy Anime",source:pool,predicate:item=>item.genres.includes(14)||item.genres.includes(10765)},
        {title:"More Japanese Anime",source:pool}
      ]:[
        {title:"Popular Cartoons",source:pool},
        {title:"Cartoon Series",source:pool,predicate:item=>item.type==="tv"},
        {title:"Animated Movies",source:pool,predicate:item=>item.type==="movie"},
        {title:"Comedy Cartoons",source:pool,predicate:item=>item.genres.includes(35)},
        {title:"Family Cartoons",source:pool,predicate:item=>item.genres.includes(10751)},
        {title:"More Cartoons",source:pool}
      ];
      document.querySelector("#catalog-grid").innerHTML = pool.length
        ? selectedGenre
          ? `<section class="filtered-catalog"><div class="catalog-grid-heading"><div><span class="eyebrow">${escapeHTML(selectedGenre.label)}</span><h2>${pool.length} matching titles</h2></div><span>Showing movies and series that match this genre</span></div><div class="catalog-main-grid">${pool.map((item,index)=>card(item,false,{priority:index<8})).join("")}</div></section>`
          : `<div class="catalog-rail-layout">${uniqueRails(definitions,pool,10,{priorityFirst:true,strict:type==="tv",reuseRows:type==="tv",repeatRows:type==="tv",maxRows:type==="tv"?5:5})}</div>`
        : `<div class="empty-state"><div><h2>No ${selectedGenre?escapeHTML(selectedGenre.label.toLowerCase()):""} titles found</h2><p>Try another genre or clear the filter.</p><a class="primary-button" href="#/${route}">Show all ${escapeHTML(label.toLowerCase())}</a></div></div>`;
    } catch(error) { document.querySelector("#catalog-grid").innerHTML=errorView(`Unable to load ${label.toLowerCase()}`,error); }
  }

  function providerRegion(provider) {
    const priorities=provider.display_priorities||{};
    return ["IN","US","GB","CA","AU"].find(region=>Object.hasOwn(priorities,region))||Object.keys(priorities)[0]||"US";
  }

  function providerTile(provider) {
    const region=providerRegion(provider);
    const href=`#/provider/${provider.provider_id}?name=${encodeURIComponent(provider.provider_name)}&logo=${encodeURIComponent(provider.logo_path||"")}&region=${encodeURIComponent(region)}`;
    return `<a class="provider-tile" href="${href}" title="${escapeHTML(provider.provider_name)}"><span>${provider.logo_path?`<img src="${escapeHTML(image(provider.logo_path,"w92"))}" alt="${escapeHTML(provider.provider_name)}" loading="lazy">`:`<b>${escapeHTML(provider.provider_name.slice(0,2).toUpperCase())}</b>`}</span><strong>${escapeHTML(provider.provider_name)}</strong></a>`;
  }

  async function renderExplore() {
    setDocumentTitle("Explore");setActiveRoute("explore");
    const masthead={kicker:"Streaming directory",title:"Explore",description:"Choose a streaming service and browse its movie and series catalog."};
    app.innerHTML=`<div class="page">${sectionMasthead(masthead)}<section class="providers-section"><div class="catalog-grid-heading"><div><span class="eyebrow">Available streaming networks</span><h2>Pick your service</h2></div><span id="provider-count">Loading providers…</span></div><div id="provider-grid" class="provider-grid">${Array.from({length:36},()=>`<span class="provider-tile skeleton"></span>`).join("")}</div></section></div>`;
    try{
      const [movieData,tvData]=await Promise.all([
        cached(`providers:movie:${locale()}`,()=>api.watchProviders({type:"movie",language:locale()})),
        cached(`providers:tv:${locale()}`,()=>api.watchProviders({type:"tv",language:locale()})),
      ]);
      const providers=[...new Map([...(movieData.results||[]),...(tvData.results||[])].map(provider=>[provider.provider_id,provider])).values()]
        .sort((a,b)=>{
          const aPreferred=Object.hasOwn(a.display_priorities||{},"IN")?0:Object.hasOwn(a.display_priorities||{},"US")?1:2;
          const bPreferred=Object.hasOwn(b.display_priorities||{},"IN")?0:Object.hasOwn(b.display_priorities||{},"US")?1:2;
          return aPreferred-bPreferred||a.provider_name.localeCompare(b.provider_name);
        });
      document.querySelector("#provider-count").textContent=`${providers.length} services`;
      document.querySelector("#provider-grid").innerHTML=providers.map(providerTile).join("");
    }catch(error){document.querySelector("#provider-grid").innerHTML=errorView("Streaming services unavailable",error);}
  }

  function providerCatalogCard(movie) {
    const typeLabel=movie.isAnime?"Anime":movie.type==="tv"?"TV series":"Movie";
    return `<a class="provider-title-card" href="#/detail/${movie.type}/${movie.id}"><div>${movie.poster?`<img src="${escapeHTML(movie.poster)}" alt="${escapeHTML(movie.title)}" loading="lazy">`:`<span class="skeleton"></span>`}<i>${movie.rating?`★ ${movie.rating.toFixed(1)}`:"New"}</i></div><strong>${escapeHTML(movie.title)}</strong><small>${escapeHTML(movie.year)} · ${escapeHTML(typeLabel)}</small></a>`;
  }

  async function renderProvider(id, search) {
    const name=search.get("name")||"Streaming service";
    const logo=search.get("logo")||"";
    const region=search.get("region")||"US";
    setDocumentTitle(name);setActiveRoute("explore");
    app.innerHTML=`<div class="page provider-page"><a class="back-link provider-back" href="#/explore">${svg("i-back")} All services</a><header class="provider-header">${logo?`<img src="${escapeHTML(image(logo,"w154"))}" alt="${escapeHTML(name)}">`:""}<div><span class="eyebrow">Streaming collection</span><h1>${escapeHTML(name)}</h1><p>Popular movies and series currently listed for this service.</p></div></header><div class="catalog-grid-heading"><h2>Popular on ${escapeHTML(name)}</h2><span id="provider-title-count">Loading titles…</span></div><div id="provider-catalog" class="provider-catalog-grid">${Array.from({length:24},()=>`<span class="provider-title-card skeleton"></span>`).join("")}</div></div>`;
    try{
      const requests=[];
      for(const type of ["movie","tv"]){for(let page=1;page<=4;page+=1)requests.push(cached(`provider:${id}:${type}:${region}:${page}:${locale()}`,()=>api.providerCatalog({id,type,page,region,language:locale()})).then(data=>(data.results||[]).map(item=>normalize(item,type))));}
      const results=(await Promise.allSettled(requests)).flatMap(result=>result.status==="fulfilled"?result.value:[]);
      const titles=[...new Map(results.filter(item=>item.poster).map(item=>[movieKey(item),item])).values()].sort((a,b)=>b.popularity-a.popularity||b.rating-a.rating);
      document.querySelector("#provider-title-count").textContent=`${titles.length} titles`;
      document.querySelector("#provider-catalog").innerHTML=titles.length?titles.map(providerCatalogCard).join(""):`<div class="empty-state"><div><h2>No titles found</h2><p>TMDB has no catalog entries for ${escapeHTML(name)} in the selected region.</p></div></div>`;
    }catch(error){document.querySelector("#provider-catalog").innerHTML=errorView(`Unable to load ${name}`,error);}
  }

  function renderFavorites() {
    setDocumentTitle("Favorites");setActiveRoute("favorites");
    const masthead={kicker:"Your collection",title:"My List",description:"Everything you saved, ready when you are."};
    const preview=cachedCatalogItems().map(item=>normalize(item));
    app.innerHTML=`<div class="page">${sectionMasthead({...masthead,item:state.favorites[0]||preview[0]})}${state.favorites.length?`<section class="favorites-section"><div class="favorites-heading"><div><span class="eyebrow">Saved by you</span><h2>Favorite titles</h2></div><div class="favorites-heading-actions"><span>${state.favorites.length} saved</span><div class="rail-heading-actions"><button class="rail-arrow" data-rail-scroll="left" aria-label="Scroll My List left">${svg("i-back")}</button><button class="rail-arrow" data-rail-scroll="right" aria-label="Scroll My List right">${svg("i-arrow")}</button></div></div></div><div class="media-rail favorites-rail" tabindex="0" aria-label="Saved titles. Use the arrow keys or navigation buttons to browse.">${state.favorites.map(m=>card(m)).join("")}</div></section>`:`<div class="empty-state compact-empty"><div><h2>Your list is ready for its first title</h2><p>Use the heart button on any card, or start with one of these recommendations.</p><a class="primary-button" href="#/movies">Browse movies</a></div></div>`}${rail("Recommended for your list",preview)}${rail("Popular series & anime",preview.filter(item=>item.type==="tv"))}</div>`;
    if(!state.favorites.length)catalog("movie").then(items=>refreshSectionMasthead(masthead,items)).catch(()=>{});
  }

  let detailEpisodeState = null;
  let watchNavigatorState = null;
  let watchNavigatorToken = 0;

  function animeSeasonRecords(items, tmdbId) {
    if(window.PublicDROPAnimeMapping)return window.PublicDROPAnimeMapping.seasonRecords(items,Number(tmdbId),false);
    const seen = new Set();
    return (Array.isArray(items) ? items : [])
      .filter(item => String(item.tmdbId || "") === String(tmdbId))
      .filter(item => item.id && ["TV","TV_SHORT","ONA"].includes(item.format))
      .filter(item => {
        if (seen.has(item.id)) return false;
        seen.add(item.id);
        return true;
      })
      .sort((a, b) => Number(a.seasonYear || 9999) - Number(b.seasonYear || 9999) || Number(a.anilistId || 0) - Number(b.anilistId || 0));
  }

  function animeEpisodeTitle(titles, number) {
    const language = String(state.language || "en").split("-")[0];
    return titles?.[language] || titles?.en || titles?.["x-jat"] || titles?.ja || `Episode ${number}`;
  }

  function normalizeAnimeEpisodes(items) {
    return (Array.isArray(items) ? items : []).map((episode, index) => {
      const number = Number(episode.number || episode.episode_number || index + 1);
      return {
        episode_number: number,
        name: animeEpisodeTitle(episode.titles, number),
        still: episode.img || "",
        overview: episode.description || "",
        runtime: Number(episode.length) || 0,
        air_date: episode.airDateUtc ? String(episode.airDateUtc).slice(0, 10) : "",
        rating: Number(episode.rating) || 0,
        isFiller: Boolean(episode.isFiller),
        hasSub: Boolean(episode.hasSub),
        hasDub: Boolean(episode.hasDub),
      };
    });
  }

  function animeEntryTitle(item) {
    return item?.titleEnglish || item?.titleRomaji || "Untitled anime";
  }

  function animeEntryFormat(item) {
    return String(item?.format || "ANIME").replaceAll("_", " ");
  }

  function rememberAnimeEntries(items) {
    (Array.isArray(items) ? items : []).forEach(item => {
      if (item?.id) state.animeEntries.set(String(item.id), item);
    });
  }

  function animeSearchVariants(title) {
    const original=String(title||"").trim();
    const ascii=original.normalize("NFD").replace(/[\u0300-\u036f]/g,"");
    const franchise=ascii
      .replace(/\s*[:\-–—]\s*(season|part|cour)\b.*$/i,"")
      .replace(/\b(shippuden|next generations|season\s+\d+|part\s+\d+|cour\s+\d+)\b.*$/i,"")
      .trim();
    return [...new Set([original,ascii,franchise].filter(Boolean))];
  }

  async function searchAnimeFranchise(title) {
    const variants=animeSearchVariants(title);
    let lastError;
    for (const query of [...variants].reverse()) {
      try {
        const data=await cached(`animex:search:${query}`,()=>api.animeSearch({title:query}));
        const items=[...new Map((data.items||[]).filter(item=>item?.id).map(item=>[String(item.id),item])).values()];
        if(items.length)return {items,query};
      } catch(error) { lastError=error; }
    }
    throw lastError||new Error("AniDap search returned no titles.");
  }

  function animeFranchisePanel(items, activeAnimeId = "", query = "") {
    const unique=[...new Map((Array.isArray(items)?items:[]).filter(item=>item?.id).map(item=>[String(item.id),item])).values()];
    if (!unique.length) return "";
    rememberAnimeEntries(unique);
    const baseQuery=query||animeEntryTitle(unique[0]);
    return `<section class="anime-franchise-section"><div class="episodes-heading"><div><span class="eyebrow">Complete anime collection</span><h2>Series, movies & specials</h2></div><span class="episode-count">${unique.length}<b>related titles</b></span></div><p class="anime-franchise-intro">Every matching AniDap title is kept together here, including movies, OVAs, ONAs and specials.</p><div class="anime-franchise-strip">${unique.map(item=>{
      const title=animeEntryTitle(item);
      const format=animeEntryFormat(item);
      const episodes=Number(item.episodeCount)||0;
      const meta=[format,item.seasonYear||"",episodes?`${episodes} ep${episodes===1?"":"s"}`:""].filter(Boolean).join(" · ");
      const href=`#/anime-title/${encodeURIComponent(item.id)}?q=${encodeURIComponent(baseQuery)}`;
      return `<a class="anime-franchise-item ${String(item.id)===String(activeAnimeId)?"active":""}" href="${href}" aria-current="${String(item.id)===String(activeAnimeId)?"page":"false"}"><strong>${escapeHTML(title)}</strong><span>${escapeHTML(meta)}</span></a>`;
    }).join("")}</div></section>`;
  }

  function episodePanel(movie, seasonCount, season, episodes, page = 1, seasonRecords = []) {
    const pageSize = 20;
    const isAnimeGuide=seasonRecords.length>0;
    const pages = Math.max(1, Math.ceil(episodes.length / pageSize));
    const safePage=Math.min(Math.max(1,page),pages);
    const visible = isAnimeGuide?episodes:episodes.slice((safePage - 1) * pageSize, safePage * pageSize);
    const seasonTabs=!isAnimeGuide?Array.from({length:seasonCount},(_,i)=>`<button class="season-tab ${i+1===season?"active":""}" data-season="${i+1}" aria-pressed="${i+1===season}"><span>Season</span><b>${i+1}</b></button>`).join(""):"";
    const episodeCards=visible.map((ep,index)=>{
      const number=Number(ep.episode_number||ep.number||((safePage-1)*pageSize+index+1));
      const runtime=Number(ep.runtime)||0;
      const airDate=ep.air_date?new Date(`${ep.air_date}T00:00:00`).toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"}):"";
      const episodeMeta=[runtime?`${runtime} min`:"",ep.rating?`★ ${Number(ep.rating).toFixed(1)}`:"",ep.hasSub?"SUB":"",ep.hasDub?"DUB":"",ep.isFiller?"FILLER":""].filter(Boolean);
      return `<a class="episode-card" href="${watchLink(movie,{season,episode:number})}"><div class="episode-still">${ep.still_path||ep.still?`<img src="${escapeHTML(ep.still||image(ep.still_path,"w500"))}" alt="${escapeHTML(ep.name||`Episode ${number}`)}" loading="lazy">`:`<span>${svg("i-play")}</span>`}<span class="episode-play">${svg("i-play")}</span><b>${number}</b></div><div class="episode-copy"><div class="episode-topline"><span>Episode ${number}</span>${episodeMeta.length?`<small>${episodeMeta.map(value=>`<i>${escapeHTML(value)}</i>`).join("")}</small>`:""}</div><h3>${escapeHTML(ep.name||`Episode ${number}`)}</h3><p>${escapeHTML(ep.overview||"Continue the story in this episode.")}</p>${airDate?`<time datetime="${escapeHTML(ep.air_date)}">${escapeHTML(airDate)}</time>`:""}</div></a>`;
    }).join("");
    const animeEpisodeGrid=isAnimeGuide&&episodes.length>20?`<div class="anime-flat-episode-grid">${episodes.map((ep,index)=>{
      const number=Number(ep.episode_number||ep.number||index+1);
      const availability=[ep.hasSub?"SUB":"",ep.hasDub?"DUB":"",ep.isFiller?"FILLER":""].filter(Boolean).join(" · ");
      return `<a class="anime-flat-episode" href="${watchLink(movie,{season:1,episode:number})}"><b>${String(number).padStart(2,"0")}</b><span><strong>${escapeHTML(ep.name||`Episode ${number}`)}</strong>${availability?`<small>${escapeHTML(availability)}</small>`:""}</span>${svg("i-play")}</a>`;
    }).join("")}</div>`:"";
    const episodePages=!isAnimeGuide&&pages>1?`<div class="episode-pagination"><div><span class="eyebrow">Episode groups</span><strong>Browse episode details</strong></div><div class="episode-page-tabs">${Array.from({length:pages},(_,i)=>`<button class="episode-page-tab ${i+1===safePage?"active":""}" data-episode-page="${i+1}">${i*pageSize+1}–${Math.min((i+1)*pageSize,episodes.length)}</button>`).join("")}</div></div>`:"";
    const seasonSwitcher=!isAnimeGuide?`<div class="season-switcher"><div class="season-switcher-label"><span>Browse</span><strong>Select a season</strong></div><div class="season-tabs">${seasonTabs}</div></div>`:"";
    return `<section class="episodes-section ${isAnimeGuide?"anime-episodes-section":""}"><div class="episodes-heading"><div><span class="eyebrow">Episode guide</span><h2>${isAnimeGuide?"Episodes":"Seasons & episodes"}</h2></div><span class="episode-count">${isAnimeGuide?"All available":`Season ${season}`}<b>${episodes.length} episodes</b></span></div>${seasonSwitcher}${episodePages}${animeEpisodeGrid||`<div class="episode-list">${episodeCards}</div>`}</section>`;
  }

  async function loadEpisodePanel(season, page = 1) {
    if (!detailEpisodeState) return;
    const {movie, seasonCount, animeSeasons = []} = detailEpisodeState;
    const target = document.querySelector("#episodes-panel");
    if (!target) return;
    target.innerHTML = `<div class="episodes-loading skeleton"></div>`;
    let episodes;
    let episodeError;
    try {
      for(let attempt=0;attempt<2;attempt++){
        try{
          if (animeSeasons.length) {
            const record=animeSeasons[season-1];
            if (!record?.id) throw new Error("Anime season unavailable");
            try{
              const data=await cached(`animex:episodes:${record.id}`,()=>api.animeEpisodes({id:record.id}));
              episodes=normalizeAnimeEpisodes(data.episodes||data.results||data);
            }catch(animeError){
              if(season!==1||(!movie.tmdbId&&!movie.id))throw animeError;
              console.warn("AnimeX episodes unavailable; using TMDB episode data.",animeError);
              const tmdbData=await api.episodes({id:movie.tmdbId||movie.id,season:1,language:locale()});
              episodes=tmdbData.episodes||tmdbData.results||tmdbData;
            }
          } else {
            const data=await api.episodes({id:movie.id,season,language:locale()});
            episodes=data.episodes||data.results||data;
          }
          break;
        }catch(error){
          episodeError=error;
          if(attempt===0)await new Promise(resolve=>setTimeout(resolve,450));
          else throw error;
        }
      }
    }
    catch(error) { episodeError=error;episodes=[]; }
    detailEpisodeState={...detailEpisodeState,season,page,episodes};
    const unavailableMessage=episodeError
      ?"The episode list could not be loaded (network or TMDB blocked). Check your connection and try again."
      :animeSeasons.length
        ?"Anime episode metadata is temporarily unavailable."
        :"Official episode metadata is not available for this season.";
    target.innerHTML=Array.isArray(episodes)&&episodes.length?episodePanel(movie,seasonCount,season,episodes,page,animeSeasons):`<section class="episodes-section episode-unavailable"><span class="eyebrow">${animeSeasons.length?"AnimeX":"TMDB"} episode guide</span><h2>Episode data unavailable</h2><p>${unavailableMessage}</p><button class="primary-button" data-retry-episodes>Retry episode data</button></section>`;
  }

  function detailLogo(raw, movie) {
    const logos=(raw.images?.logos||[]).slice().sort((a,b)=>(b.vote_average||0)-(a.vote_average||0));
    const official=logos.find(logo=>logo.iso_639_1==="en")||logos.find(logo=>!logo.iso_639_1)||logos[0];
    return official?.file_path?image(official.file_path,"w780"):(movie.logo||titleLogoData(movie));
  }

  function detailCertification(raw, type) {
    if(type==="movie"){
      const releases=raw.release_dates?.results||[];
      const region=releases.find(item=>item.iso_3166_1==="US")||releases.find(item=>(item.release_dates||[]).some(entry=>entry.certification));
      return (region?.release_dates||[]).find(entry=>entry.certification)?.certification||"";
    }
    const ratings=raw.content_ratings?.results||[];
    return (ratings.find(item=>item.iso_3166_1==="US")||ratings.find(item=>item.rating))?.rating||"";
  }

  function detailBannerFacts(raw) {
    const creators=(raw.created_by||[]).map(person=>person.name).filter(Boolean).join(", ");
    const countries=(raw.production_countries||raw.origin_country||[]).map(country=>country.name||country).filter(Boolean).join(", ");
    const networks=(raw.networks||[]).map(network=>network.name).filter(Boolean).join(", ");
    const studios=(raw.production_companies||[]).map(company=>company.name).filter(Boolean).slice(0,3).join(", ");
    const facts=[
      ["Status",raw.status||"Released"],
      ["Language",String(raw.original_language||"en").toUpperCase()],
      ["Country",countries||null],
      ["Network",networks||null],
      ["Created by",creators||null],
      ["Studio",studios||null],
    ].filter(([,value])=>value);
    return facts.length?`<dl class="detail-banner-facts">${facts.map(([label,value])=>`<div><dt>${escapeHTML(label)}</dt><dd title="${escapeHTML(value)}">${escapeHTML(value)}</dd></div>`).join("")}</dl>`:"";
  }

  function detailHero(raw, movie, type, id, seasons = 0) {
    const runtime=movie.runtime||Number(raw.runtime)||Number((raw.episode_run_time||[])[0])||0;
    const duration=runtime?(runtime>=60?`${Math.floor(runtime/60)}h${runtime%60?` ${runtime%60}m`:""}`:`${runtime}m`):"";
    const episodes=Number(raw.number_of_episodes||movie.episodes)||0;
    const genreRoute=movie.isAnime?"anime":movie.isCartoon?"cartoons":type==="tv"?"series":"movies";
    const genres=(raw.genres||[]).map(g=>`<a href="#/${genreRoute}?genre=${g.id}">${escapeHTML(g.name)}</a>`).join("");
    const logo=detailLogo(raw,movie);
    rememberPlaybackMetadata(raw,movie,type,id,logo);
    const certification=detailCertification(raw,type);
    const typeLabel=movie.isAnime?"Japanese anime":movie.isCartoon?"Cartoon":type==="tv"?"Series":"Movie";
    const playURL=watchLink(movie,{season:1,episode:1});
    const favoriteLabel=isSaved(movie)?"Saved":"My List";
    return `<section class="detail-hero"><div class="detail-media" aria-hidden="true"><img class="detail-backdrop" src="${escapeHTML(movie.backdrop||movie.poster)}" alt=""></div><div class="detail-copy"><a class="back-link" href="javascript:history.back()">${svg("i-back")} Back</a><span class="detail-kicker">${escapeHTML(typeLabel)}</span><div class="detail-logo-stage" tabindex="0" aria-label="${escapeHTML(movie.title)}. Hover or focus to show title information"><img class="detail-title-logo ${movie.logo||logo.startsWith("http")?"official-logo":"fallback-logo"}" src="${escapeHTML(logo)}" alt="${escapeHTML(movie.title)} logo"><div class="detail-logo-reveal"><div class="detail-meta-line"><span class="detail-score">★ ${movie.rating.toFixed(1)}</span><span>${escapeHTML(movie.year)}</span>${certification?`<span>${escapeHTML(certification)}</span>`:""}${duration?`<span>${escapeHTML(duration)}</span>`:""}<span class="detail-type">${escapeHTML(typeLabel)}</span>${seasons&&!movie.isAnime?`<span>${seasons} Season${seasons===1?"":"s"}</span>`:""}${episodes?`<span>${episodes} Episodes</span>`:""}<span class="detail-quality">HD</span></div><div class="genre-list">${genres}</div></div></div>${detailBannerFacts(raw)}<div class="detail-synopsis"><span>Synopsis</span><p>${escapeHTML(movie.overview||"No overview is available for this title.")}</p></div><div class="button-row detail-actions"><a class="detail-play-button" href="${playURL}"><span>${svg("i-play")}</span> Watch now</a><button class="detail-action-button" data-detail-favorite='${escapeHTML(JSON.stringify(movie))}'>${svg("i-heart")} ${favoriteLabel}</button><button type="button" class="detail-action-button" data-scroll-related>${svg("i-grid")} Similar</button><button class="detail-action-button detail-share-button" data-share-title="${escapeHTML(movie.title)}">${svg("i-share")} Share</button></div></div></section>`;
  }

  function detailCast(raw) {
    const cast=(raw.credits?.cast||[]).slice(0,10);
    return cast.length?`<section class="cast-section"><div class="episodes-heading"><div><h2>Cast</h2><p class="section-description">The cast behind this title</p></div><span class="episode-count">${cast.length} featured</span></div><div class="cast-grid">${cast.map(person=>`<article class="cast-card">${person.profile_path?`<img src="${escapeHTML(image(person.profile_path,"w185"))}" alt="${escapeHTML(person.name)}" loading="lazy">`:`<span class="cast-avatar">${escapeHTML((person.name||"?").charAt(0))}</span>`}<div><strong>${escapeHTML(person.name||"Unknown")}</strong><small>${escapeHTML(person.character||"Cast")}</small></div></article>`).join("")}</div></section>`:"";
  }

  function fallbackRelated(movie) {
    const all=cachedCatalogItems().map(item=>normalize(item));
    const related=all.filter(item=>movieKey(item)!==movieKey(movie)).sort((a,b)=>Number(b.type===movie.type)-Number(a.type===movie.type)||b.rating-a.rating).slice(0,12);
    return rail("More like this",related);
  }

  function plainAnimeDescription(value) {
    const node=document.createElement("div");
    node.innerHTML=String(value||"").replace(/<br\s*\/?\s*>/gi," ");
    return (node.textContent||"").replace(/\s+/g," ").trim();
  }

  function animeEntryRaw(item) {
    const format=animeEntryFormat(item);
    const isMovie=format==="MOVIE";
    const cover=typeof item.coverImage==="string"?item.coverImage:(item.coverImage?.extraLarge||item.coverImage?.large||item.coverImage?.medium||"");
    const numericId=Number(item.anilistId||item.malId||item.tmdbId)||Math.abs(String(item.id||"").split("").reduce((total,char)=>((total*31)+char.charCodeAt(0))|0,7));
    return {
      id:numericId,
      media_type:isMovie?"movie":"tv",
      title:isMovie?animeEntryTitle(item):undefined,
      name:isMovie?undefined:animeEntryTitle(item),
      overview:plainAnimeDescription(item.description),
      poster:cover,
      backdrop:cover,
      release_date:isMovie&&item.seasonYear?`${item.seasonYear}-01-01`:"",
      first_air_date:!isMovie&&item.seasonYear?`${item.seasonYear}-01-01`:"",
      vote_average:Number(item.averageScore||0)/10,
      genre_ids:[16],
      original_language:"ja",
      origin_country:["JP"],
      status:item.status||"",
      number_of_seasons:isMovie?0:1,
      number_of_episodes:isMovie?0:Number(item.episodeCount)||0,
      isAnime:true,
      anilistId:Number(item.anilistId)||0,
      malId:Number(item.malId)||0,
      tmdbId:Number(item.tmdbId)||0,
      anidapId:item.id||"",
    };
  }

  function animeQueryFromSlug(value) {
    return decodeURIComponent(String(value||"")).replace(/-[a-z0-9]{5,}$/i,"").replaceAll("-"," ").trim();
  }

  async function renderAnimeTitle(animeId, search) {
    setActiveRoute("anime");
    detailEpisodeState=null;
    app.innerHTML=`<div class="page"><div class="detail-hero skeleton"></div></div>`;
    try {
      const query=search.get("q")||animeQueryFromSlug(animeId);
      let item=state.animeEntries.get(String(animeId));
      const animeData=item ? {items:[item]} : await searchAnimeFranchise(query);
      const animeItems=animeData.items||[];
      rememberAnimeEntries(animeItems);
      item=item||animeItems.find(entry=>String(entry.id)===String(animeId));
      if(!item)throw new Error("AniDap could not find this anime entry.");
      const entryRaw=animeEntryRaw(item);
      const type=entryRaw.media_type;
      let raw=entryRaw;
      if(item.tmdbId){
        try{
          const tmdbRaw=await cached(`details:${type}:${item.tmdbId}:${locale()}`,()=>api.details({id:item.tmdbId,type,language:locale()}));
          raw={...tmdbRaw,...entryRaw,credits:tmdbRaw.credits,images:tmdbRaw.images,production_countries:tmdbRaw.production_countries,production_companies:tmdbRaw.production_companies,networks:tmdbRaw.networks,genres:tmdbRaw.genres};
        }catch(error){console.warn("TMDB enrichment unavailable for AniDap title; using AniDap metadata.",error);}
      }
      const movie=normalize(raw,type);
      const hasEpisodes=type!=="movie"&&Number(item.episodeCount)>0;
      const seasonRecords=hasEpisodes?[item]:[];
      setDocumentTitle(movie.title);
      app.innerHTML=`<div class="page with-hero detail-page">${detailHero(raw,movie,type,movie.id,hasEpisodes?1:0)}<div class="detail-body">${animeFranchisePanel(animeItems,item.id,query)}${hasEpisodes?`<div id="episodes-panel"></div>`:""}${detailCast(raw)}<div id="related">${fallbackRelated(movie)}</div></div></div>`;
      if(hasEpisodes){detailEpisodeState={movie,seasonCount:1,animeSeasons:seasonRecords,animeId:item.id};loadEpisodePanel(1);}
    }catch(error){app.innerHTML=`<div class="page">${errorView("Anime title unavailable",error)}</div>`;}
  }

  async function renderDetail(type,id) {
    setActiveRoute(type==="tv"?"series":type); app.innerHTML=`<div class="page"><div class="detail-hero skeleton"></div></div>`;
    try {
      detailEpisodeState=null;
      const tmdbRaw=await cached(`details:${type}:${id}:${locale()}`,()=>api.details({id,type,language:locale()}));let raw=tmdbRaw;let m=normalize(raw,type);let animeSeasons=[];let animeItems=[];let activeAnimeId="";
      if(m.isAnime){
        try{
          const animeData=await searchAnimeFranchise(m.title);
          animeItems=animeData.items||[];
          rememberAnimeEntries(animeItems);
          const matchingAnime=type==="tv"?animeSeasonRecords(animeItems,id):[];
          const activeAnime=type==="tv"?matchingAnime[0]:animeItems.find(item=>String(item.tmdbId||"")===String(id)&&animeEntryFormat(item)==="MOVIE");
          animeSeasons=type==="tv"&&activeAnime?matchingAnime:[];
          activeAnimeId=activeAnime?.id||"";
          if(type==="tv"&&activeAnime){
            raw={...tmdbRaw,number_of_seasons:0,number_of_episodes:Number(activeAnime.episodeCount)||0,anilistId:Number(activeAnime.anilistId)||0,malId:Number(activeAnime.malId)||0,tmdbId:Number(activeAnime.tmdbId)||Number(id)||0,anidapId:activeAnime.id||"",isAnime:true};
            m=normalize(raw,type);
          }
        }catch(error){console.warn("AniDap metadata unavailable; using TMDB episode metadata.",error);}
      }
      setDocumentTitle(m.title);
      const seasons=type==="tv"?(animeSeasons.length?1:Math.max(1,Number(raw.number_of_seasons)||((raw.seasons||[]).filter(s=>Number(s.season_number)>0).length)||1)):0;
      app.innerHTML=`<div class="page with-hero detail-page">${detailHero(raw,m,type,id,seasons)}<div class="detail-body">${animeFranchisePanel(animeItems,activeAnimeId,m.title)}${seasons?`<div id="episodes-panel"></div>`:""}${detailCast(raw)}<div id="related">${skeletonRail()}</div></div></div>`;
      if(seasons){detailEpisodeState={movie:m,seasonCount:seasons,animeSeasons};loadEpisodePanel(1);}
      try { const relatedRaw=await api.related({id,type,language:locale()});const related=(relatedRaw.results||[]).filter(x=>x.poster_path||x.poster).map(x=>normalize(x,type));document.querySelector("#related").innerHTML=related.length?rail("More like this",related):fallbackRelated(m); } catch { document.querySelector("#related").innerHTML=fallbackRelated(m); }
    } catch(error){
      const preview=cachedCatalogItems().find(item=>String(item.id)===String(id));
      if(preview){const m=normalize(preview,type),seasons=type==="tv"?Math.max(1,Number(preview.number_of_seasons)||Number(m.seasons)||1):0;setDocumentTitle(m.title);app.innerHTML=`<div class="page with-hero detail-page">${detailHero(preview,m,type,id,seasons)}<div class="detail-body">${seasons?`<div id="episodes-panel"></div>`:""}${detailCast(preview)}<div id="related">${fallbackRelated(m)}</div></div></div>`;if(seasons){detailEpisodeState={movie:m,seasonCount:seasons};loadEpisodePanel(1);}}else{app.innerHTML=`<div class="page">${errorView("Title unavailable",error)}</div>`;}
    }
  }

  function watchEpisodeHref(type,id,season,episode,queryString="") {
    const query=new URLSearchParams(queryString);
    query.set("season",String(Math.max(1,Number(season)||1)));
    query.set("episode",String(Math.max(1,Number(episode)||1)));
    return `#/watch/${encodeURIComponent(type)}/${encodeURIComponent(id)}?${query.toString()}`;
  }

  function watchNavigatorShell(season,episode) {
    return `<aside class="watch-navigator" id="watch-navigator" aria-label="Season and episode navigation">
      <div class="watch-navigator-head"><div><span class="eyebrow">Episode guide</span><strong id="watch-navigator-title">Browse episodes</strong></div><span class="watch-current-pill">S${season} E${episode}</span></div>
      <div class="watch-navigator-tools">
        <label class="watch-season-select"><span>Season</span><select data-watch-season aria-label="Choose season" disabled><option value="${season}">Season ${season}</option></select></label>
        <label class="watch-episode-search">${svg("i-search")}<input type="search" data-watch-filter placeholder="Find episode" inputmode="numeric" aria-label="Find episode"></label>
      </div>
      <div class="watch-episode-status"><span id="watch-episode-count">Loading episodes…</span><span>Playing <b>${episode}</b></span></div>
      <div class="watch-episode-grid is-loading" id="watch-episode-grid" aria-live="polite">${Array.from({length:30},()=>`<span class="watch-episode-skeleton"></span>`).join("")}</div>
      <div class="watch-navigator-footer" id="watch-navigator-footer"></div>
    </aside>`;
  }

  function normalizeWatchEpisodeEntries(value,total=0) {
    const source=Array.isArray(value)?value:[];
    if(source.length)return source.map((item,index)=>({
      number:Math.max(1,Number(item.episode_number||item.number)||index+1),
      title:item.name||item.title||`Episode ${Number(item.episode_number||item.number)||index+1}`,
    }));
    return Array.from({length:Math.max(0,Number(total)||0)},(_,index)=>({number:index+1,title:`Episode ${index+1}`}));
  }

  function renderWatchEpisodeGrid() {
    const nav=watchNavigatorState;
    const grid=document.querySelector("#watch-episode-grid");
    if(!nav||!grid)return;
    const filter=String(nav.filter||"").trim().toLowerCase();
    const filtered=nav.episodes.filter(item=>!filter||String(item.number).includes(filter)||item.title.toLowerCase().includes(filter));
    grid.classList.remove("is-loading");
    const showEpisodeTitles=nav.type==="tv";
    grid.classList.toggle("has-episode-titles",showEpisodeTitles);
    grid.innerHTML=filtered.length?filtered.map(item=>{
      const active=nav.season===(nav.activeGuideSeason||nav.activeSeason)&&item.number===nav.activeEpisode;
      const target=nav.guideTarget||{id:nav.id,season:nav.season,query:nav.query};
      const label=showEpisodeTitles?`Episode ${item.number}: ${item.title}`:item.title;
      const title=showEpisodeTitles?`<span class="watch-episode-title">${escapeHTML(item.title)}</span>`:"";
      return `<a class="watch-episode-number ${active?"is-active":""}" href="${watchEpisodeHref(nav.type,target.id,target.season,item.number,target.query)}" aria-label="${escapeHTML(label)}" aria-current="${active?"true":"false"}" title="${escapeHTML(item.title)}"><span class="watch-episode-index">${item.number}</span>${title}${active?svg("i-play"):""}</a>`;
    }).join(""):`<p class="watch-episode-empty">No matching episodes</p>`;
    const count=document.querySelector("#watch-episode-count");
    if(count)count.textContent=`${nav.episodes.length} episode${nav.episodes.length===1?"":"s"}`;
    const activeTarget=nav.activeEpisodeTarget||{id:nav.id,season:nav.activeSeason,query:nav.query};
    const previous=nav.activeEpisode>1?watchEpisodeHref(nav.type,activeTarget.id,activeTarget.season,nav.activeEpisode-1,activeTarget.query):"";
    const activeSeasonEpisodes=nav.season===(nav.activeGuideSeason||nav.activeSeason)?nav.episodes:[];
    const maxEpisode=activeSeasonEpisodes.length?Math.max(...activeSeasonEpisodes.map(item=>item.number)):Number(nav.totalEpisodes)||0;
    const next=maxEpisode&&nav.activeEpisode<maxEpisode?watchEpisodeHref(nav.type,activeTarget.id,activeTarget.season,nav.activeEpisode+1,activeTarget.query):"";
    const footer=document.querySelector("#watch-navigator-footer");
    if(footer)footer.innerHTML=`${previous?`<a href="${previous}">${svg("i-back")} Previous</a>`:`<span>${svg("i-back")} Previous</span>`}${next?`<a href="${next}">Next ${svg("i-arrow")}</a>`:`<span>Next ${svg("i-arrow")}</span>`}`;
  }

  function updateWatchSeasonOptions() {
    const nav=watchNavigatorState;
    const select=document.querySelector("[data-watch-season]");
    if(!nav||!select)return;
    select.innerHTML=Array.from({length:nav.seasonCount},(_,index)=>`<option value="${index+1}" ${index+1===nav.season?"selected":""}>${escapeHTML(nav.metadata?.animeSeasons?.[index]?.titleEnglish||nav.metadata?.animeSeasons?.[index]?.titleRomaji||`Season ${index+1}`)}</option>`).join("");
    select.disabled=nav.seasonCount<2;
  }

  async function loadWatchNavigatorSeason(season) {
    const nav=watchNavigatorState;
    const grid=document.querySelector("#watch-episode-grid");
    if(!nav||!grid)return;
    const requestToken=++nav.requestToken;
    nav.season=Math.min(nav.seasonCount,Math.max(1,Number(season)||1));
    nav.filter="";
    const filterInput=document.querySelector("[data-watch-filter]");
    if(filterInput)filterInput.value="";
    updateWatchSeasonOptions();
    grid.classList.add("is-loading");
    grid.innerHTML=Array.from({length:30},()=>`<span class="watch-episode-skeleton"></span>`).join("");
    try{
      let episodes=[];
      if(nav.type==="anime"&&window.PublicDROPAnimeMapping){
        const seasonSlug=nav.metadata?.animeSeasons?.[nav.season-1]?.id;
        const mapping=nav.metadata?.animeMappingVerified&&seasonSlug===nav.metadata.animexId?nav.metadata:await window.PublicDROPAnimeMapping.resolve({id:nav.id,isTmdb:new URLSearchParams(nav.query).get("isTmdb")==="1",tmdbType:nav.tmdbType,season:nav.season,episode:nav.season===nav.activeGuideSeason?nav.activeEpisode:1,seasonSlug,metadata:nav.metadata});
        const guideQuery=new URLSearchParams(nav.query);guideQuery.set("isTmdb","0");
        if(watchNavigatorState!==nav||requestToken!==nav.requestToken)return;
        nav.guideTarget={id:String(mapping.anilistId),season:1,query:guideQuery.toString()};
        const entries=normalizeAnimeEpisodes(mapping.animeEpisodeData);
        episodes=normalizeWatchEpisodeEntries(entries,entries.length);
      }else if(nav.type==="anime"&&nav.anidapId){
        const data=await api.animeEpisodes({id:nav.anidapId});
        episodes=normalizeWatchEpisodeEntries(normalizeAnimeEpisodes(data.episodes||data.results||data),nav.totalEpisodes);
      }else if(nav.type!=="anime"&&nav.tmdbId&&nav.tmdbType!=="movie"){
        const data=await api.episodes({id:nav.tmdbId,season:nav.season,language:locale()});
        episodes=normalizeWatchEpisodeEntries(data.episodes||data.results||data,nav.totalEpisodes);
      }else{
        episodes=nav.type==="anime"?[]:normalizeWatchEpisodeEntries([],nav.totalEpisodes||nav.activeEpisode);
      }
      if(!watchNavigatorState||requestToken!==watchNavigatorState.requestToken)return;
      nav.episodes=episodes;
      if(nav.type==="tv")nav.episodesBySeason.set(nav.season,episodes);
      renderWatchEpisodeGrid();
    }catch{
      if(!watchNavigatorState||requestToken!==watchNavigatorState.requestToken)return;
      nav.episodes=nav.type==="anime"?[]:normalizeWatchEpisodeEntries([],nav.totalEpisodes||nav.activeEpisode);
      renderWatchEpisodeGrid();
      const count=document.querySelector("#watch-episode-count");
      if(count)count.textContent=nav.episodes.length?`${nav.episodes.length} episodes`:`Episode list unavailable`;
    }
  }

  async function initializeWatchNavigator(type,id,season,episode,metadata,search) {
    const token=++watchNavigatorToken;
    const tmdbType=search.get("tmdbType")||"tv";
    const tmdbId=Number(metadata?.tmdbId)||(type==="tv"||search.get("isTmdb")==="1"?Number(id):0);
    watchNavigatorState={
      type,id:String(id),query:search.toString(),activeSeason:season,activeEpisode:episode,season,metadata,
      seasonCount:Math.max(1,Number(metadata?.seasons)||1),totalEpisodes:Number(metadata?.episodes)||0,
      tmdbId,tmdbType:type==="tv"?"tv":tmdbType,anidapId:metadata?.anidapId||"",episodes:[],episodesBySeason:new Map(),filter:"",requestToken:0,
    };
    if(type==="anime"&&metadata?.animeMappingVerified){
      const nav=watchNavigatorState;
      nav.seasonCount=metadata.animeSeasons.length;
      nav.season=metadata.animeSeasonIndex;
      nav.activeGuideSeason=metadata.animeSeasonIndex;
      const pill=document.querySelector(".watch-current-pill");if(pill)pill.textContent=`S${metadata.animeSeasonIndex} E${episode}`;
      const query=new URLSearchParams(nav.query);query.set("isTmdb","0");
      nav.activeEpisodeTarget={id:String(metadata.anilistId),season:1,query:query.toString()};
    }
    if(type!=="anime"&&tmdbId&&watchNavigatorState.tmdbType!=="movie"){
      try{
        const details=await cached(`details:tv:${tmdbId}:${locale()}`,()=>api.details({id:tmdbId,type:"tv",language:locale()}));
        if(token!==watchNavigatorToken||!watchNavigatorState)return;
        watchNavigatorState.seasonCount=Math.max(1,Number(details.number_of_seasons)||watchNavigatorState.seasonCount);
        watchNavigatorState.totalEpisodes=Math.max(Number(details.number_of_episodes)||0,watchNavigatorState.totalEpisodes);
        const title=document.querySelector("#watch-navigator-title");
        if(title)title.textContent=details.name||metadata?.title||"Browse episodes";
      }catch{}
    }else{
      const title=document.querySelector("#watch-navigator-title");
      if(title&&metadata?.title)title.textContent=metadata.title;
    }
    if(token!==watchNavigatorToken||!watchNavigatorState)return;
    updateWatchSeasonOptions();
    loadWatchNavigatorSeason(watchNavigatorState.season);
  }

  function watchAnimeSourcePanel() {
    return `<section class="watch-anime-source-panel" id="watch-anime-source-panel" aria-label="Anime audio and server selection"><div class="watch-anime-source-loading">Finding available servers…</div></section>`;
  }

  /* warn when the chosen audio language is probably not available for this title (TMDB knows original + spoken languages) */
  async function audioCheck(type,id,metadata) {
    const A=window.PublicDROPAudio;if(!A||type==="anime")return;
    const code=A.get(),key=`pd-audio-warn:${code}:${type}:${id}`;
    try{if(sessionStorage.getItem(key))return;}catch{}
    let source=metadata,ok=A.supports(metadata,code);
    if(ok!==true){try{source=await cached(`details:${type}:${id}:${locale()}`,()=>api.details({id,type,language:locale()}));ok=A.supports(source,code);}catch{return;}}
    if(ok!==false)return;
    try{sessionStorage.setItem(key,"1");}catch{}
    A.notice({code,title:metadata?.title||source?.title||source?.name||"",original:A.originalOf(source)||"en"});
  }
  function audioSubtitle(metadata) {
    const A=window.PublicDROPAudio;return A&&A.supports(metadata)===false?A.info(A.get()).sub:undefined;
  }
  async function mountWatchPlayer(type,id,season,episode,metadata,search) {
    const token=++watchPlayerToken;
    clearPlayerBridge();
    const mount=app.querySelector("#publicdrop-static-player");
    if(!mount)return false;
    mount.innerHTML="";
    await ensurePlayerScript();
    if(token!==watchPlayerToken||!mount.isConnected||!window.PublicDROPStaticPlayer)return false;
    playerBridgeCleanup=window.PublicDROPStaticPlayer.mount(mount,{type,id:String(id),season,episode,playbackServer:watchPlaybackServer,subtitle:audioSubtitle(metadata),dub:search.get("dub")==="dub"?"dub":"sub",isTmdb:search.get("isTmdb")==="1",tmdbType:search.get("tmdbType")||"tv",metadata,resume:embeddedResumePosition({type,id:String(id),season,episode}),onProgress:persistEmbeddedProgress});
    return true;
  }
  function isActionThrillerSeries(item) {
    return item.type==="tv"&&!item.isAnime&&!item.isCartoon&&(
      item.genres.includes(28)||item.genres.includes(53)||item.genres.includes(10759)
    );
  }

  function vumetoEmbedUrl(type,id,season,episode) {
    const base=String(config.VUMETO_EMBED_BASE_URL||config.PYTHON_EMBED_BASE_URL||"").replace(/\/$/,"");
    if(!base)return "";
    const path=type==="tv"
      ? `/embed/tv/${encodeURIComponent(id)}/${season}/${episode}`
      : `/embed/movie/${encodeURIComponent(id)}`;
    const url=new URL(base+path);
    url.searchParams.set("autoplay","1");url.searchParams.set("muted","0");url.searchParams.set("autonext","1");
    url.searchParams.set("parentOrigin",location.origin);
    const resume=embeddedResumePosition({type,id,season,episode});
    if(resume>5)url.searchParams.set("start",String(Math.floor(resume)));
    return url.href;
  }

  async function showWatchServer(server,type,id,season,episode,metadata,search) {
    watchPlaybackServer=[2,3].includes(server)?server:1;
    try{localStorage.setItem("pd-server",String(watchPlaybackServer));localStorage.setItem("pd-server-"+audioCode(),String(watchPlaybackServer));}catch{}
    document.querySelectorAll("[data-watch-server]").forEach(button=>{
      const active=Number(button.dataset.watchServer)===watchPlaybackServer;
      button.classList.toggle("is-active",active);
      button.setAttribute("aria-pressed",String(active));
    });
    const shell=app.querySelector(".watch-shell");
    if(!shell)return false;
    clearPlayerBridge();
    shell.replaceChildren();
    const mount=document.createElement("div");
    mount.className="publicdrop-static-player";
    mount.id="publicdrop-static-player";
    shell.append(mount);
    return mountWatchPlayer(type,id,season,episode,metadata,search);
  }

  async function resolveWatchAutoAdvance(nav,requestedEpisode) {
    // The visible guide may be browsing another season. Never use the show's
    // total episode count (or that guide) as the active season's boundary.
    const episodesFor=async season=>{
      const known=nav.episodesBySeason.get(season);
      if(known)return known;
      const data=await api.episodes({id:nav.tmdbId||Number(nav.id),season,language:locale()});
      const episodes=normalizeWatchEpisodeEntries(data.episodes||data.results||data);
      nav.episodesBySeason.set(season,episodes);
      return episodes;
    };
    const current=await episodesFor(nav.activeSeason);
    if(!current.length)return null;
    if(current.some(item=>item.number===requestedEpisode))return {season:nav.activeSeason,episode:requestedEpisode};
    if(requestedEpisode<=Math.max(...current.map(item=>item.number)))return null;
    for(let season=nav.activeSeason+1;season<=nav.seasonCount;season++){
      const episodes=await episodesFor(season);
      if(episodes.length)return {season,episode:Math.min(...episodes.map(item=>item.number))};
    }
    return null;
  }

  async function switchWatchEpisode(season,episode,updateHistory=true) {
    const nav=watchNavigatorState;
    if(!nav)return false;
    const nextSeason=Math.max(1,Number(season)||1);
    const nextEpisode=Math.max(1,Number(episode)||1);
    const seasonChanged=nextSeason!==nav.activeSeason;
    const currentRoute=parseRoute();
    const search=new URLSearchParams(currentRoute.search);
    search.set("season",String(nextSeason));
    search.set("episode",String(nextEpisode));
    const nextHref=watchEpisodeHref(nav.type,nav.id,nextSeason,nextEpisode,search.toString());

    nav.activeSeason=nextSeason;
    nav.activeEpisode=nextEpisode;
    nav.season=nextSeason;
    nav.query=search.toString();
    if(nav.type==="anime"&&window.PublicDROPAnimeMapping){
      let nextMetadata;
      try{nextMetadata=await window.PublicDROPAnimeMapping.resolve({id:nav.id,isTmdb:search.get("isTmdb")==="1",tmdbType:search.get("tmdbType")||"tv",season:nextSeason,episode:nextEpisode,metadata:nav.metadata});}
      catch(error){nextMetadata={...nav.metadata,animeMappingError:error.message};}
      if(watchNavigatorState!==nav||nav.activeSeason!==nextSeason||nav.activeEpisode!==nextEpisode)return false;
      nav.metadata=nextMetadata;
      if(nextMetadata.animeMappingVerified){
        nav.activeGuideSeason=nextMetadata.animeSeasonIndex;
        nav.season=nextMetadata.animeSeasonIndex;
        nav.totalEpisodes=nextMetadata.episodes;
        const targetQuery=new URLSearchParams(search);targetQuery.set("isTmdb","0");
        nav.activeEpisodeTarget={id:String(nextMetadata.anilistId),season:1,query:targetQuery.toString()};
      }
    }
    watchPlaybackContext={type:nav.type,id:nav.id,season:nextSeason,episode:nextEpisode,metadata:nav.metadata,search};
    if(updateHistory)history.pushState(null,"",nextHref);

    const pill=document.querySelector(".watch-current-pill");
    if(pill)pill.textContent=`S${nav.activeGuideSeason||nextSeason} E${nextEpisode}`;
    const playing=document.querySelector(".watch-episode-status span:last-child");
    if(playing)playing.innerHTML=`Playing <b>${nextEpisode}</b>`;
    const heading=document.querySelector(".watch-heading strong");
    if(heading)heading.textContent=`${nav.metadata?.title?`${nav.metadata.title} · `:""}Episode ${nextEpisode}`;
    renderWatchEpisodeGrid();
    if(seasonChanged||nav.type==="anime")void loadWatchNavigatorSeason(nav.type==="anime"?nav.season:nextSeason);
    await showWatchServer(watchPlaybackServer,nav.type,nav.id,nextSeason,nextEpisode,nav.metadata,search);
    return true;
  }

  async function renderWatch(type,id,search) {
    setDocumentTitle("Now playing");setActiveRoute("");removePreview();clearPlayerBridge();
    try {
      const key=playbackMetadataKey(type,id);
      let metadata=state.playbackMetadata.get(key);
      if(!metadata){try{metadata=JSON.parse(sessionStorage.getItem(`publicdrop-player-meta:${key}`)||"null");}catch{metadata=null;}}
      if(!metadata){
        const resume=continueWatchingEntries().find(entry=>entry.key===key);
        if(resume?.metadata)metadata=resume.metadata;
      }
      const season=Math.max(1,Number(search.get("season"))||1);
      const episode=Math.max(1,Number(search.get("episode"))||1);
      const animeMovie=type==="anime"&&search.get("tmdbType")==="movie"&&!Number(metadata?.episodes);
      const hasEpisodeNavigation=type==="tv"||(type==="anime"&&!animeMovie);
      watchNavigatorState=null;
      const nowPlaying=type==="anime"?`Episode ${episode}`:type==="tv"?`Season ${season} · Episode ${episode}`:"Movie";
      watchPlaybackContext={type,id:String(id),season,episode,metadata,search};
      const serverSwitch=type==="anime"?"":`<div class="watch-server-switch" aria-label="Playback server"><button type="button" data-watch-server="1" class="is-active" aria-pressed="true"><span>Server 1</span></button><button type="button" data-watch-server="2" aria-pressed="false"><span>Server 2</span></button><button type="button" data-watch-server="3" aria-pressed="false"><span>Server 3</span></button></div>`;
      app.innerHTML=`<div class="page watch-page"><div class="watch-heading"><a class="back-link" href="javascript:history.back()">${svg("i-back")} Back to details</a><div><span class="eyebrow">Now playing</span><strong>${escapeHTML(metadata?.title||"")} ${metadata?.title?"· ":""}${nowPlaying}</strong></div></div><div class="watch-layout ${hasEpisodeNavigation?"has-episode-navigation":"is-movie"}"><div class="watch-video-column"><div class="watch-shell"></div>${serverSwitch}</div>${hasEpisodeNavigation?`<div class="watch-sidebar">${type==="anime"?watchAnimeSourcePanel():""}${watchNavigatorShell(season,episode)}</div>`:""}</div></div>`;
      watchPlaybackServer=(()=>{const code=audioCode(),pick=v=>v===2||v===3?v:0;try{return pick(Number(localStorage.getItem("pd-server-"+code)))||pick(Number((config.AUDIO_DEFAULT_SERVER||{})[code]))||pick(Number(localStorage.getItem("pd-server")))||1;}catch{return 1;}})();
      if(type==="anime"&&window.PublicDROPAnimeMapping){
        try{metadata=await window.PublicDROPAnimeMapping.resolve({id:String(id),isTmdb:search.get("isTmdb")==="1",tmdbType:search.get("tmdbType")||"tv",season,episode,metadata});}
        catch(error){metadata={...(metadata||{}),animeMappingError:error.message};console.warn("AnimeX mapping unavailable",error);}
        watchPlaybackContext.metadata=metadata;
        const current=parseRoute();
        if(current.parts[0]!=="watch"||current.parts[1]!==type||String(current.parts[2])!==String(id)||Math.max(1,Number(current.search.get("season"))||1)!==season||Math.max(1,Number(current.search.get("episode"))||1)!==episode)return;
        const heading=document.querySelector(".watch-heading strong");
        if(heading&&metadata.title)heading.textContent=`${metadata.title} · ${nowPlaying}`;
      }
      await showWatchServer(watchPlaybackServer,type,id,season,episode,metadata,search);
      audioCheck(type,id,metadata);
      if(hasEpisodeNavigation)initializeWatchNavigator(type,id,season,episode,metadata,search);
    } catch(error){app.innerHTML=`<div class="page">${errorView("Stream unavailable",error)}</div>`;}
  }

  function parseRoute() {
    const raw=(location.hash||"#/").slice(1);
    if(/^(?:access_token|refresh_token|expires_in|token_type|error|error_code|error_description)=/i.test(raw))return {parts:[],search:new URLSearchParams()};
    const [path,query=""]=raw.split("?");
    return {parts:path.split("/").filter(Boolean),search:new URLSearchParams(query)};
  }
  function renderLoginWall() {
    setDocumentTitle("Sign in to watch");setActiveRoute("");removePreview();clearPlayerBridge();
    app.innerHTML=`<div class="page"><div class="empty-state login-wall"><div><span class="eyebrow">Members only</span><h1>Sign in to watch</h1><p>Create a free account or sign in to start watching. It only takes a moment.</p><button class="primary-button" type="button" data-login-wall>Sign in or create account</button> <a class="secondary-button" href="#/">Go home</a></div></div></div>`;
  }
  document.addEventListener("click",event=>{
    if(event.target.closest("[data-login-wall]")){event.preventDefault();window.PublicDROPAuth?.open?.();}
  });
  window.addEventListener("publicdrop:authchange",event=>{
    if(event.detail?.user&&document.querySelector("[data-login-wall]"))router();
  });
  async function router() {
    const hashAtStart=location.hash;
    const {parts,search}=parseRoute();const route=parts[0]||"home";
    if (!syncPromoRoute()) return;
    if(route==="watch"&&watchNavigatorState&&document.querySelector(".watch-page")&&parts[1]===watchNavigatorState.type&&String(parts[2])===String(watchNavigatorState.id)){
      const season=Math.max(1,Number(search.get("season"))||1);
      const episode=Math.max(1,Number(search.get("episode"))||1);
      if(season!==watchNavigatorState.activeSeason||episode!==watchNavigatorState.activeEpisode)return switchWatchEpisode(season,episode,false);
    }
    clearInterval(heroSliderTimer);clearPlayerBridge();removePreview();window.scrollTo(0,0);
    if(route==="home") return renderHome();
    if(route==="movies") return renderCatalog("movie",search.get("genre"));
    if(route==="series") return renderCatalog("tv",search.get("genre"));
    if(route==="anime") return renderCatalog("anime",search.get("genre"));
    if(route==="cartoons") return renderCatalog("cartoon",search.get("genre"));
    if(route==="sports"){
      setDocumentTitle("Live Sports");setActiveRoute("sports");
      if(window.PublicDROPSports?.render)return window.PublicDROPSports.render(app);
      app.innerHTML=`<div class="page">${errorView("Sports unavailable",new Error("The sports module could not be loaded."))}</div>`;
      return;
    }
    if(route==="explore") return renderExplore();
    if(route==="provider"&&parts[1]) return renderProvider(parts[1],search);
    if(route==="favorites") return renderFavorites();
    if(route==="detail"&&parts[1]&&parts[2]) return renderDetail(parts[1],parts[2]);
    if(route==="anime-title"&&parts[1]) return renderAnimeTitle(decodeURIComponent(parts[1]),search);
    if(route==="watch"&&parts[1]&&parts[2]){
      // Admin switch "Login required to watch": guests see a sign-in screen instead of the player (fail-open if the server is unreachable).
      let needLogin=false;
      try{needLogin=Boolean(window.PDGate&&await window.PDGate.needLogin());}catch{}
      if(location.hash!==hashAtStart)return;
      if(needLogin)return renderLoginWall();
      return renderWatch(parts[1],parts[2],search);
    }
    app.innerHTML=`<div class="page"><div class="empty-state"><div><h1>Page not found</h1><p>This corner of PublicDROP does not exist.</p><a class="primary-button" href="#/">Go home</a></div></div></div>`;
  }

  function toggleFavorite(movie) {
    const normalized=normalize(movie,movie.type);const saved=isSaved(normalized);
    state.favorites=saved?state.favorites.filter(item=>movieKey(item)!==movieKey(normalized)):[normalized,...state.favorites];storage.set("publicdrop-favorites",state.favorites);showToast(saved?"Removed from favorites":"Added to favorites");
    const nowSaved=!saved;
    window.dispatchEvent(new CustomEvent("publicdrop:favoritechange",{detail:{movie:normalized,saved:nowSaved}}));
    document.querySelectorAll("[data-favorite]").forEach(button=>{
      try{
        const item=JSON.parse(button.dataset.favorite);
        if(movieKey(normalize(item,item.type))!==movieKey(normalized))return;
        button.classList.toggle("saved",nowSaved);
        button.setAttribute("aria-pressed",String(nowSaved));
        button.setAttribute("aria-label",nowSaved?"Remove from favorites":"Add to favorites");
        button.title=nowSaved?"Saved to My List":"Add to My List";
      }catch{}
    });
  }

  let previewTimer;
  let previewCard;
  let previewPanel;

  function removePreview() {
    clearTimeout(previewTimer);
    previewCard = null;
    if (previewPanel) {
      previewPanel.classList.remove("visible");
      const panel = previewPanel;
      previewPanel = null;
      setTimeout(() => panel.remove(), 180);
    }
  }

  function previewFacts(movie) {
    if(movie.type==="movie"&&movie.runtime)return `${Math.floor(movie.runtime/60)}h ${movie.runtime%60}m`;
    if(movie.type==="tv"&&(movie.seasons||movie.episodes))return `${movie.seasons||"—"} season${movie.seasons===1?"":"s"} · ${movie.episodes||"—"} episodes`;
    return movie.isAnime?"Japanese anime":movie.type==="tv"?"TV series":"Movie";
  }

  function showPreview(cardElement) {
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
    const movie = JSON.parse(cardElement.dataset.preview);
    const detailPromise=cached(`details:${movie.type}:${movie.id}:${locale()}`,()=>api.details({id:movie.id,type:movie.type,language:locale()}));
    const rect = cardElement.getBoundingClientRect();
    const width = Math.min(365, window.innerWidth - 24);
    const estimatedHeight = 300;
    const left = Math.max(12, Math.min(rect.left + rect.width / 2 - width / 2, window.innerWidth - width - 12));
    const top = Math.max(74, Math.min(rect.top - 58, window.innerHeight - estimatedHeight - 12));
    removePreview();
    previewCard = cardElement;
    previewPanel = document.createElement("aside");
    previewPanel.className = "card-preview";
    previewPanel.style.width = `${width}px`;
    previewPanel.style.left = `${left}px`;
    previewPanel.style.top = `${top}px`;
    previewPanel.innerHTML = `<a class="preview-art" href="#/detail/${movie.type}/${movie.id}"><img src="${escapeHTML(movie.backdrop || movie.poster)}" alt="${escapeHTML(movie.title)}">${movie.logo ? `<img class="preview-logo" src="${escapeHTML(movie.logo)}" alt="">` : `<strong>${escapeHTML(movie.title)}</strong>`}<span class="preview-art-shade"></span></a><div class="preview-body"><div class="preview-actions"><a class="preview-play" href="${watchLink(movie,{season:1,episode:1})}" aria-label="Play">${svg("i-play")}</a><button class="preview-action ${isSaved(movie) ? "saved" : ""}" data-favorite='${escapeHTML(JSON.stringify(movie))}' aria-label="Add to favorites">${svg("i-heart")}</button><a class="preview-action preview-more" href="#/detail/${movie.type}/${movie.id}" aria-label="More information">${svg("i-info")}</a></div><div class="preview-meta"><b class="preview-rating">${svg("i-star")} ${Number(movie.rating || 0).toFixed(1)}</b><span>${escapeHTML(movie.year)}</span><span class="preview-quality">HD</span><span class="preview-specific">${escapeHTML(previewFacts(movie))}</span></div><div class="preview-genres">${(movie.genres||[]).slice(0,3).map(id=>`<span>${escapeHTML(genreMap[id]||"")}</span>`).join("")}</div><p>${escapeHTML(movie.overview || `Watch ${movie.title} and discover more titles like it on PublicDROP.`)}</p></div>`;
    document.body.append(previewPanel);
    previewPanel.addEventListener("mouseenter", () => clearTimeout(previewTimer));
    previewPanel.addEventListener("mouseleave", removePreview);
    requestAnimationFrame(() => requestAnimationFrame(() => previewPanel?.classList.add("visible")));
    detailPromise.then(raw=>{
      if(previewCard!==cardElement||!previewPanel)return;
      const detailed=normalize(raw,movie.type);
      const specific=previewPanel.querySelector(".preview-specific");if(specific)specific.textContent=previewFacts(detailed);
      const genres=(raw.genres||[]).map(genre=>genre.name).filter(Boolean).slice(0,3);const genreNode=previewPanel.querySelector(".preview-genres");if(genreNode&&genres.length)genreNode.innerHTML=genres.map(genre=>`<span>${escapeHTML(genre)}</span>`).join("");
      const overview=previewPanel.querySelector(".preview-body>p");if(overview&&detailed.overview)overview.textContent=detailed.overview;
    }).catch(()=>{});
  }

  let searchTimer;
  let searchRequestToken=0;
  const searchFilters={type:"all",genre:"",sort:"popularity"};

  function searchResultRow(movie) {
    const typeLabel=movie.isAnime?"Anime":movie.type==="tv"?"TV series":"Movie";
    return `<a class="live-search-result" href="#/detail/${movie.type}/${movie.id}">${movie.poster?`<img src="${escapeHTML(movie.poster)}" alt="" loading="lazy">`:`<span class="search-result-placeholder"></span>`}<span><strong>${escapeHTML(movie.title)}</strong><small>${escapeHTML(movie.year)} · ${escapeHTML(typeLabel)}${movie.rating?` · ★ ${movie.rating.toFixed(1)}`:""}</small></span>${svg("i-arrow")}</a>`;
  }

  function filterSearchResults(items) {
    let results=items.filter(item=>searchFilters.type==="all"||(searchFilters.type==="anime"?item.isAnime:item.type===searchFilters.type));
    const genre=selectedGenreFor(searchFilters.type,searchFilters.genre);
    if(genre)results=results.filter(item=>itemMatchesGenre(item,genre));
    results=[...results];
    if(searchFilters.sort==="rating")results.sort((a,b)=>b.rating-a.rating);
    else if(searchFilters.sort==="newest")results.sort((a,b)=>Number(b.year||0)-Number(a.year||0));
    else if(searchFilters.sort==="title")results.sort((a,b)=>a.title.localeCompare(b.title));
    else results.sort((a,b)=>b.popularity-a.popularity);
    return results;
  }

  function renderSearchResults(target, items, query, heading) {
    const results=filterSearchResults(items);
    target.innerHTML=results.length?`<div class="search-result-heading"><strong>${escapeHTML(heading)}</strong><span>${results.length} results</span></div><div class="live-search-list">${results.slice(0,20).map(searchResultRow).join("")}</div>`:`<p class="empty-copy">No matching results${query?` for “${escapeHTML(query)}”`:""}. Try another filter.</p>`;
  }

  async function searchCatalog(query) {
    const target=document.querySelector("#search-results");
    if(!target)return;
    const term=query.trim();
    if(!term){const picks=cachedCatalogItems().map(x=>normalize(x));renderSearchResults(target,picks,"","Trending now");return;}
    if(term.length<2){target.innerHTML=`<p class="empty-copy">Type at least two characters.</p>`;return;}
    const token=++searchRequestToken;
    target.innerHTML=`<p class="empty-copy">Searching as you type…</p>`;
    try{
      const data=await api.search({q:term,language:locale()});
      if(token!==searchRequestToken)return;
      const results=(data.results||[]).filter(item=>(item.media_type==="movie"||item.media_type==="tv")&&item.poster_path).map(item=>normalize(item));
      renderSearchResults(target,results,term,`Results for “${term}”`);
    }catch{
      if(token!==searchRequestToken)return;
      const lower=term.toLowerCase();
      const results=cachedCatalogItems().filter(item=>(item.title||item.name||"").toLowerCase().includes(lower)).map(item=>normalize(item));
      if(results.length) renderSearchResults(target,results,term,"Previously loaded results");
      else target.innerHTML=`<p class="empty-copy" role="status">Search is temporarily unavailable. Please try again.</p>`;
    }
  }

  function setupSearchFilters() {
    document.querySelectorAll('[data-search-type]').forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.searchType === searchFilters.type));
    });
    const target=document.querySelector("#search-genre-filters");
    const options=genreOptionsFor(searchFilters.type);
    if(searchFilters.genre&&!options.some(option=>option.key===searchFilters.genre))searchFilters.genre="";
    target.innerHTML=`<button type="button" class="${searchFilters.genre?"":"active"}" data-search-genre="">All</button>${options.map(option=>`<button type="button" class="${searchFilters.genre===option.key?"active":""}" data-search-genre="${option.key}">${escapeHTML(option.label)}</button>`).join("")}`;
  }

  function applyPreferences() { document.documentElement.dataset.theme=state.theme;document.documentElement.style.setProperty("--accent",state.accent);document.querySelector("#theme-toggle").checked=state.theme==="dark";document.querySelector("#language-select").value=state.language;document.querySelector("#promo-toggle").checked=promoEnabled; }
  function setupSettings() { const wrap=document.querySelector("#accent-options");wrap.innerHTML=accents.map(color=>`<button type="button" class="accent-dot ${color===state.accent?"active":""}" style="background:${color}" data-accent="${color}" aria-label="Use ${color}"></button>`).join("");wrap.addEventListener("click",e=>{const btn=e.target.closest("[data-accent]");if(!btn)return;if(window.PDTheme&&window.PDTheme.locked()){showToast("The site colour is set by the admin");return;}state.accent=btn.dataset.accent;storage.set("publicdrop-accent",state.accent);applyPreferences();wrap.querySelectorAll("button").forEach(x=>x.classList.toggle("active",x===btn));}); }

  function finishCardArtwork(art) {
    art.classList.add("is-loaded");
    const shell=art.closest(".card-art-shell");
    shell?.classList.add("is-ready");
    const card=art.closest(".media-card[data-preview]");
    if(!card)return;
    const loadLogo=()=>hydrateCardLogo(card);
    if("requestIdleCallback" in window)window.requestIdleCallback(loadLogo,{timeout:900});
    else setTimeout(loadLogo,180);
  }
  document.addEventListener("load",event=>{
    const imageNode=event.target;
    if(imageNode instanceof HTMLImageElement&&imageNode.matches(".card-art"))finishCardArtwork(imageNode);
  },true);
  document.addEventListener("error",event=>{
    const imageNode=event.target;
    if(!(imageNode instanceof HTMLImageElement))return;
    if(imageNode.matches(".card-art")){
      if(imageNode.dataset.fallbackTried!=="1"&&imageNode.dataset.fallbackSrc){
        imageNode.dataset.fallbackTried="1";
        imageNode.src=imageNode.dataset.fallbackSrc;
        return;
      }
      if(imageNode.dataset.placeholderTried!=="1"&&imageNode.dataset.placeholderSrc){
        imageNode.dataset.placeholderTried="1";
        imageNode.src=imageNode.dataset.placeholderSrc;
        return;
      }
      finishCardArtwork(imageNode);
      return;
    }
    if(imageNode.matches(".card-logo.official-logo")&&imageNode.dataset.fallbackLogo){
      const fallback=imageNode.dataset.fallbackLogo;
      imageNode.dataset.fallbackLogo="";
      imageNode.classList.remove("official-logo");
      imageNode.classList.add("fallback-logo");
      imageNode.src=fallback;
    }
  },true);

  document.addEventListener("click",event=>{
    const continueRemove=event.target.closest("[data-continue-remove]");
    if(continueRemove){
      event.preventDefault();
      event.stopPropagation();
      const key=continueRemove.dataset.continueRemove;
      const card=continueRemove.closest(".continue-card");
      removeContinueWatchingEntry(key);
      card?.classList.add("is-removing");
      setTimeout(()=>{
        const section=card?.closest(".continue-watching-section");
        card?.remove();
        if(section&&!section.querySelector(".continue-card"))section.remove();
      },180);
      showToast("Removed from Continue Watching");
      return;
    }
    const watchEpisodeLink=event.target.closest(".watch-episode-number,#watch-navigator-footer a");
    if(watchEpisodeLink&&watchNavigatorState){
      event.preventDefault();
      const href=watchEpisodeLink.getAttribute("href")||"";
      const query=new URLSearchParams((href.split("?")[1]||""));
      const targetId=decodeURIComponent((href.split("?")[0].split("/")[3]||""));
      if(targetId!==String(watchNavigatorState.id)||query.get("isTmdb")!==new URLSearchParams(watchNavigatorState.query).get("isTmdb")){
        location.hash=href.slice(1);
        return;
      }
      switchWatchEpisode(Number(query.get("season"))||watchNavigatorState.season,Number(query.get("episode"))||watchNavigatorState.activeEpisode);
      return;
    }
    const watchServerButton=event.target.closest("[data-watch-server]");
    if(watchServerButton&&watchPlaybackContext){
      if(Number(watchServerButton.dataset.watchServer)===watchPlaybackServer)return;
      const context=watchPlaybackContext;
      showWatchServer(Number(watchServerButton.dataset.watchServer),context.type,context.id,context.season,context.episode,context.metadata,context.search);
      return;
    }
    const favorite=event.target.closest("[data-favorite]");if(favorite){event.preventDefault();event.stopPropagation();toggleFavorite(JSON.parse(favorite.dataset.favorite));}
    const detailFavorite=event.target.closest("[data-detail-favorite]");if(detailFavorite){toggleFavorite(JSON.parse(detailFavorite.dataset.detailFavorite));detailFavorite.lastChild.textContent=isSaved(JSON.parse(detailFavorite.dataset.detailFavorite))?" Saved":" Add to favorites";}
    const shareButton=event.target.closest("[data-share-title]");if(shareButton){const shareData={title:shareButton.dataset.shareTitle,text:`Watch ${shareButton.dataset.shareTitle} on PublicDROP`,url:location.href};if(navigator.share)navigator.share(shareData).catch(()=>{});else navigator.clipboard?.writeText(location.href).then(()=>showToast("Link copied to clipboard")).catch(()=>showToast("Copy the page URL to share"));}
    if(event.target.closest("[data-retry]")) router();
    if(event.target.closest("[data-retry-episodes]")&&detailEpisodeState)loadEpisodePanel(detailEpisodeState.season||1,detailEpisodeState.page||1);
    if(event.target.closest("[data-scroll-top]"))window.scrollTo({top:0,behavior:"smooth"});
    if(event.target.closest("[data-scroll-related]")){document.querySelector("#related")?.scrollIntoView({behavior:"smooth",block:"start"});return;}
    if(event.target.closest("[data-open-search]"))document.querySelector("#search-button")?.click();
    if(event.target.closest("[data-open-settings]"))document.querySelector("#settings-button")?.click();
    const seasonButton=event.target.closest("[data-season]");if(seasonButton) loadEpisodePanel(Number(seasonButton.dataset.season),1);
    const episodePage=event.target.closest("[data-episode-page]");if(episodePage&&detailEpisodeState){const page=Number(episodePage.dataset.episodePage);detailEpisodeState={...detailEpisodeState,page};document.querySelector("#episodes-panel").innerHTML=episodePanel(detailEpisodeState.movie,detailEpisodeState.seasonCount,detailEpisodeState.season,detailEpisodeState.episodes,page,detailEpisodeState.animeSeasons||[]);}
    const searchTerm=event.target.closest("[data-search-term]");if(searchTerm){const input=document.querySelector("#global-search-input");input.value=searchTerm.dataset.searchTerm;searchCatalog(input.value);}
    const searchTypeButton=event.target.closest('[data-search-type]');
    if(searchTypeButton){
      const select=document.querySelector('#search-media-type');
      select.value=searchTypeButton.dataset.searchType;
      select.dispatchEvent(new Event('change',{bubbles:true}));
    }
    const searchFilterButton=event.target.closest("#search-filter-button");if(searchFilterButton){const panel=document.querySelector("#search-filter-panel");panel.hidden=!panel.hidden;searchFilterButton.setAttribute("aria-expanded",String(!panel.hidden));}
    const searchGenre=event.target.closest("[data-search-genre]");if(searchGenre){searchFilters.genre=searchGenre.dataset.searchGenre||"";document.querySelectorAll("[data-search-genre]").forEach(button=>button.classList.toggle("active",button===searchGenre));searchCatalog(document.querySelector("#global-search-input").value);}
    const searchResult=event.target.closest(".live-search-result");if(searchResult)document.querySelector("#search-dialog")?.close();
    const arrow = event.target.closest("[data-rail-scroll]");
    if (arrow) {
      const rail = arrow.closest(".rail-section, .favorites-section")?.querySelector(".media-rail");
      if (rail) rail.scrollBy({ left: (arrow.dataset.railScroll === "left" ? -1 : 1) * rail.clientWidth * .82, behavior: "smooth" });
    }
  });
  document.addEventListener("keydown",event=>{
    const rail=event.target.closest?.(".favorites-rail");
    if(!rail||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
    event.preventDefault();
    if(event.key==='Home')rail.scrollTo({left:0,behavior:'smooth'});
    else if(event.key==='End')rail.scrollTo({left:rail.scrollWidth,behavior:'smooth'});
    else rail.scrollBy({left:(event.key==='ArrowLeft'?-1:1)*rail.clientWidth*.82,behavior:'smooth'});
  });
  document.addEventListener("change",event=>{
    const seasonSelect=event.target.closest?.("[data-watch-season]");
    if(seasonSelect)loadWatchNavigatorSeason(Number(seasonSelect.value)||1);
  });
  document.addEventListener("input",event=>{
    const filter=event.target.closest?.("[data-watch-filter]");
    if(filter&&watchNavigatorState){watchNavigatorState.filter=filter.value;renderWatchEpisodeGrid();}
  });
  document.addEventListener("mouseover", event => {
    const card = event.target.closest(".media-card[data-preview]:not(.continue-card)");
    if (!card || card.contains(event.relatedTarget) || card === previewCard) return;
    clearTimeout(previewTimer);
    previewTimer = setTimeout(() => showPreview(card), 320);
  });
  document.addEventListener("mouseout", event => {
    const card = event.target.closest(".media-card[data-preview]:not(.continue-card)");
    if (!card || card.contains(event.relatedTarget)) return;
    clearTimeout(previewTimer);
    previewTimer = setTimeout(() => {
      if (!previewPanel?.matches(":hover")) removePreview();
    }, 170);
  });
  window.addEventListener("scroll", removePreview, { passive: true });
  window.addEventListener("publicdrop:data-synced",()=>{
    state.favorites=storage.get("publicdrop-favorites",[]);
    const route=parseRoute().parts[0]||"home";
    if(route==="home"||route==="favorites")router();
    else document.querySelectorAll("[data-favorite]").forEach(button=>{
      try{
        const item=normalize(JSON.parse(button.dataset.favorite),JSON.parse(button.dataset.favorite).type);
        const saved=isSaved(item);
        button.classList.toggle("saved",saved);
        button.setAttribute("aria-pressed",String(saved));
      }catch{}
    });
  });
  window.addEventListener("hashchange",router);
  window.addEventListener("publicdrop:progresschange",refreshContinueWatchingRail);
  window.addEventListener("pageshow",event=>{ if (event.persisted) refreshContinueWatchingRail(); });
  window.addEventListener("publicdrop:player-episode-change",async event=>{
    if(!watchNavigatorState)return;
    event.preventDefault();
    const detail=event.detail||{};
    let nextSeason=Math.max(1,Number(detail.season)||watchNavigatorState.activeSeason);
    let nextEpisode=Math.max(1,Number(detail.episode)||watchNavigatorState.activeEpisode);
    if(detail.automatic&&watchNavigatorState.type==="tv"){
      const nav=watchNavigatorState;
      const season=nav.activeSeason,episode=nav.activeEpisode;
      if(String(detail.id)!==nav.id||detail.type!==nav.type||nextSeason!==season||nextEpisode!==episode+1||nav.autoAdvancePending)return;
      nav.autoAdvancePending=true;
      try{
        const target=await resolveWatchAutoAdvance(nav,nextEpisode);
        if(!target||watchNavigatorState!==nav||nav.activeSeason!==season||nav.activeEpisode!==episode)return;
        const current=parseRoute();
        if(detail.dub)current.search.set("dub",detail.dub);
        nav.query=current.search.toString();
        await switchWatchEpisode(target.season,target.episode);
      }catch{showToast("Could not load the next episode. Please try the episode guide.");}
      finally{nav.autoAdvancePending=false;}
      return;
    }
    if(detail.automatic){
      const knownEpisodes=watchNavigatorState.season===watchNavigatorState.activeSeason?watchNavigatorState.episodes:[];
      const lastKnownEpisode=knownEpisodes.length?Math.max(...knownEpisodes.map(item=>Number(item.number)||0)):Number(watchNavigatorState.totalEpisodes)||0;
      if(lastKnownEpisode&&nextEpisode>lastKnownEpisode){
        if(watchNavigatorState.type==="tv"&&nextSeason<watchNavigatorState.seasonCount){
          nextSeason+=1;
          nextEpisode=1;
        }else return;
      }
    }
    const current=parseRoute();
    if(detail.dub)current.search.set("dub",detail.dub);
    watchNavigatorState.query=current.search.toString();
    switchWatchEpisode(nextSeason,nextEpisode);
  });
  window.addEventListener("publicdrop:anime-mode-change",event=>{
    if(!watchNavigatorState||watchNavigatorState.type!=="anime")return;
    const current=parseRoute();
    current.search.set("dub",event.detail?.dub==="dub"?"dub":"sub");
    watchNavigatorState.query=current.search.toString();
    history.replaceState(null,"",`#/${current.parts.map(encodeURIComponent).join("/")}?${current.search.toString()}`);
    renderWatchEpisodeGrid();
  });
  (()=>{const bar=document.querySelector("#topbar");let tick=false,was=null;const upd=()=>{tick=false;const on=window.scrollY>20;if(on!==was){was=on;if(bar)bar.classList.toggle("scrolled",on);}};window.addEventListener("scroll",()=>{if(!tick){tick=true;requestAnimationFrame(upd);}},{passive:true});upd();})();
  document.querySelector("#search-button").addEventListener("click",()=>{document.querySelector("#search-dialog").showModal();searchCatalog(document.querySelector("#global-search-input").value);setTimeout(()=>document.querySelector("#global-search-input").focus(),40);});
  document.querySelector("#mobile-search-button").addEventListener("click",()=>document.querySelector("#search-button").click());
  document.querySelector("#settings-button").addEventListener("click",()=>document.querySelector("#settings-dialog").showModal());
  document.querySelector("#global-search-input").addEventListener("input",event=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>searchCatalog(event.target.value),140);});
  document.querySelector("#search-media-type").addEventListener("change",event=>{searchFilters.type=event.target.value;setupSearchFilters();searchCatalog(document.querySelector("#global-search-input").value);});
  document.querySelector("#search-sort").addEventListener("change",event=>{searchFilters.sort=event.target.value;searchCatalog(document.querySelector("#global-search-input").value);});
  document.querySelector("#theme-toggle").addEventListener("change",event=>{if(window.PDTheme&&window.PDTheme.locked()){showToast("The site theme is set by the admin");applyPreferences();return;}state.theme=event.target.checked?"dark":"light";storage.set("publicdrop-theme",state.theme);applyPreferences();});
  document.querySelector("#promo-toggle").addEventListener("change",event=>{
    promoEnabled=event.target.checked;
    if(promoEnabled){sessionStorage.setItem(promoOnKey,"1");loadPromoScript();showToast("Promotional pop-ups enabled");return;}
    sessionStorage.removeItem(promoOnKey);
    location.reload();
  });
  document.querySelector("#language-select").addEventListener("change",event=>{state.language=event.target.value;storage.set("publicdrop-language",state.language);state.cache.clear();router();});

  /* admin changed the default theme, or this account's saved settings arrived from the cloud */
  function refreshFromStorage(reloadLanguage) {
    const previousLanguage = state.language;
    if (window.PDTheme) { const e = window.PDTheme.effective(); state.theme = e.theme; state.accent = e.accent; }
    else { state.theme = storage.get("publicdrop-theme", "dark"); state.accent = storage.get("publicdrop-accent", "#e50914"); }
    if (reloadLanguage) state.language = storage.get("publicdrop-language", config.DEFAULT_LANGUAGE);
    applyPreferences();
    document.querySelectorAll("#accent-options .accent-dot").forEach(dot => dot.classList.toggle("active", dot.dataset.accent === state.accent));
    if (reloadLanguage && state.language !== previousLanguage) { state.cache.clear(); router(); }
  }
  let lastAudio = audioCode();
  const audioChanged = () => { const now = audioCode(); if (now === lastAudio) return; lastAudio = now; state.cache.clear(); router(); };
  window.addEventListener("publicdrop:audio-changed", audioChanged);
  window.addEventListener("publicdrop:settings-loaded", audioChanged);
  window.addEventListener("pd:theme", () => { try { refreshFromStorage(false); } catch (error) { console.warn("Theme refresh skipped:", error); } });
  window.addEventListener("publicdrop:settings-loaded", () => { try { refreshFromStorage(true); } catch (error) { console.warn("Settings refresh skipped:", error); } });

  setupSettings();setupSearchFilters();applyPreferences();loadPromoScript();router().finally(()=>{
    window.PUBLICDROP_CRITICAL_UI_READY=true;
    window.dispatchEvent(new Event("publicdrop:critical-ui-ready"));
    setTimeout(()=>document.querySelector("#startup-loader").classList.add("hidden"),180);
  });
})();
