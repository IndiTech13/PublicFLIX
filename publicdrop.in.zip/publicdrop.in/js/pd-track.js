/* PublicDROP: visitor heartbeat, admin-controlled maintenance screen + home popup, push opt-in.
   Everything here is fail-open: if the backend is down or slow, the site works exactly as before. */
(function () {
  "use strict";
  if (window.__pdTrack) return;
  window.__pdTrack = true;

  var API = "/pd-api";
  var T0 = Date.now();
  var BOT = /bot|crawl|spider|headless|lighthouse/i;
  if (BOT.test(navigator.userAgent || "")) return;

  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function paragraphs(box, text) {
    String(text || "").split("\n").forEach(function (line) { if (line.trim()) box.appendChild(el("p", null, line)); });
  }
  function openModal(d) {
    document.body.appendChild(d);
    try { d.showModal(); } catch (e) { d.setAttribute("open", ""); }
  }
  function anyDialogOpen() { return !!document.querySelector("dialog[open]"); }

  /* ---------- ids + heartbeat ---------- */
  function rid() {
    var a = new Uint8Array(12);
    if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(a);
    else for (var i = 0; i < a.length; i++) a[i] = Math.floor(Math.random() * 256);
    return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join("");
  }
  function stored(store, key) {
    try { var v = store.getItem(key); if (!v) { v = rid(); store.setItem(key, v); } return v; }
    catch (e) { return rid(); }
  }
  var vid = stored(window.localStorage, "pd_vid");
  var sid = stored(window.sessionStorage, "pd_sid");

  function who() {
    try {
      var s = window.PublicDROPAuth && window.PublicDROPAuth.getSession && window.PublicDROPAuth.getSession();
      var u = s && s.user;
      if (u) { var m = u.user_metadata || {}; return { email: u.email || "", name: m.display_name || m.full_name || m.name || "" }; }
    } catch (e) {}
    return { email: "", name: "" };
  }
  function send(kind) {
    var w = who();
    var body = JSON.stringify({ vid: vid, sid: sid, t: kind, path: (location.hash || "#/").slice(0, 120), email: w.email, name: w.name });
    try { if (navigator.sendBeacon && navigator.sendBeacon(API + "/hit", new Blob([body], { type: "text/plain" }))) return; } catch (e) {}
    try { fetch(API + "/hit", { method: "POST", body: body, keepalive: true, headers: { "Content-Type": "text/plain" } }).catch(function () {}); } catch (e) {}
  }

  send("pv");
  /* when someone signs in, tell the admin panel straight away */
  window.addEventListener("publicdrop:authchange", function (e) { if (e && e.detail && e.detail.user) send("beat"); });
  var hashTimer = null;
  window.addEventListener("hashchange", function () {
    clearTimeout(hashTimer);
    hashTimer = setTimeout(function () { send("pv"); }, 400);
    tryPopup();
  });
  setInterval(function () { if (document.visibilityState === "visible") send("beat"); }, 25000);
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible") { send("beat"); fetchCfg(); }
  });

  /* ---------- styles for maintenance + popup ---------- */
  function addStyle() {
    if (document.getElementById("pdn-style")) return;
    var st = el("style"); st.id = "pdn-style";
    st.textContent =
      "dialog.pdn-maint{position:fixed;inset:0;width:100%;height:100%;max-width:none;max-height:none;margin:0;padding:24px;border:0;background:#0b0b0b;color:#fff;box-sizing:border-box;font-family:'DM Sans',system-ui,sans-serif}" +
      "dialog.pdn-maint[open]{display:flex;align-items:center;justify-content:center;text-align:center}" +
      "dialog.pdn-maint::backdrop{background:#0b0b0b}" +
      ".pdn-mbox{max-width:460px}.pdn-logo{max-width:190px;max-height:60px;margin:0 auto 26px;display:block}" +
      ".pdn-mbox h1{font-size:28px;line-height:1.2;margin:0 0 14px}.pdn-mbox p{margin:0 0 10px;color:#c9c9c9;font-size:16px;line-height:1.55}" +
      ".pdn-eta{display:inline-block;margin-top:10px;padding:8px 14px;border-radius:999px;background:#1c1c1c;border:1px solid #2c2c2c;color:#fff;font-weight:600;font-size:14px}" +
      ".pdn-spin{width:26px;height:26px;margin:26px auto 0;border:3px solid #2a2a2a;border-top-color:var(--accent,#e50914);border-radius:50%;animation:pdnspin 1s linear infinite}" +
      "@keyframes pdnspin{to{transform:rotate(360deg)}}" +
      "dialog.pdn-pop{border:0;padding:0;background:transparent;color:#fff;width:min(92vw,420px);max-width:calc(100vw - 32px);margin:auto;overflow:visible;font-family:'DM Sans',system-ui,sans-serif}" +
      "dialog.pdn-pop::backdrop{background:rgba(3,3,6,.72);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}" +
      ".pdn-card{background:#141414;border:1px solid #2c2c2c;border-radius:18px;overflow:hidden;box-shadow:0 18px 50px rgba(0,0,0,.6)}" +
      ".pdn-img{display:block;width:100%;max-height:220px;object-fit:cover}" +
      ".pdn-in{padding:20px}.pdn-in h2{margin:0 0 10px;font-size:21px;line-height:1.25}" +
      ".pdn-body p{margin:0 0 8px;color:#cfcfcf;font-size:15px;line-height:1.5}" +
      ".pdn-row{display:flex;gap:10px;margin-top:16px}.pdn-row button{flex:1;border:0;border-radius:11px;padding:12px;font:inherit;font-weight:700;cursor:pointer}" +
      ".pdn-go{background:var(--accent,#e50914);color:#fff}.pdn-x{background:#262626;color:#ddd}";
    document.head.appendChild(st);
  }

  /* ---------- maintenance screen ---------- */
  var maintOn = false, maintDlg = null, mTitle, mMsg, mEta;
  function showMaint(m) {
    addStyle();
    if (!maintDlg) {
      maintDlg = el("dialog", "pdn-maint"); maintDlg.id = "pdn-maint";
      maintDlg.addEventListener("cancel", function (e) { e.preventDefault(); });
      var box = el("div", "pdn-mbox");
      var logo = el("img", "pdn-logo"); logo.src = "/assets/publicdrop-wordmark.png"; logo.alt = "PublicDROP";
      logo.onerror = function () { logo.style.display = "none"; };
      mTitle = el("h1"); mMsg = el("div"); mEta = el("div");
      box.appendChild(logo); box.appendChild(mTitle); box.appendChild(mMsg); box.appendChild(mEta); box.appendChild(el("div", "pdn-spin"));
      maintDlg.appendChild(box);
      if (popupDlg) closePopup();
      openModal(maintDlg);
      // stop anything still playing behind the screen; the page reloads when maintenance ends
      try {
        var vs = document.querySelectorAll("video"); for (var i = 0; i < vs.length; i++) vs[i].pause();
        var fs = document.querySelectorAll("iframe"); for (var j = 0; j < fs.length; j++) fs[j].src = "about:blank";
      } catch (e) {}
    }
    mTitle.textContent = m.title || "We'll be right back";
    mMsg.textContent = ""; paragraphs(mMsg, m.message);
    mEta.textContent = "";
    if (m.eta) mEta.appendChild(el("span", "pdn-eta", m.eta));
  }
  function applyMaint(m) {
    var bypass = lsGet("pd_admin_bypass") === "1"; // set when you are logged in to /admin/ on this browser
    if (m && m.on && !bypass) {
      lsSet("pd_cfg", JSON.stringify({ t: Date.now(), m: m }));
      maintOn = true;
      showMaint(m);
    } else {
      lsDel("pd_cfg");
      if (maintOn) { maintOn = false; location.reload(); }
    }
  }

  /* ---------- home-page popup ---------- */
  var popupCfg = null, popupDlg = null, popupShownId = 0, popupTimer = null;
  function isHome() { var h = location.hash || ""; return h === "" || h === "#" || h === "#/"; }
  function dueByFreq(p) {
    var key = "pd_popup_" + p.id;
    if (p.show === "visit") { try { return !sessionStorage.getItem(key); } catch (e) { return true; } }
    var ts = Number(lsGet(key) || 0);
    if (!ts) return true;
    return p.show === "daily" ? Date.now() - ts > 86400000 : false;
  }
  function markShown(p) {
    var key = "pd_popup_" + p.id;
    if (p.show === "visit") { try { sessionStorage.setItem(key, "1"); } catch (e) {} } else lsSet(key, String(Date.now()));
  }
  function closePopup() {
    var d = popupDlg; popupDlg = null;
    if (!d) return;
    try { d.close(); } catch (e) {}
    try { d.remove(); } catch (e) {}
  }
  function goTo(url) {
    closePopup();
    if (url.charAt(0) === "#") location.hash = url;
    else if (url.indexOf("/#") === 0) location.hash = url.slice(1);
    else if (url.charAt(0) === "/") location.href = url;
    else window.open(url, "_blank", "noopener");
  }
  function showPopup(p) {
    addStyle();
    popupShownId = p.id; markShown(p);
    popupDlg = el("dialog", "pdn-pop"); popupDlg.id = "pdn-popup";
    var card = el("div", "pdn-card");
    if (p.image) {
      var img = el("img", "pdn-img"); img.alt = ""; img.loading = "lazy"; img.referrerPolicy = "no-referrer";
      img.onerror = function () { try { img.remove(); } catch (e) {} };
      img.src = p.image; card.appendChild(img);
    }
    var inner = el("div", "pdn-in");
    if (p.title) inner.appendChild(el("h2", null, p.title));
    if (p.body) { var b = el("div", "pdn-body"); paragraphs(b, p.body); inner.appendChild(b); }
    var row = el("div", "pdn-row");
    var x = el("button", "pdn-x", p.btn && p.url ? "Close" : "Got it"); x.type = "button";
    x.addEventListener("click", closePopup);
    row.appendChild(x);
    if (p.btn && p.url) {
      var go = el("button", "pdn-go", p.btn); go.type = "button";
      go.addEventListener("click", function () { goTo(p.url); });
      row.appendChild(go);
    }
    inner.appendChild(row); card.appendChild(inner); popupDlg.appendChild(card);
    popupDlg.addEventListener("click", function (e) { if (e.target === popupDlg) closePopup(); });
    popupDlg.addEventListener("close", function () { popupDlg = null; });
    openModal(popupDlg);
  }
  function tryPopup() {
    var p = popupCfg;
    if (!p || maintOn || popupDlg || popupTimer || popupShownId === p.id || !isHome() || !dueByFreq(p)) return;
    var wait = Math.max(0, (p.delay || 0) * 1000 - (Date.now() - T0));
    popupTimer = setTimeout(function () {
      popupTimer = null;
      var q = popupCfg;
      if (!q || maintOn || popupDlg || popupShownId === q.id || !isHome() || !dueByFreq(q)) return;
      if (anyDialogOpen() || (!window.PUBLICDROP_CRITICAL_UI_READY && Date.now() - T0 < 8000)) { setTimeout(tryPopup, 2500); return; }
      showPopup(q);
    }, wait);
  }
  function applyPopup(p) {
    popupCfg = p && p.on ? p : null;
    if (!popupCfg && popupDlg) closePopup();
    tryPopup();
  }

  /* ---------- config polling ---------- */
  function applyCfg(cfg) {
    if (!cfg || typeof cfg !== "object") return;
    try { applyMaint(cfg.m); } catch (e) {}
    try { applyPopup(cfg.p); } catch (e) {}
  }
  function fetchCfg() {
    var ctl = window.AbortController ? new AbortController() : null;
    var to = setTimeout(function () { if (ctl) ctl.abort(); }, 6000);
    fetch(API + "/config", { cache: "no-store", signal: ctl ? ctl.signal : undefined })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(applyCfg)
      .catch(function () {})
      .then(function () { clearTimeout(to); });
  }
  try { // show a recent maintenance state instantly, before the first fetch returns
    var cached = JSON.parse(lsGet("pd_cfg") || "null");
    if (cached && cached.m && cached.m.on && Date.now() - cached.t < 900000 && lsGet("pd_admin_bypass") !== "1") { maintOn = true; showMaint(cached.m); }
  } catch (e) {}
  fetchCfg();
  setInterval(fetchCfg, 30000);

  /* ---------- push notifications ---------- */
  var canPush = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
  if (!canPush) return;

  function keyBytes(s) {
    var pad = "=".repeat((4 - (s.length % 4)) % 4);
    var raw = atob((s + pad).replace(/-/g, "+").replace(/_/g, "/"));
    var out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }
  async function subscribe() {
    var reg = await navigator.serviceWorker.register("/sw.js");
    await navigator.serviceWorker.ready;
    var key = (await (await fetch(API + "/vapid")).json()).key;
    var sub = await reg.pushManager.getSubscription();
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes(key) });
    await fetch(API + "/subscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ subscription: sub.toJSON(), email: who().email }) });
    lsSet("pd_push_ts", String(Date.now()));
  }
  async function subscribeSafe() {
    try { await subscribe(); return true; }
    catch (e) {
      try {
        var reg = await navigator.serviceWorker.getRegistration("/");
        var old = reg && (await reg.pushManager.getSubscription());
        if (old) await old.unsubscribe();
        await subscribe();
        return true;
      } catch (e2) { return false; }
    }
  }

  if (Notification.permission === "granted") {
    if (Date.now() - Number(lsGet("pd_push_ts") || 0) > 7 * 86400000) setTimeout(subscribeSafe, 8000);
    return;
  }
  if (Notification.permission !== "default") return;
  if (Date.now() - Number(lsGet("pd_push_dismiss") || 0) < 7 * 86400000) return;

  function showBanner() {
    if (document.getElementById("pdn-banner")) return;
    var st = el("style");
    st.textContent =
      "#pdn-banner{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:9998;width:min(92vw,380px);box-sizing:border-box;background:#141414;color:#fff;border:1px solid #2c2c2c;border-radius:14px;padding:14px;font:500 14px/1.4 'DM Sans',system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.55)}" +
      "#pdn-banner p{margin:0 0 12px}#pdn-banner .r{display:flex;gap:8px;justify-content:flex-end}" +
      "#pdn-banner button{border:0;border-radius:9px;padding:9px 14px;font:inherit;font-weight:700;cursor:pointer}#pdn-yes{background:#e50914;color:#fff}#pdn-no{background:#262626;color:#ddd}";
    document.head.appendChild(st);
    var box = el("div"); box.id = "pdn-banner"; box.setAttribute("role", "dialog");
    box.appendChild(el("p", null, "\uD83D\uDD14 Get a notification when new movies and shows are added?"));
    var r = el("div", "r");
    var no = el("button", null, "Not now"); no.id = "pdn-no"; no.type = "button";
    var yes = el("button", null, "Enable"); yes.id = "pdn-yes"; yes.type = "button";
    r.appendChild(no); r.appendChild(yes); box.appendChild(r); document.body.appendChild(box);
    no.onclick = function () { lsSet("pd_push_dismiss", String(Date.now())); box.remove(); };
    yes.onclick = async function () {
      box.remove();
      var perm = await Notification.requestPermission();
      if (perm === "granted") await subscribeSafe(); else lsSet("pd_push_dismiss", String(Date.now()));
    };
  }

  setTimeout(function () {
    fetch(API + "/health").then(function (r) { return r.json(); }).then(function (h) {
      if (!h || !h.push) return;
      var tries = 0;
      var t = setInterval(function () {
        tries++;
        if (tries > 24) return clearInterval(t);
        if (!maintOn && !anyDialogOpen() && (location.hash || "").indexOf("/watch/") === -1 && document.visibilityState === "visible") { clearInterval(t); showBanner(); }
      }, 5000);
    }).catch(function () {});
  }, 30000);
})();
