/* PublicDROP: install-as-app support. Registers the service worker and shows an "Install app" button.
   Everything here is optional: if anything fails, the website keeps working exactly as before. */
(function () {
  "use strict";
  var DISMISS_KEY = "pd_install_dismissed";
  var deferred = null;
  var btn = null;

  function standalone() {
    return (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone === true;
  }
  function dismissedRecently() {
    try { var t = Number(localStorage.getItem(DISMISS_KEY) || 0); return t && Date.now() - t < 7 * 864e5; } catch (e) { return false; }
  }
  function isIOS() {
    return /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  }

  /* ---- service worker ---- */
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(function () {});
    });
  }

  /* ---- install button ---- */
  function style() {
    if (document.getElementById("pd-pwa-style")) return;
    var st = document.createElement("style"); st.id = "pd-pwa-style";
    st.textContent =
      ".pd-install{position:fixed;left:50%;bottom:calc(16px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:60;display:flex;align-items:center;gap:10px;max-width:calc(100vw - 24px);padding:10px 10px 10px 16px;border-radius:999px;background:#141414;color:#fff;border:1px solid #2c2c2c;box-shadow:0 10px 34px rgba(0,0,0,.55);font:600 14px/1.2 'DM Sans',system-ui,sans-serif}" +
      ".pd-install button{border:0;cursor:pointer;font:inherit;border-radius:999px}" +
      ".pd-install .pd-go{background:var(--accent,#e50914);color:#fff;padding:9px 16px}" +
      ".pd-install .pd-x{background:transparent;color:#aaa;width:30px;height:30px;font-size:18px;line-height:1}" +
      ".pd-install span{max-width:60vw}";
    document.head.appendChild(st);
  }
  function hide() { if (btn) { btn.remove(); btn = null; } }
  function remember() { try { localStorage.setItem(DISMISS_KEY, String(Date.now())); } catch (e) {} }

  function show(text, action) {
    if (btn || standalone() || dismissedRecently() || !document.body) return;
    style();
    btn = document.createElement("div"); btn.className = "pd-install"; btn.setAttribute("role", "region"); btn.setAttribute("aria-label", "Install PublicDROP");
    var label = document.createElement("span"); label.textContent = text;
    btn.appendChild(label);
    if (action) {
      var go = document.createElement("button"); go.type = "button"; go.className = "pd-go"; go.textContent = "Install";
      go.addEventListener("click", action); btn.appendChild(go);
    }
    var x = document.createElement("button"); x.type = "button"; x.className = "pd-x"; x.setAttribute("aria-label", "Dismiss"); x.textContent = "\u00d7";
    x.addEventListener("click", function () { remember(); hide(); });
    btn.appendChild(x);
    document.body.appendChild(btn);
  }

  function install() {
    if (!deferred) return;
    var p = deferred; deferred = null; hide();
    try {
      p.prompt();
      p.userChoice.then(function (r) { if (r && r.outcome !== "accepted") remember(); }).catch(function () {});
    } catch (e) {}
  }

  window.addEventListener("beforeinstallprompt", function (e) {
    e.preventDefault();
    deferred = e;
    setTimeout(function () { if (deferred) show("Install PublicDROP as an app", install); }, 4000);
  });
  window.addEventListener("appinstalled", function () { deferred = null; hide(); });

  /* iPhone / iPad Safari has no install prompt: show a one-line hint instead */
  if (isIOS() && !standalone()) {
    window.addEventListener("load", function () {
      setTimeout(function () { show("To install: tap Share, then Add to Home Screen", null); }, 6000);
    });
  }

  /* lets other parts of the site (or a menu button) trigger the install */
  window.PublicDROPInstall = {
    available: function () { return Boolean(deferred); },
    prompt: install,
  };
})();
