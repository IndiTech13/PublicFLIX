/* PublicDROP account center: profile (name + avatar), watch history, My List, and cloud sync of watch history.
   Everything here is additive. If this file fails to load, the rest of the website keeps working. */
(function () {
  "use strict";

  var HISTORY_KEY = "publicdrop-watch-history";
  var FAVORITES_KEY = "publicdrop-favorites";
  var AVATARS = ["a1","a2","a3","a4","a5","a6","a7","a8","a9","a10","a11","a12","a13","a14","a15","a16","a17","a18","a19","a20","a21","a22","a23","a24","a25","a26","a27","a28","a29","a30","a31","a32","a33","a34","a35","a36","a37","a38","a39","a40","a41","a42","a43","a44","a45","a46","a47","a48","a49","a50","a51","a52","a53","a54","a55","a56","a57","a58","a59","a60","a61","a62","a63","a64"];
  var AVATAR_NAMES = {a1: "Fox", a2: "Panda", a3: "Unicorn", a4: "Robot", a5: "Alien", a6: "Lion", a7: "Ninja", a8: "Astronaut", a9: "Dragon", a10: "Tiger", a11: "Ghost", a12: "Frog", a13: "Penguin", a14: "Owl", a15: "Octopus", a16: "Koala", a17: "Superhero", a18: "Wolf", a19: "Shark", a20: "T-Rex", a21: "Wizard", a22: "Bear", a23: "Cat", a24: "Pup", a25: "Vampire", a26: "Genie", a27: "Fairy", a28: "Bat", a29: "Monkey", a30: "Rabbit", a31: "Raccoon", a32: "Chick", a33: "Little Hero", a34: "Space Ranger", a35: "Wizard Kid", a36: "Pirate", a37: "Samurai", a38: "Blue Ninja", a39: "Viking", a40: "Knight", a41: "Cowboy Kid", a42: "Princess", a43: "Secret Agent", a44: "Mummy", a45: "Vampire", a46: "Dragon Kid", a47: "Alien", a48: "Sprout Buddy", a49: "Cyber Hacker", a50: "Ice Mage", a51: "Fire Hero", a52: "Cat Thief", a53: "Wolf Hoodie", a54: "Elf Archer", a55: "Rockstar", a56: "Pharaoh", a57: "Gladiator", a58: "Ghost Kid", a59: "Zombie Kid", a60: "Mermaid", a61: "Star Pilot", a62: "Detective", a63: "Robot Knight", a64: "Cyclops"};

  var auth = function () { return window.PublicDROPAuth || null; };
  var session = function () { var a = auth(); return a && a.getSession ? a.getSession() : null; };

  /* ---------- tiny helpers ---------- */
  function readList(key) {
    try { var v = JSON.parse(localStorage.getItem(key) || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; }
  }
  function writeList(key, list) { try { localStorage.setItem(key, JSON.stringify(list)); } catch (e) {} }
  function esc(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; });
  }
  function safeImg(url) { return /^(https:\/\/|\/|data:image\/)/i.test(String(url || "")) ? String(url) : ""; }
  function timeAgo(ts) {
    var s = Math.max(0, (Date.now() - Number(ts || 0)) / 1000);
    if (s < 60) return "just now";
    if (s < 3600) return Math.floor(s / 60) + " min ago";
    if (s < 86400) return Math.floor(s / 3600) + " h ago";
    if (s < 86400 * 30) return Math.floor(s / 86400) + " d ago";
    return new Date(Number(ts)).toLocaleDateString();
  }
  function clock(sec) {
    sec = Math.max(0, Math.floor(Number(sec) || 0));
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(s).padStart(2, "0");
  }
  function watchHref(e) {
    var type = ["movie", "tv", "anime"].indexOf(e.type) > -1 ? e.type : "movie";
    var q = new URLSearchParams();
    if (type !== "movie") {
      q.set("season", String(Math.max(1, Number(e.season) || 1)));
      q.set("episode", String(Math.max(1, Number(e.episode) || 1)));
    }
    if (type === "anime") {
      q.set("dub", e.dub === "dub" ? "dub" : "sub");
      if (e.isTmdb) q.set("isTmdb", "1");
      if (e.tmdbType) q.set("tmdbType", e.tmdbType);
    }
    var suffix = q.toString();
    return "#/watch/" + type + "/" + encodeURIComponent(e.id) + (suffix ? "?" + suffix : "");
  }

  /* ---------- watch history (local + cloud) ---------- */
  var pendingHistory = new Map();
  var historyTimers = new Map();
  var lastUser = "";

  function recordProgress(detail) {
    if (!detail || !detail.key) return;
    var list = readList(HISTORY_KEY);
    var key = String(detail.key);
    var idx = list.findIndex(function (x) { return x && x.key === key; });
    var item = null;
    if (detail.entry && !detail.removed) {
      var e = detail.entry;
      item = {
        key: key, type: e.type, id: String(e.id), title: e.title || "Untitled", year: e.year || "",
        poster: e.poster || "", backdrop: e.backdrop || "", season: e.season || 0, episode: e.episode || 0,
        dub: e.dub || "sub", isTmdb: Boolean(e.isTmdb), tmdbType: e.tmdbType || "",
        currentTime: Number(e.currentTime) || 0, duration: Number(e.duration) || 0,
        watchedSec: Number(e.watchedSec) || 0,
        watchedAt: Date.now(), finished: false
      };
    } else if (detail.removed && idx > -1) {
      /* removed from Continue Watching: finished only if the last position was near the end */
      var prev = list[idx];
      var ratio = prev.duration > 0 ? prev.currentTime / prev.duration : 0;
      if (ratio < 0.85 && !detail.finished) return;
      item = Object.assign({}, prev, { finished: true, watchedAt: Date.now() });
      if (detail.finished && prev.duration > 0) item.currentTime = prev.duration;
      if (detail.watchedSec != null && Number.isFinite(Number(detail.watchedSec))) item.watchedSec = Number(detail.watchedSec);
    }
    if (!item) return;
    if (idx > -1) list.splice(idx, 1);
    list.unshift(item);
    writeList(HISTORY_KEY, list.slice(0, 150));
    queueCloud(item, Boolean(detail.removed));
  }

  function queueCloud(item, now) {
    if (!session()) return;
    pendingHistory.set(item.key, item);
    if (now) { clearTimeout(historyTimers.get(item.key)); historyTimers.delete(item.key); flushHistory(item.key); return; }
    /* throttle, do not debounce: progress arrives every few seconds, so a restarting timer would never fire while someone is watching */
    if (!historyTimers.has(item.key)) historyTimers.set(item.key, setTimeout(function () { historyTimers.delete(item.key); flushHistory(item.key); }, 15000));
  }

  /* Also keep a copy on our own server (admin panel reads watch history from there) */
  function pushServer(items, clear) {
    try {
      var s = session();
      if (!s || !s.access_token) return;
      fetch("/pd-api/wh", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "Authorization": "Bearer " + s.access_token },
        body: JSON.stringify({ items: items || [], clear: !!clear }) }).catch(function () {});
    } catch (e) {}
  }

  async function flushHistory(key) {
    var item = pendingHistory.get(key);
    var s = session();
    if (!item || !s || !s.user) return;
    pendingHistory.delete(key);
    pushServer([item]);
    try {
      var client = await auth().getClient();
      await client.from("watch_history").upsert({
        user_id: s.user.id, media_key: key, history_data: item, watched_at: new Date(item.watchedAt).toISOString()
      }, { onConflict: "user_id,media_key" });
    } catch (e) { /* the table may not exist yet; local history keeps working */ }
  }

  async function syncHistory() {
    var s = session();
    if (!s || !s.user) return;
    pushServer(readList(HISTORY_KEY).slice(0, 100));
    try {
      var client = await auth().getClient();
      var res = await client.from("watch_history").select("media_key,history_data,watched_at").order("watched_at", { ascending: false }).limit(150);
      if (res.error) throw res.error;
      var map = new Map();
      (res.data || []).forEach(function (row) { if (row.history_data) map.set(row.media_key, row.history_data); });
      var localOnly = [];
      readList(HISTORY_KEY).forEach(function (item) {
        var cloud = map.get(item.key);
        if (!cloud || Number(item.watchedAt || 0) > Number(cloud.watchedAt || 0)) { map.set(item.key, item); localOnly.push(item); }
      });
      var merged = Array.from(map.values()).sort(function (a, b) { return Number(b.watchedAt || 0) - Number(a.watchedAt || 0); }).slice(0, 150);
      writeList(HISTORY_KEY, merged);
      if (localOnly.length) {
        await client.from("watch_history").upsert(localOnly.slice(0, 100).map(function (item) {
          return { user_id: s.user.id, media_key: item.key, history_data: item, watched_at: new Date(Number(item.watchedAt) || Date.now()).toISOString() };
        }), { onConflict: "user_id,media_key" });
      }
      refreshOpenTab();
    } catch (e) { /* table not created yet */ }
  }

  window.addEventListener("publicdrop:progresschange", function (event) { try { recordProgress(event.detail); } catch (e) {} });
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "hidden") Array.from(pendingHistory.keys()).forEach(flushHistory);
  });
  window.addEventListener("pagehide", function () { Array.from(pendingHistory.keys()).forEach(flushHistory); });
  window.addEventListener("publicdrop:data-synced", syncHistory);
  window.addEventListener("publicdrop:authchange", function (event) {
    var user = event.detail && event.detail.user;
    var id = user ? user.id : "";
    if (lastUser && !id) { try { localStorage.removeItem(HISTORY_KEY); } catch (e) {} }
    lastUser = id;
    if (user) { renderProfileTab(); }
  });

  /* ---------- UI ---------- */
  var dialog = null, activeTab = "profile";

  function injectStyle() {
    if (document.getElementById("pd-account-style")) return;
    var st = document.createElement("style");
    st.id = "pd-account-style";
    st.textContent = [
      ".pd-acc-links{display:grid;gap:10px;margin:16px 0 0}",
      ".pd-acc-links button{display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%;min-height:48px;padding:0 16px;border-radius:14px;border:1px solid var(--border,rgba(255,255,255,.1));background:rgba(255,255,255,.05);color:var(--text,#fff);font:600 .92rem/1 inherit;cursor:pointer}",
      ".pd-acc-links button:hover{border-color:var(--accent,#e50914)}",
      "#account-center{width:min(720px,calc(100vw - 20px));max-height:calc(100dvh - 24px);padding:0;border:1px solid var(--border,rgba(255,255,255,.1));border-radius:22px;background:var(--surface,#111319);color:var(--text,#fff);box-shadow:var(--shadow,0 28px 75px rgba(0,0,0,.5));overflow:hidden}",
      "#account-center::backdrop{background:rgba(0,0,0,.72);backdrop-filter:blur(6px)}",
      ".pd-acc{display:flex;flex-direction:column;max-height:calc(100dvh - 24px)}",
      ".pd-acc-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 20px 8px}",
      ".pd-acc-head h2{margin:0;font-size:1.25rem}",
      ".pd-acc-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border,rgba(255,255,255,.12));background:rgba(255,255,255,.06);color:inherit;font-size:20px;cursor:pointer}",
      ".pd-acc-tabs{display:flex;gap:8px;padding:6px 20px 12px;overflow-x:auto}",
      ".pd-acc-tabs button{flex:0 0 auto;padding:9px 16px;border-radius:999px;border:1px solid var(--border,rgba(255,255,255,.12));background:transparent;color:var(--muted,#969daa);font:600 .85rem/1 inherit;cursor:pointer}",
      ".pd-acc-tabs button[aria-selected=true]{background:var(--accent,#e50914);border-color:var(--accent,#e50914);color:#fff}",
      ".pd-acc-body{padding:4px 20px 22px;overflow-y:auto;min-height:260px}",
      ".pd-acc-me{display:flex;align-items:center;gap:14px;margin-bottom:18px}",
      ".pd-acc-me img{width:72px;height:72px;border-radius:50%;object-fit:cover;background:#222}",
      ".pd-acc-me strong{display:block;font-size:1.1rem}",
      ".pd-acc-me span{display:block;color:var(--muted,#969daa);font-size:.85rem;margin-top:2px;overflow-wrap:anywhere}",
      ".pd-acc-label{display:block;margin:16px 0 8px;font-size:.78rem;letter-spacing:.06em;text-transform:uppercase;color:var(--muted,#969daa)}",
      ".pd-avatars{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}",
      ".pd-avatars button{padding:0;border:3px solid transparent;border-radius:50%;background:none;cursor:pointer;aspect-ratio:1;overflow:hidden}",
      ".pd-avatars button img{width:100%;height:100%;display:block;border-radius:50%}",
      ".pd-avatars button[aria-checked=true]{border-color:var(--accent,#e50914);box-shadow:0 0 0 3px rgba(229,9,20,.25)}",
      ".pd-acc-input{width:100%;min-height:46px;padding:0 14px;border-radius:12px;border:1px solid var(--border,rgba(255,255,255,.14));background:rgba(255,255,255,.05);color:inherit;font:inherit}",
      ".pd-acc-save{margin-top:16px;width:100%;min-height:48px;border:0;border-radius:999px;background:var(--accent,#e50914);color:#fff;font:700 .95rem/1 inherit;cursor:pointer}",
      ".pd-acc-save:disabled{opacity:.6;cursor:wait}",
      ".pd-acc-msg{min-height:20px;margin:10px 0 0;font-size:.85rem;color:var(--muted,#969daa)}",
      ".pd-acc-msg.ok{color:#4ade80}.pd-acc-msg.err{color:#ff7a7a}",
      ".pd-acc-list{display:grid;gap:10px}",
      ".pd-acc-row{display:flex;gap:12px;align-items:center;padding:8px;border-radius:14px;border:1px solid var(--border,rgba(255,255,255,.08));background:rgba(255,255,255,.03);color:inherit;text-decoration:none}",
      ".pd-acc-row:hover{border-color:var(--accent,#e50914)}",
      ".pd-acc-thumb{flex:0 0 auto;width:56px;height:80px;border-radius:8px;object-fit:cover;background:#1b1e27}",
      ".pd-acc-info{min-width:0;flex:1}",
      ".pd-acc-info b{display:block;font-size:.95rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
      ".pd-acc-info small{display:block;margin-top:3px;color:var(--muted,#969daa);font-size:.78rem}",
      ".pd-acc-bar{height:4px;border-radius:4px;background:rgba(255,255,255,.14);margin-top:8px;overflow:hidden}",
      ".pd-acc-bar i{display:block;height:100%;background:var(--accent,#e50914)}",
      ".pd-acc-empty{padding:38px 10px;text-align:center;color:var(--muted,#969daa)}",
      ".pd-acc-clear{margin:14px 0 0;background:none;border:1px solid var(--border,rgba(255,255,255,.14));color:var(--muted,#969daa);padding:9px 16px;border-radius:999px;cursor:pointer;font:600 .8rem/1 inherit}"
    ].join("\n");
    document.head.appendChild(st);
  }

  function ensureDialog() {
    if (dialog) return dialog;
    injectStyle();
    dialog = document.createElement("dialog");
    dialog.id = "account-center";
    dialog.innerHTML =
      '<div class="pd-acc"><div class="pd-acc-head"><h2>My account</h2><button type="button" class="pd-acc-close" aria-label="Close">\u00d7</button></div>' +
      '<div class="pd-acc-tabs" role="tablist">' +
      '<button type="button" role="tab" data-tab="profile">Profile</button>' +
      '<button type="button" role="tab" data-tab="history">Watch history</button>' +
      '<button type="button" role="tab" data-tab="list">My List</button></div>' +
      '<div class="pd-acc-body" id="pd-acc-body"></div></div>';
    document.body.appendChild(dialog);
    dialog.querySelector(".pd-acc-close").addEventListener("click", function () { dialog.close(); });
    dialog.addEventListener("click", function (e) {
      if (e.target === dialog) dialog.close();
      var link = e.target.closest && e.target.closest("a[href^='#/']");
      if (link) dialog.close();
    });
    dialog.querySelectorAll(".pd-acc-tabs button").forEach(function (b) {
      b.addEventListener("click", function () { showTab(b.dataset.tab); });
    });
    return dialog;
  }

  function user() { var s = session(); return s && s.user ? s.user : null; }
  function avUrl(id) { var A = window.PublicDROPAvatars; return A ? A.url(id) : "/assets/avatars/" + id + ".webp?v=14"; }
  function avName(id) { var A = window.PublicDROPAvatars; return A ? A.name(id, AVATAR_NAMES[id]) : AVATAR_NAMES[id]; }
  function avatarSrc(u) {
    var id = String((u && u.user_metadata && u.user_metadata.avatar_id) || "");
    return avUrl(/^a([1-9]|[1-5]\d|6[0-4])$/.test(id) ? id : "a1");
  }
  function nameOf(u) { var a = auth(); return a && a.displayName ? a.displayName(u) : (u.email || "").split("@")[0]; }

  function renderProfileTab() {
    var body = document.getElementById("pd-acc-body");
    if (!body || activeTab !== "profile" || !dialog || !dialog.open) return;
    var u = user();
    if (!u) { body.innerHTML = '<div class="pd-acc-empty">Please sign in to see your account.</div>'; return; }
    var m = u.user_metadata || {};
    var chosen = /^a([1-9]|[1-5]\d|6[0-4])$/.test(String(m.avatar_id || "")) ? m.avatar_id : "";
    var currentName = nameOf(u);
    body.innerHTML =
      '<div class="pd-acc-me"><img alt="" src="' + esc(avatarSrc(u)) + '"><div><strong>' + esc(currentName) + '</strong><span>@' + esc(m.username || "setting-up") + '</span><span>' + esc(u.email || "") + '</span></div></div>' +
      '<span class="pd-acc-label">Choose your avatar</span><div class="pd-avatars" role="radiogroup" aria-label="Avatar">' +
      AVATARS.map(function (id) {
        return '<button type="button" role="radio" data-avatar="' + id + '" aria-checked="' + (id === chosen) + '" aria-label="' + esc(avName(id)) + '"><img alt="" src="' + avUrl(id) + '"></button>';
      }).join("") + '</div>' +
      '<label class="pd-acc-label" for="pd-acc-name">Display name</label>' +
      '<input class="pd-acc-input" id="pd-acc-name" maxlength="30" autocomplete="nickname" value="' + esc(currentName) + '">' +
      '<label class="pd-acc-label" for="pd-acc-audio">Audio language</label>' +
      '<select class="pd-acc-input" id="pd-acc-audio">' + (window.PublicDROPAudio ? window.PublicDROPAudio.options(window.PublicDROPAudio.get()) : '') + '</select>' +
      '<p class="pd-acc-msg" style="margin:6px 0 14px">The home page shows titles in this language. Default is Hindi.</p>' +
      '<button type="button" class="pd-acc-save" id="pd-acc-save">Save changes</button><p class="pd-acc-msg" id="pd-acc-msg" role="status"></p>';
    var picked = chosen;
    body.querySelectorAll("[data-avatar]").forEach(function (b) {
      b.addEventListener("click", function () {
        picked = b.dataset.avatar;
        body.querySelectorAll("[data-avatar]").forEach(function (x) { x.setAttribute("aria-checked", String(x === b)); });
      });
    });
    var save = document.getElementById("pd-acc-save"), msg = document.getElementById("pd-acc-msg");
    save.addEventListener("click", async function () {
      var changes = {};
      var typed = document.getElementById("pd-acc-name").value;
      if (typed.trim() !== currentName) changes.name = typed;
      if (picked && picked !== chosen) changes.avatar = picked;
      var audioSel = document.getElementById("pd-acc-audio"), audioChanged = !!(audioSel && window.PublicDROPAudio && audioSel.value !== window.PublicDROPAudio.get());
      if (!Object.keys(changes).length && !audioChanged) { msg.className = "pd-acc-msg"; msg.textContent = "Nothing to change."; return; }
      save.disabled = true; msg.className = "pd-acc-msg"; msg.textContent = "Saving\u2026";
      try {
        if (audioChanged) window.PublicDROPAudio.set(audioSel.value);
        if (Object.keys(changes).length) await auth().updateProfile(changes);
        msg.className = "pd-acc-msg ok"; msg.textContent = "Saved.";
        activeTab = "profile";
        setTimeout(function () { renderProfileTab(); var again = document.getElementById("pd-acc-msg"); if (again) { again.className = "pd-acc-msg ok"; again.textContent = "Saved."; } }, 50);
      } catch (e) {
        msg.className = "pd-acc-msg err"; msg.textContent = (e && e.message) || "Could not save. Please try again.";
      } finally { save.disabled = false; }
    });
  }

  function mediaRow(href, item, extra) {
    var img = safeImg(item.poster || item.backdrop);
    return '<a class="pd-acc-row" href="' + esc(href) + '">' +
      (img ? '<img class="pd-acc-thumb" loading="lazy" alt="" src="' + esc(img) + '">' : '<span class="pd-acc-thumb"></span>') +
      '<span class="pd-acc-info"><b>' + esc(item.title || "Untitled") + '</b>' + extra + '</span></a>';
  }

  function renderHistoryTab() {
    var body = document.getElementById("pd-acc-body");
    var list = readList(HISTORY_KEY).filter(function (x) { return x && x.id && x.title; });
    if (!list.length) { body.innerHTML = '<div class="pd-acc-empty">Nothing watched yet.<br>Start a movie or series and it will show up here.</div>'; return; }
    body.innerHTML = '<div class="pd-acc-list">' + list.map(function (e) {
      var label = e.type === "movie" ? "Movie" : "S" + Math.max(1, Number(e.season) || 1) + " E" + Math.max(1, Number(e.episode) || 1);
      var pct = e.duration > 0 ? Math.min(100, Math.round(e.currentTime / e.duration * 100)) : 0;
      var status = e.finished ? "Finished" : (e.duration > 0 ? "Stopped at " + clock(e.currentTime) + " (" + pct + "%)" : "Watched");
      var bar = !e.finished && pct > 0 ? '<span class="pd-acc-bar"><i style="width:' + pct + '%"></i></span>' : "";
      return mediaRow(watchHref(e), e, "<small>" + esc(label) + " \u00b7 " + esc(status) + " \u00b7 " + esc(timeAgo(e.watchedAt)) + "</small>" + bar);
    }).join("") + '</div><button type="button" class="pd-acc-clear" id="pd-acc-clear-history">Clear watch history</button>';
    document.getElementById("pd-acc-clear-history").addEventListener("click", async function () {
      if (!window.confirm("Clear your watch history?")) return;
      writeList(HISTORY_KEY, []);
      pushServer([], true);
      var s = session();
      if (s && s.user) { try { var c = await auth().getClient(); await c.from("watch_history").delete().eq("user_id", s.user.id); } catch (e) {} }
      renderHistoryTab();
    });
  }

  function renderListTab() {
    var body = document.getElementById("pd-acc-body");
    var list = readList(FAVORITES_KEY).filter(function (x) { return x && x.id && x.title && ["movie", "tv", "anime"].indexOf(x.type) > -1; });
    if (!list.length) { body.innerHTML = '<div class="pd-acc-empty">Your list is empty.<br>Tap the + or heart on any title to save it here.</div>'; return; }
    body.innerHTML = '<div class="pd-acc-list">' + list.map(function (m) {
      var kind = m.type === "tv" ? "Series" : m.type === "anime" ? "Anime" : "Movie";
      var year = m.year || (m.releaseDate ? String(m.releaseDate).slice(0, 4) : "");
      return mediaRow("#/detail/" + m.type + "/" + m.id, m, "<small>" + esc(kind) + (year ? " \u00b7 " + esc(year) : "") + "</small>");
    }).join("") + "</div>";
  }

  function showTab(tab) {
    activeTab = tab;
    dialog.querySelectorAll(".pd-acc-tabs button").forEach(function (b) { b.setAttribute("aria-selected", String(b.dataset.tab === tab)); });
    if (tab === "history") renderHistoryTab();
    else if (tab === "list") renderListTab();
    else renderProfileTab();
  }
  function refreshOpenTab() { if (dialog && dialog.open) showTab(activeTab); }

  function openCenter(tab) {
    if (!user()) { if (auth() && auth().open) auth().open(); return; }
    ensureDialog();
    var authDialog = document.getElementById("auth-dialog");
    if (authDialog && authDialog.open) authDialog.close();
    if (!dialog.open) dialog.showModal();
    showTab(tab || "profile");
  }

  /* add the buttons to the signed-in view of the existing account dialog */
  function addLinks() {
    var view = document.getElementById("auth-user-view");
    if (!view || view.querySelector(".pd-acc-links")) return;
    var wrap = document.createElement("div");
    wrap.className = "pd-acc-links";
    [["profile", "Profile & settings"], ["history", "Watch history"], ["list", "My List (liked titles)"]].forEach(function (pair) {
      var b = document.createElement("button");
      b.type = "button"; b.textContent = pair[1];
      b.addEventListener("click", function () { openCenter(pair[0]); });
      wrap.appendChild(b);
    });
    var signout = document.getElementById("auth-signout");
    if (signout) view.insertBefore(wrap, signout); else view.appendChild(wrap);
    injectStyle();
  }

  window.addEventListener("hashchange", function () { if (dialog && dialog.open) dialog.close(); });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", addLinks); else addLinks();
  injectStyle();

  window.PublicDROPAccount = { open: openCenter };
})();
