/* PublicDROP speed + smoothness helpers. Purely additive; every step is wrapped so it can never break the site. */
(function () {
  "use strict";
  var root = document.documentElement;
  try {
    /* 1. Images below the fold load lazily and decode off the main thread. */
    var skip = ".hero, .detail-hero, .topbar, .startup-loader, .brand, .pd-pop, .pd-screen, .player, #player";
    function tune(img) {
      try {
        if (!img || img.tagName !== "IMG" || img.__pdTuned) return;
        img.__pdTuned = 1;
        if (!img.hasAttribute("decoding")) img.decoding = "async";
        if (!img.hasAttribute("loading") && !(img.closest && img.closest(skip))) img.loading = "lazy";
      } catch (e) {}
    }
    function scan(node) {
      try {
        if (!node || node.nodeType !== 1) return;
        if (node.tagName === "IMG") tune(node);
        else if (node.querySelectorAll) { var l = node.querySelectorAll("img"); for (var i = 0; i < l.length; i++) tune(l[i]); }
      } catch (e) {}
    }
    var pending = [], queued = false;
    function flush() { queued = false; var n = pending; pending = []; for (var i = 0; i < n.length; i++) scan(n[i]); }
    if ("MutationObserver" in window) {
      new MutationObserver(function (muts) {
        for (var i = 0; i < muts.length; i++) for (var j = 0; j < muts[i].addedNodes.length; j++) pending.push(muts[i].addedNodes[j]);
        if (!queued) { queued = true; (window.requestAnimationFrame || setTimeout)(flush); }
      }).observe(root, { childList: true, subtree: true });
    }
    document.addEventListener("DOMContentLoaded", function () { scan(document.body); });

    /* 2. Pause decorative animations while the tab is hidden (saves battery and CPU). */
    document.addEventListener("visibilitychange", function () { root.classList.toggle("pd-hidden", document.hidden); });

    /* 3. Smooth cross-fade when the theme is switched. */
    var lastTheme = root.getAttribute("data-theme"), tm;
    if ("MutationObserver" in window) {
      new MutationObserver(function () {
        var t = root.getAttribute("data-theme");
        if (t === lastTheme) return;
        lastTheme = t;
        root.classList.add("pd-theme-anim");
        clearTimeout(tm); tm = setTimeout(function () { root.classList.remove("pd-theme-anim"); }, 450);
      }).observe(root, { attributes: true, attributeFilter: ["data-theme"] });
    }
  } catch (e) {}
})();
