(function () {
  "use strict";

  const config = window.PUBLICDROP_CONFIG;

  async function fetchJson(url, options = {}, timeoutMs = config.CATALOG_REQUEST_TIMEOUT_MS || 15000) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        cache: "no-store",
        ...options,
        headers: { Accept: "application/json", ...(options.headers || {}) },
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`API request failed (${response.status})`);
      return await response.json();
    } finally {
      clearTimeout(timeout);
    }
  }

  // Some networks block api.themoviedb.org; api.tmdb.org is TMDB's official alias. Remember whichever host answers.
  const tmdbBases = [...new Set([config.TMDB_BASE_URL, ...(config.TMDB_FALLBACK_BASE_URLS || [])].filter(Boolean))];
  let preferredBase = 0;

  async function tmdbRequest(path, params) {
    let lastError;
    const total = tmdbBases.length * 2;
    for (let attempt = 0; attempt < total; attempt += 1) {
      const index = (preferredBase + attempt) % tmdbBases.length;
      const url = new URL(`${tmdbBases[index]}${path}`);
      Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, String(value));
      });
      url.searchParams.set("api_key", config.TMDB_API_KEY);
      try {
        const data = await fetchJson(url.href);
        preferredBase = index;
        return data;
      } catch (error) {
        lastError = error;
        // A 404 means "no such title/season" — another host will say the same.
        if (/\((?:404|401)\)/.test(String(error?.message))) throw error;
        if (attempt === tmdbBases.length - 1) await new Promise(resolve => setTimeout(resolve, 350));
      }
    }
    throw lastError;
  }

  async function availableResults(requests) {
    const settled = await Promise.allSettled(requests);
    if (settled.every(item => item.status === "rejected")) throw settled[0].reason;
    return settled.map(item => item.status === "fulfilled" ? item.value : { results: [] });
  }

  function joinedGenres(...ids) {
    return [...new Set(ids.map(Number).filter(Number.isFinite).filter(Boolean))].join(",");
  }

  async function publicSeries({ type, page = 1, language = "en-US", genre = null }) {
    if (type === "anime") {
      const [series, movies] = await availableResults([
        tmdbRequest("/discover/tv", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.tv), with_original_language: "ja" }),
        tmdbRequest("/discover/movie", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.movie), with_original_language: "ja" }),
      ]);
      return { results: [
        ...(series.results || []).map(item => ({ ...item, media_type: "tv", isJapaneseAnime: true })),
        ...(movies.results || []).map(item => ({ ...item, media_type: "movie", isJapaneseAnime: true })),
      ] };
    }
    if (type === "cartoon") {
      const [series, movies] = await availableResults([
        tmdbRequest("/discover/tv", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.tv), with_original_language: "en" }),
        tmdbRequest("/discover/movie", { language, page, sort_by: "popularity.desc", include_adult: false, with_genres: joinedGenres(16,genre?.movie), with_original_language: "en" }),
      ]);
      return { results: [
        ...(series.results || []).map(item => ({ ...item, media_type: "tv", isCartoon: true })),
        ...(movies.results || []).map(item => ({ ...item, media_type: "movie", isCartoon: true })),
      ] };
    }
    const mediaType = type === "tv" ? "tv" : "movie";
    return tmdbRequest(`/discover/${mediaType}`, { language, page, sort_by: "popularity.desc", include_adult: false, without_genres: 16, with_genres: genre?.[mediaType] || "" });
  }

  const publicImages = ({ id, type, language = "en" }) =>
    tmdbRequest(`/${type}/${id}/images`, { include_image_language: `${language},null` });
  const publicSearch = ({ q, page = 1, language = "en-US" }) =>
    tmdbRequest("/search/multi", { query: q, page, language, include_adult: false });
  const publicDetails = ({ id, type, language = "en-US" }) => tmdbRequest(`/${type}/${id}`, {
    language,
    append_to_response: "credits,images,release_dates,content_ratings,external_ids,alternative_titles",
    include_image_language: "en,null",
  });
  const publicRelated = ({ id, type, page = 1, language = "en-US" }) =>
    tmdbRequest(`/${type}/${id}/recommendations`, { page, language });
  const publicEpisodes = ({ id, season = 1, language = "en-US" }) =>
    tmdbRequest(`/tv/${id}/season/${season}`, { language });
  const watchProviders = ({ type, language = "en-US" }) =>
    tmdbRequest(`/watch/providers/${type}`, { language });
  const providerCatalog = ({ id, type, page = 1, region = "US", language = "en-US" }) =>
    tmdbRequest(`/discover/${type}`, {
      language,
      page,
      include_adult: false,
      sort_by: "popularity.desc",
      watch_region: region,
      with_watch_providers: id,
    });

  async function animeSearch({ title }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-search?title=${encodeURIComponent(title)}`);
  }

  async function animeDetails({ anilistId }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-anime?anilistId=${encodeURIComponent(anilistId)}`);
  }

  async function animeEpisodes({ id }) {
    return fetchJson(`${config.ANIMEX_RELAY_BASE_URL}/animex-episodes?id=${encodeURIComponent(id)}`);
  }

  window.PublicDROPAPI = Object.freeze({
    animeDetails,
    publicSeries,
    publicImages,
    series: publicSeries,
    search: publicSearch,
    details: publicDetails,
    images: publicImages,
    related: publicRelated,
    episodes: publicEpisodes,
    watchProviders,
    providerCatalog,
    animeSearch,
    animeEpisodes,
  });
})();
