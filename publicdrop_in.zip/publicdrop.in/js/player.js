(function () {
  "use strict";
  /*
    PublicDROP player  ·  v5 (vidlink + autoembed + vidstuck + vumeto, mobile gestures, pop-up guard)

    app.js calls PublicDROPStaticPlayer.mount(container, options) and keeps the returned cleanup function.

    Providers
      Server 1  vidlink.pro     movies/TV  https://vidlink.pro/movie/{tmdb} · /tv/{tmdb}/{s}/{e} · anime /anime/{malId}/{ep}/{sub|dub}?fallback=true
      Server 2  autoembed.cc    movies/TV/cartoons  https://player.autoembed.cc/embed/movie/{tmdb} · /embed/tv/{tmdb}/{s}/{e}
                                anime: same TMDB path when the title came from TMDB, else https://anime.autoembed.cc/embed/{title-slug}-episode-{n}
      Server 3  vidstuck.cc     (movies + TV only)
      Server 4  vumeto.xyz      (movies, TV, anime)
      Server 5  vumeto.xyz      server=nova
      Vidstuck documents no anime embed URL, so on anime it falls back to vumeto.

    Everything the page can do to a cross-origin iframe is done from a layer ABOVE it:
      - Lock screen  : full-cover shield that swallows touches (hold the lock icon to unlock)
      - Brightness   : swipe up/down on the RIGHT edge  (CSS brightness() filter on the iframe)
      - Volume       : swipe up/down on the LEFT edge   (see sendVolume() — needs embed support)
      - Fullscreen   : our own button, so the lock + gestures stay on top of the video
  */
  const config = window.PUBLICDROP_CONFIG || {};
  const trimSlash = value => String(value || "").replace(/\/+$/, "");
  const VUMETO = trimSlash(config.VUMETO_EMBED_BASE_URL || config.PYTHON_EMBED_BASE_URL || "https://vumeto.xyz");
  const VIDSTUCK = trimSlash(config.VIDSTUCK_EMBED_BASE_URL || config.SERVER_ONE_EMBED_BASE_URL || "https://vidstuck.cc");
  const VIDLINK = trimSlash(config.VIDLINK_EMBED_BASE_URL || "https://vidlink.pro");
  const AUTOEMBED = trimSlash(config.AUTOEMBED_EMBED_BASE_URL || "https://player.autoembed.cc");
  const AUTOEMBED_ANIME = trimSlash(config.AUTOEMBED_ANIME_BASE_URL || "https://anime.autoembed.cc");
  const BRAND = String(config.PLAYER_BRANDING || "PublicDROP");
  const ACCENT = String(config.PLAYER_ACCENT || "e50914").replace(/^#/, "");
  const SUBTITLE = String(config.PLAYER_SUBTITLE || "english");

  const STALL_MS = Number(config.PLAYER_STALL_MS) || 25000;
  const SERVERS = {
    1: { provider: "vidlink", server: "" },
    2: { provider: "autoembed", server: "" },
    3: { provider: "vidstuck", server: String(config.VIDSTUCK_SERVER || "") },
    4: { provider: "vumeto", server: "" },
    5: { provider: "vumeto", server: "nova" },
  };
  const SERVER_COUNT = 5;
  /* Which embeds post playback messages to the page. Only those can be judged "not playing"; AutoEmbed documents none,
     so for it the stall banner stays off (it would wrongly claim a working video is stuck). */
  const SIGNALS = { vidlink: true, vidstuck: true, vumeto: true, autoembed: false };
  const audioInfo = code => { try { return window.PublicDROPAudio ? window.PublicDROPAudio.info(code) : null; } catch { return null; } };
  const BRIGHT_MIN = 0.25, BRIGHT_MAX = 1.5;
  const PREF_KEY = "publicdrop_player_prefs";
  const coarse = () => { try { return matchMedia("(pointer: coarse)").matches; } catch { return false; } };
  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

  /* ---------- preferences (brightness / volume / gestures survive episode changes) ---------- */
  const defaults = { brightness: 1, volume: 1, gestures: "auto", hinted: false, shield: config.PLAYER_AD_SHIELD !== false };
  let prefs = (() => {
    try { return { ...defaults, ...JSON.parse(localStorage.getItem(PREF_KEY) || "{}") }; } catch { return { ...defaults }; }
  })();
  const savePrefs = () => { try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch {} };
  prefs.brightness = clamp(Number(prefs.brightness) || 1, BRIGHT_MIN, BRIGHT_MAX);
  prefs.volume = clamp(Number.isFinite(Number(prefs.volume)) ? Number(prefs.volume) : 1, 0, 1);

  /* ---------- source url ---------- */
  function resumeSeconds(o, season, episode) {
    const fromApp = Number(o.resume);
    if (Number.isFinite(fromApp) && fromApp > 5) return Math.floor(fromApp);
    try {
      const key = `publicdrop_progress_${o.type}_${o.id}_${o.type === "movie" ? 0 : season}_${o.type === "movie" ? 0 : episode}`;
      const value = Number(localStorage.getItem(key));
      return Number.isFinite(value) && value > 5 ? Math.floor(value) : 0;
    } catch { return 0; }
  }

  function buildSource(o) {
    const id = encodeURIComponent(String(o.id));
    const season = Math.max(1, Number(o.season) || 1);
    const episode = Math.max(1, Number(o.episode) || 1);
    const start = resumeSeconds(o, season, episode);
    const isAnime = o.type === "anime";
    const meta = o.metadata || {};
    let choice = SERVERS[o.playbackServer] || SERVERS[1];
    if (isAnime && choice.provider === "vidstuck") choice = { provider: "vumeto", server: "" };   // vidstuck has no anime embed

    if (choice.provider === "vidlink") {
      const params = new URLSearchParams({ primaryColor: ACCENT.toUpperCase(), secondaryColor: "3A3A3A", iconColor: "FFFFFF", icons: "default", title: "false", poster: "true", autoplay: "true" });
      let path;
      if (isAnime) {
        const mal = Number(meta.malId) || 0;
        if (mal > 0) {
          path = `/anime/${mal}/${Math.max(1, Number(meta.animeEpisode) || episode)}/${o.dub === "dub" ? "dub" : "sub"}`;
          params.set("fallback", "true");
        } else if (o.isTmdb) {
          path = o.tmdbType === "movie" ? `/movie/${id}` : `/tv/${id}/${season}/${episode}`;
        } else { choice = { provider: "vumeto", server: "" }; }
      } else {
        path = o.type === "tv" ? `/tv/${id}/${season}/${episode}` : `/movie/${id}`;
      }
      if (path) {
        if (o.type === "tv" || (isAnime && !(o.isTmdb && o.tmdbType === "movie"))) params.set("nextbutton", "true");
        if (start) params.set("startAt", String(start));
        return { url: `${VIDLINK}${path}?${params}`, origin: new URL(VIDLINK).origin, provider: "vidlink" };
      }
    }

    if (choice.provider === "autoembed") {
      /* AutoEmbed documents three URL shapes: /embed/movie/{id}, /embed/tv/{id}/{s}/{e} (TMDB or tt-IMDb id) and, for anime,
         anime.autoembed.cc/embed/{title-slug}-episode-{n}. A page cannot test which one a given title answers to, so every
         usable shape is listed (best first) and the viewer can step through them with the "Another link" button. */
      const urls = [];
      const tvUrl = (tid, sn, ep) => `${AUTOEMBED}/embed/tv/${tid}/${sn}/${ep}`;
      const movieUrl = tid => `${AUTOEMBED}/embed/movie/${tid}`;
      if (!isAnime) {
        urls.push(o.type === "tv" ? tvUrl(id, season, episode) : movieUrl(id));
      } else {
        const idx = Math.max(1, Number(meta.animeSeasonIndex) || 1);
        const rec = (meta.animeSeasons || [])[idx - 1] || {};
        const ep = Math.max(1, Number(meta.animeEpisode) || episode);
        const movie = o.isTmdb ? o.tmdbType === "movie" : (o.tmdbType === "movie" || rec.format === "MOVIE");
        const tid = o.isTmdb ? id : (Number(meta.tmdbId) || 0);
        if (tid) urls.push(movie ? movieUrl(tid) : tvUrl(tid, o.isTmdb ? season : idx, o.isTmdb ? episode : ep));
        if (!movie) {
          const raw = String(meta.titleEnglish || meta.title || rec.titleEnglish || rec.titleRomaji || "").replace(/\(\d{4}\)/g, " ");
          const slug = raw.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/['\u2019]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
          const year = Number(rec.seasonYear) || 0;
          if (slug && year && !slug.endsWith("-" + year)) urls.push(`${AUTOEMBED_ANIME}/embed/${slug}-${year}-episode-${ep}`);
          if (slug) urls.push(`${AUTOEMBED_ANIME}/embed/${slug}-episode-${ep}`);
        }
      }
      if (urls.length) return { url: urls[0], alts: urls, origin: new URL(urls[0]).origin, provider: "autoembed" };
      choice = { provider: "vumeto", server: "" };
    }

    if (choice.provider === "vidstuck") {
      const path = o.type === "tv" ? `/embed/tv/${id}/${season}/${episode}` : `/embed/movie/${id}`;
      const ownLang = o.audioLang && o.audioLang !== "en" ? (audioInfo(o.audioLang) || {}).sub : "";
      const params = new URLSearchParams({ color: ACCENT, branding: BRAND, subtitle: o.subtitle || ownLang || SUBTITLE });
      if (choice.server) params.set("server", choice.server);
      if (start) params.set("progress", String(start));
      if (o.type === "tv") { params.set("nextEpisode", "true"); params.set("autoplayNextEpisode", "true"); }
      return { url: `${VIDSTUCK}${path}?${params}`, origin: new URL(VIDSTUCK).origin, provider: "vidstuck" };
    }

    const params = new URLSearchParams({ autoplay: "1", muted: "0", autonext: "1" });
    let path;
    if (isAnime) {
      const idType = o.isTmdb ? "tmdb" : "anilist";
      path = `/embed/anime/${idType}/${id}/${o.isTmdb && o.tmdbType === "movie" ? 1 : episode}`;
      if (o.isTmdb) { if (o.tmdbType === "movie") params.set("format", "movie"); else params.set("season", String(season)); }
      params.set("dub", o.dub === "dub" ? "dub" : "sub");
    } else {
      path = o.type === "tv" ? `/embed/tv/${id}/${season}/${episode}` : `/embed/movie/${id}`;
      if (choice.server) params.set("server", choice.server);
      if (start) params.set("start", String(start));
    }
    try { params.set("parentOrigin", location.origin); } catch {}
    return { url: `${VUMETO}${path}?${params}`, origin: new URL(VUMETO).origin, provider: "vumeto" };
  }

  /* ---------- styles (injected once so no extra css file is needed) ---------- */
  function injectStyles() {
    if (document.getElementById("pd-player-css")) return;
    const style = document.createElement("style");
    style.id = "pd-player-css";
    style.textContent = `
.pd-player{--pd-accent:#${ACCENT};position:absolute;inset:0;overflow:hidden;background:#000;-webkit-tap-highlight-color:transparent;font-family:"DM Sans",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.pd-frame{position:absolute;inset:0;width:100%;height:100%;border:0;display:block;background:#000;transition:filter .1s linear}
.pd-zone{position:absolute;top:16%;bottom:24%;width:28%;z-index:4;display:none;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}
.pd-zone-left{left:0}.pd-zone-right{right:0}
.pd-player.pd-gestures .pd-zone{display:block}
.pd-hud{position:absolute;z-index:7;left:50%;top:13%;transform:translate(-50%,-6px);display:flex;align-items:center;gap:10px;padding:10px 16px 10px 12px;border-radius:999px;background:rgba(10,10,14,.8);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);color:#fff;font-weight:600;font-size:13px;line-height:1;opacity:0;pointer-events:none;transition:opacity .18s ease,transform .18s ease}
.pd-hud.is-on{opacity:1;transform:translate(-50%,0)}
.pd-hud svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:none}
.pd-hud-bar{width:104px;height:4px;border-radius:2px;background:rgba(255,255,255,.24);overflow:hidden}
.pd-hud-fill{display:block;height:100%;width:50%;background:var(--pd-accent)}
.pd-hud-val{min-width:36px;text-align:right;font-variant-numeric:tabular-nums}
.pd-controls{position:absolute;z-index:8;top:calc(10px + env(safe-area-inset-top,0px));right:calc(10px + env(safe-area-inset-right,0px));display:flex;gap:8px;opacity:.55;transition:opacity .2s ease}
.pd-controls:hover,.pd-controls:focus-within,.pd-controls.is-awake{opacity:1}
.pd-btn{display:grid;place-items:center;width:40px;height:40px;padding:0;margin:0;border:1px solid rgba(255,255,255,.16);border-radius:12px;background:rgba(10,10,14,.66);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:#fff;cursor:pointer;touch-action:manipulation}
.pd-btn svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.pd-btn[aria-pressed="true"]{background:var(--pd-accent);border-color:transparent}
.pd-btn:focus-visible,.pd-banner button:focus-visible,.pd-unlock:focus-visible{outline:2px solid #fff;outline-offset:2px}
@media (pointer:coarse){.pd-btn{width:44px;height:44px}}
.pd-clickguard{position:absolute;left:0;right:0;top:0;bottom:16%;z-index:5;background:transparent;touch-action:manipulation}
.pd-clickguard-hint{position:absolute;left:50%;top:46%;transform:translate(-50%,-50%);z-index:6;padding:8px 14px;border-radius:10px;background:rgba(10,10,14,.8);color:#fff;font-size:13px;pointer-events:none;opacity:0;transition:opacity .2s}
.pd-clickguard-hint.is-on{opacity:1}
.pd-scrim{position:absolute;left:0;right:0;top:0;height:84px;z-index:3;pointer-events:none;background:linear-gradient(to bottom,rgba(0,0,0,.55),transparent)}
.pd-chip{position:absolute;z-index:7;left:calc(12px + env(safe-area-inset-left,0px));top:calc(12px + env(safe-area-inset-top,0px));display:flex;align-items:center;gap:8px;padding:6px 11px;border-radius:999px;background:rgba(10,10,14,.6);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:#fff;font-size:12px;font-weight:600;letter-spacing:.02em;pointer-events:none;opacity:.8}
.pd-chip i{width:7px;height:7px;border-radius:50%;background:var(--pd-accent);flex:none}
.pd-banner:not([hidden])~.pd-chip{display:none}
.pd-loader small{color:rgba(255,255,255,.62);font-size:12px;letter-spacing:.04em}
.pd-shield{position:absolute;inset:0;z-index:9;display:none;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}
.pd-player.is-locked .pd-shield{display:block}
.pd-player.is-locked .pd-controls,.pd-player.is-locked .pd-zone,.pd-player.is-locked .pd-banner{display:none}
.pd-unlock{position:absolute;left:calc(18px + env(safe-area-inset-left,0px));top:50%;width:60px;height:60px;padding:0;border:0;border-radius:50%;display:grid;place-items:center;background:rgba(10,10,14,.82);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:#fff;cursor:pointer;opacity:0;pointer-events:none;transform:translateY(-50%) scale(.9);transition:opacity .2s ease,transform .2s ease;touch-action:none}
.pd-shield.is-awake .pd-unlock{opacity:1;pointer-events:auto;transform:translateY(-50%) scale(1)}
.pd-unlock svg.pd-ico{position:relative;width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.pd-unlock svg.pd-ring{position:absolute;inset:0;width:100%;height:100%;transform:rotate(-90deg);fill:none;stroke:var(--pd-accent);stroke-width:3;stroke-dasharray:176;stroke-dashoffset:176}
.pd-unlock.is-holding svg.pd-ring{animation:pd-hold .7s linear forwards}
@keyframes pd-hold{to{stroke-dashoffset:0}}
.pd-shield-note{position:absolute;left:calc(90px + env(safe-area-inset-left,0px));top:50%;transform:translateY(-50%);max-width:calc(100% - 120px);color:#fff;font-size:13px;line-height:1.35;padding:8px 12px;border-radius:10px;background:rgba(10,10,14,.78);opacity:0;pointer-events:none;transition:opacity .2s ease}
.pd-shield.is-awake .pd-shield-note{opacity:1}
.pd-banner{position:absolute;z-index:8;left:calc(10px + env(safe-area-inset-left,0px));top:calc(10px + env(safe-area-inset-top,0px));max-width:calc(100% - 190px);display:flex;align-items:center;gap:8px;padding:8px 8px 8px 14px;border-radius:14px;background:rgba(10,10,14,.9);color:#fff;font-size:13px;line-height:1.3}
.pd-banner[hidden]{display:none}
.pd-banner button{flex:none;min-height:32px;padding:0 12px;border:0;border-radius:9px;background:rgba(255,255,255,.12);color:#fff;font:600 13px/1 inherit;cursor:pointer;touch-action:manipulation}
.pd-banner button.pd-primary{background:var(--pd-accent)}
.pd-pseudo-fs{position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;height:100dvh!important;max-width:none!important;margin:0!important;border:0!important;border-radius:0!important;aspect-ratio:auto!important;z-index:2147483000!important}
html.pd-no-scroll,html.pd-no-scroll body{overflow:hidden!important;overscroll-behavior:none}
.pd-loader{position:absolute;inset:0;z-index:3;display:grid;place-items:center;align-content:center;gap:16px;background:radial-gradient(circle at 50% 42%,rgba(255,255,255,.06),transparent 55%),#000;transition:opacity .5s ease,visibility .5s;pointer-events:none}
.pd-loader.is-done{opacity:0;visibility:hidden}
.pd-loader img{width:58px;height:58px;border-radius:16px;animation:pd-pulse 1.6s ease-in-out infinite}
.pd-loader i{width:128px;height:3px;border-radius:2px;background:rgba(255,255,255,.14);overflow:hidden;position:relative}
.pd-loader i::after{content:"";position:absolute;inset:0;width:40%;background:var(--pd-accent);border-radius:2px;animation:pd-slide 1.1s cubic-bezier(.4,0,.2,1) infinite}
@keyframes pd-pulse{0%,100%{transform:scale(1);opacity:.9}50%{transform:scale(1.06);opacity:1}}
@keyframes pd-slide{from{transform:translateX(-110%)}to{transform:translateX(260%)}}
.pd-btn{transition:background-color .2s,transform .15s,opacity .2s}.pd-btn:active{transform:scale(.92)}.pd-btn:hover{background:rgba(30,30,36,.85)}
@media (max-width:640px){.pd-controls{gap:6px}.pd-btn{width:38px;height:38px;border-radius:11px}.pd-banner{top:calc(58px + env(safe-area-inset-top,0px));right:calc(10px + env(safe-area-inset-right,0px));max-width:none}}
@media (prefers-reduced-motion:reduce){.pd-loader,.pd-loader img,.pd-loader i::after{animation:none;transition:none}}
@media (prefers-reduced-motion:reduce){.pd-hud,.pd-controls,.pd-unlock,.pd-shield-note,.pd-frame{transition:none}.pd-unlock.is-holding svg.pd-ring{animation-duration:.01s}}
`;
    document.head.append(style);
  }

  /* ---------- icons ---------- */
  const ICON = {
    lock: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
    unlock: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.4-2"/></svg>',
    enterFs: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
    exitFs: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>',
    gestures: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4v16M12 4v16M19 4v16"/><circle cx="5" cy="14" r="2"/><circle cx="12" cy="8" r="2"/><circle cx="19" cy="15" r="2"/></svg>',
    sun: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    volume: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/></svg>',
    prev: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5v14M19 5l-9 7 9 7z"/></svg>',
    next: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 5v14M5 5l9 7-9 7z"/></svg>',
    reload: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
    shield: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path d="M9 12l2 2 4-4"/></svg>',
    swap: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4L3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/></svg>',
    mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/></svg>',
  };
  const el = (tag, className, html) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html) node.innerHTML = html;
    return node;
  };

  /* ---------- window.open guard ----------
     A page cannot reach inside a cross-origin iframe, so pop-ups opened BY the embed are stopped by the iframe's sandbox (Ad shield).
     This guard covers the parent page: while a player is on screen, a cross-origin window.open() is dropped unless it follows a real
     tap/key on OUR page (taps inside the iframe never reach this document, so a recent gesture here is always ours). */
  (function installOpenGuard() {
    if (window.__pdOpenGuard) return;
    window.__pdOpenGuard = true;
    let lastGesture = 0;
    ["pointerdown", "touchstart", "keydown"].forEach(name => document.addEventListener(name, () => { lastGesture = Date.now(); }, true));
    const nativeOpen = window.open;
    window.open = function (url) {
      try {
        if (document.querySelector(".pd-player") && url) {
          const target = new URL(String(url), location.href);
          if (target.origin !== location.origin && Date.now() - lastGesture > 1500) { return null; }
        }
      } catch {}
      return nativeOpen.apply(window, arguments);
    };
  })();

  /* ---------- fullscreen helpers (shared) ---------- */
  const fsListeners = new Set();
  const nativeFsElement = () => document.fullscreenElement || document.webkitFullscreenElement || null;
  ["fullscreenchange", "webkitfullscreenchange"].forEach(name => document.addEventListener(name, () => fsListeners.forEach(fn => fn())));
  window.addEventListener("hashchange", () => setTimeout(() => {
    if (document.querySelector(".pd-player")) return;
    document.documentElement.classList.remove("pd-no-scroll");
    if (nativeFsElement()) (document.exitFullscreen || document.webkitExitFullscreen)?.call(document);
    try { screen.orientation?.unlock?.(); } catch {}
  }, 0));

  /* ---------- mount ---------- */
  function mount(container, rawOptions) {
    injectStyles();
    const options = rawOptions || {};
    let src = buildSource(options), altIndex = 0;
    const isTv = options.type === "tv";
    const touch = coarse();
    // On phones the embed's own fullscreen button would hide our lock + gestures, so we own fullscreen there.
    const customFs = config.PLAYER_CUSTOM_FULLSCREEN === true || (config.PLAYER_CUSTOM_FULLSCREEN !== false && touch);
    const target = container.closest(".watch-shell") || container;
    const cur = { season: Math.max(1, Number(options.season) || 1), episode: Math.max(1, Number(options.episode) || 1), ratio: 0, signal: false, lastReport: 0 };
    let dead = false, hudTimer = 0, awakeTimer = 0, holdTimer = 0, stallTimer = 0, ctlTimer = 0, wakeLock = null;

    /* DOM */
    const wrapper = el("div", "pd-player");
    const frame = document.createElement("iframe");
    frame.className = "pd-frame";
    frame.title = `PublicDROP video player · Server ${Number(options.playbackServer) || 1}`;
    frame.allow = customFs ? "autoplay; encrypted-media; picture-in-picture" : "autoplay; fullscreen; encrypted-media; picture-in-picture";
    frame.allowFullscreen = !customFs;
    frame.referrerPolicy = "strict-origin-when-cross-origin";
    /* Ad shield: a sandboxed frame cannot open pop-ups/new tabs or redirect the page, which is how most embed ads work.
       Scripts, playback, fullscreen and the embed's own player keep working. Toggle with the shield button (or key A). */
    const SHIELD_FLAGS = "allow-scripts allow-same-origin allow-forms allow-presentation allow-orientation-lock allow-pointer-lock";
    /* the shield is remembered per server, so one server that dislikes it never affects the others */
    const shieldKey = String(Number(options.playbackServer) || 1);
    /* Server 3 (vidstuck) refuses to play inside a sandboxed frame ("Sandbox Detected"), so its shield starts OFF. */
    const SHIELD_OFF_BY_DEFAULT = { "3": true };
    const shieldOn = () => {
      if (prefs.shield === false) return false;
      const saved = prefs.shieldOff && prefs.shieldOff[shieldKey];
      return saved === undefined ? !SHIELD_OFF_BY_DEFAULT[shieldKey] : !saved;
    };
    const applyShield = () => { if (shieldOn()) frame.setAttribute("sandbox", SHIELD_FLAGS); else frame.removeAttribute("sandbox"); };
    applyShield();
    try {
      if (!document.getElementById("pd-preconnect")) {
        [VIDLINK, AUTOEMBED, VIDSTUCK, VUMETO].forEach((origin, i) => { const l = document.createElement("link"); l.rel = "preconnect"; l.href = origin; l.crossOrigin = ""; if (i === 0) l.id = "pd-preconnect"; document.head.append(l); });
      }
    } catch {}

    const zoneLeft = el("div", "pd-zone pd-zone-left");
    const zoneRight = el("div", "pd-zone pd-zone-right");
    zoneLeft.dataset.zone = "volume";
    zoneRight.dataset.zone = "brightness";

    const hud = el("div", "pd-hud");
    hud.setAttribute("role", "status");
    hud.setAttribute("aria-live", "polite");
    const hudIcon = el("span");
    const hudBar = el("span", "pd-hud-bar", '<span class="pd-hud-fill"></span>');
    const hudFill = hudBar.firstChild;
    const hudVal = el("span", "pd-hud-val");
    hud.append(hudIcon, hudBar, hudVal);

    const controls = el("div", "pd-controls");
    const btn = (label, html) => { const b = el("button", "pd-btn", html); b.type = "button"; b.setAttribute("aria-label", label); b.title = label; return b; };
    const gestureBtn = btn("Swipe gestures", ICON.gestures);
    const lockBtn = btn("Lock screen", ICON.lock);
    const fsBtn = btn("Fullscreen", ICON.enterFs);
    const hasEps = options.type === "tv" || options.type === "anime";
    const prevBtn = btn("Previous episode (P)", ICON.prev), nextBtn = btn("Next episode (N)", ICON.next);
    const reloadBtn = btn("Reload video (R)", ICON.reload);
    const shieldBtn = btn("Ad shield (A)", ICON.shield);
    const altBtn = btn("Another AutoEmbed link (V)", ICON.swap);
    const hasAlts = Boolean(src.alts && src.alts.length > 1);
    controls.append(...(hasEps ? [prevBtn, nextBtn] : []), ...(hasAlts ? [altBtn] : []), reloadBtn, shieldBtn, gestureBtn, lockBtn, fsBtn);
    lockBtn.title = "Lock screen (L)"; gestureBtn.title = "Swipe gestures (G)"; fsBtn.title = "Fullscreen (F)";
    const langInfo = options.audioLang ? audioInfo(options.audioLang) : null;
    const loader = el("div", "pd-loader", '<img src="/assets/publicdrop-favicon.png" alt="" width="58" height="58"><i></i><small></small>');
    loader.querySelector("small").textContent = `Loading Server ${Number(options.playbackServer) || 1}${langInfo && options.audioLang !== "en" ? " \u00b7 " + langInfo.name : ""}\u2026`;
    const scrim = el("div", "pd-scrim");
    const chip = el("div", "pd-chip", "<i></i><span></span>");
    chip.lastChild.textContent = `Server ${Number(options.playbackServer) || 1}${langInfo ? " \u00b7 " + langInfo.name : ""}`;

    const banner = el("div", "pd-banner");
    banner.hidden = true;

    const shield = el("div", "pd-shield");
    const unlockBtn = el("button", "pd-unlock", `${ICON.unlock.replace("<svg ", '<svg class="pd-ico" ')}<svg class="pd-ring" viewBox="0 0 60 60" aria-hidden="true"><circle cx="30" cy="30" r="28"/></svg>`);
    unlockBtn.type = "button";
    unlockBtn.setAttribute("aria-label", "Hold to unlock screen");
    const shieldNote = el("div", "pd-shield-note", "Screen locked.<br>Hold the lock to unlock.");
    shield.append(shieldNote, unlockBtn);

    wrapper.append(frame, scrim, loader, zoneLeft, zoneRight, hud, controls, banner, chip, shield);
    /* Click guard (config.PLAYER_CLICK_GUARD = true): a transparent layer over the video (not the bottom control bar) swallows
       the FIRST tap, because most embed pop-ups fire on the first click. After that tap it removes itself so the player is fully usable. */
    if (config.PLAYER_CLICK_GUARD === true) {
      const guard = el("div", "pd-clickguard"), hint = el("div", "pd-clickguard-hint", "Tap again to play");
      let gone = false;
      const drop = () => { if (gone) return; gone = true; guard.remove(); setTimeout(() => hint.remove(), 1600); };
      guard.addEventListener("pointerdown", event => { event.preventDefault(); event.stopPropagation(); hint.classList.add("is-on"); setTimeout(() => hint.classList.remove("is-on"), 1400); drop(); });
      wrapper.append(guard, hint);
    }
    container.replaceChildren(wrapper);
    frame.src = src.url;

    /* state sync */
    const isFs = () => nativeFsElement() === target || target.classList.contains("pd-pseudo-fs");
    const isLocked = () => target.dataset.pdLocked === "1";
    const gesturesOn = () => prefs.gestures === "on" || (prefs.gestures === "auto" && touch && isFs());
    function sync() {
      if (dead) return;
      const fs = isFs(), locked = isLocked(), gestures = gesturesOn();
      wrapper.classList.toggle("is-locked", locked);
      wrapper.classList.toggle("pd-gestures", gestures && !locked);
      gestureBtn.setAttribute("aria-pressed", String(gestures));
      fsBtn.innerHTML = fs ? ICON.exitFs : ICON.enterFs;
      fsBtn.setAttribute("aria-label", fs ? "Exit fullscreen" : "Fullscreen");
      fsBtn.title = fsBtn.getAttribute("aria-label") + " (F)";
      lockBtn.setAttribute("aria-pressed", String(locked));
      shieldBtn.setAttribute("aria-pressed", String(shieldOn()));
      shieldBtn.title = shieldOn() ? "Ad shield is ON (A)" : "Ad shield is OFF (A)";
    }
    fsListeners.add(sync);

    /* brightness + volume */
    function applyBrightness() { frame.style.filter = Math.abs(prefs.brightness - 1) < 0.01 ? "" : `brightness(${prefs.brightness.toFixed(2)})`; }
    function showHud(kind, level, percentText) {
      hudIcon.innerHTML = kind === "brightness" ? ICON.sun : (prefs.volume <= 0.001 ? ICON.mute : ICON.volume);
      hudFill.style.width = `${Math.round(level * 100)}%`;
      hudVal.textContent = percentText;
      hud.classList.add("is-on");
      clearTimeout(hudTimer);
      hudTimer = setTimeout(() => hud.classList.remove("is-on"), 900);
    }
    function setBrightness(value) {
      prefs.brightness = clamp(value, BRIGHT_MIN, BRIGHT_MAX);
      applyBrightness();
      showHud("brightness", (prefs.brightness - BRIGHT_MIN) / (BRIGHT_MAX - BRIGHT_MIN), `${Math.round(prefs.brightness * 100)}%`);
    }
    /*
      Volume: a page cannot read or change the audio of a cross-origin iframe. This sends a best-effort
      postMessage; it only has an effect if the embed implements it. To use a different message format set
      PUBLICDROP_CONFIG.PLAYER_VOLUME_MESSAGE = volume01 => ({ ... }) in js/config.js.
    */
    function sendVolume(value) {
      const win = frame.contentWindow;
      if (!win) return;
      const custom = typeof config.PLAYER_VOLUME_MESSAGE === "function" ? config.PLAYER_VOLUME_MESSAGE : null;
      const messages = custom ? [custom(value)] : [{ type: "setVolume", volume: value }, { type: "volume", volume: value }];
      messages.filter(Boolean).forEach(message => {
        try { win.postMessage(message, src.origin); win.postMessage(JSON.stringify(message), src.origin); } catch {}
      });
    }
    function setVolume(value) {
      prefs.volume = clamp(value, 0, 1);
      sendVolume(prefs.volume);
      showHud("volume", prefs.volume, `${Math.round(prefs.volume * 100)}%`);
    }
    applyBrightness();
    let loaderTimer = 0;
    const hideLoader = () => { clearTimeout(loaderTimer); loader.classList.add("is-done"); };
    const showLoader = () => { loader.classList.remove("is-done"); clearTimeout(loaderTimer); loaderTimer = setTimeout(hideLoader, 15000); };
    showLoader();
    frame.addEventListener("load", () => { if (frame.src && frame.src !== "about:blank" && !/^about:/.test(frame.src)) setTimeout(hideLoader, 350); if (prefs.volume < 1) sendVolume(prefs.volume); });

    /* swipe zones */
    function bindZone(zone, kind) {
      let active = null;
      zone.addEventListener("pointerdown", event => {
        if (isLocked() || !gesturesOn()) return;
        try { zone.setPointerCapture(event.pointerId); } catch {}
        active = { id: event.pointerId, y: event.clientY, start: kind === "volume" ? prefs.volume : prefs.brightness, moved: false };
      });
      zone.addEventListener("pointermove", event => {
        if (!active || event.pointerId !== active.id) return;
        const dy = active.y - event.clientY;
        if (!active.moved && Math.abs(dy) < 8) return;
        active.moved = true;
        event.preventDefault();
        const height = wrapper.getBoundingClientRect().height || 1;
        const span = kind === "volume" ? 1 : BRIGHT_MAX - BRIGHT_MIN;
        const next = active.start + (dy / (height * 0.7)) * span;
        if (kind === "volume") setVolume(next); else setBrightness(next);
      });
      const end = event => {
        if (!active || event.pointerId !== active.id) return;
        if (active.moved) savePrefs();
        active = null;
      };
      zone.addEventListener("pointerup", end);
      zone.addEventListener("pointercancel", end);
      zone.addEventListener("contextmenu", event => event.preventDefault());
      zone.addEventListener("wheel", event => {
        if (isLocked() || !gesturesOn()) return;
        event.preventDefault();
        const step = -Math.sign(event.deltaY) * (kind === "volume" ? 0.05 : 0.06);
        if (kind === "volume") setVolume(prefs.volume + step); else setBrightness(prefs.brightness + step);
        savePrefs();
      }, { passive: false });
    }
    bindZone(zoneLeft, "volume");
    bindZone(zoneRight, "brightness");

    /* lock */
    const buzz = ms => { try { navigator.vibrate?.(ms); } catch {} };
    function wakeShield() {
      shield.classList.add("is-awake");
      clearTimeout(awakeTimer);
      awakeTimer = setTimeout(() => shield.classList.remove("is-awake"), 3000);
    }
    function setLocked(value) {
      if (value) target.dataset.pdLocked = "1"; else delete target.dataset.pdLocked;
      sync();
      buzz(value ? 20 : [12, 40, 12]);
      if (value) wakeShield(); else { shield.classList.remove("is-awake"); unlockBtn.classList.remove("is-holding"); }
    }
    lockBtn.addEventListener("click", () => setLocked(true));
    shield.addEventListener("pointerdown", wakeShield);
    shield.addEventListener("contextmenu", event => event.preventDefault());
    shield.addEventListener("touchmove", event => event.preventDefault(), { passive: false });
    unlockBtn.addEventListener("pointerdown", event => {
      event.stopPropagation();
      wakeShield();
      unlockBtn.classList.add("is-holding");
      clearTimeout(holdTimer);
      holdTimer = setTimeout(() => setLocked(false), 700);
    });
    ["pointerup", "pointercancel", "pointerleave"].forEach(name => unlockBtn.addEventListener(name, () => {
      clearTimeout(holdTimer);
      unlockBtn.classList.remove("is-holding");
    }));
    unlockBtn.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); setLocked(false); } });

    /* gestures toggle + fullscreen */
    gestureBtn.addEventListener("click", () => {
      prefs.gestures = gesturesOn() ? "off" : "on";
      savePrefs();
      sync();
      showBanner(prefs.gestures === "on"
        ? "Swipe the left edge for volume, the right edge for brightness."
        : "Swipe gestures off.", [], 2600);
    });
    async function keepAwake(on) {
      try {
        if (on && navigator.wakeLock && !wakeLock) {
          wakeLock = await navigator.wakeLock.request("screen");
          wakeLock.addEventListener("release", () => { wakeLock = null; });
        } else if (!on && wakeLock) { await wakeLock.release(); wakeLock = null; }
      } catch {}
    }
    async function enterFs() {
      const request = target.requestFullscreen || target.webkitRequestFullscreen;
      if (request) {
        try {
          await request.call(target);
          try { await screen.orientation?.lock?.("landscape"); } catch {}
          keepAwake(true);
          sync();
          return;
        } catch {}
      }
      // iPhone Safari (no element fullscreen): fill the viewport instead.
      target.classList.add("pd-pseudo-fs");
      document.documentElement.classList.add("pd-no-scroll");
      keepAwake(true);
      sync();
    }
    async function exitFs() {
      if (nativeFsElement()) { try { await (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch {} }
      target.classList.remove("pd-pseudo-fs");
      document.documentElement.classList.remove("pd-no-scroll");
      try { screen.orientation?.unlock?.(); } catch {}
      keepAwake(false);
      sync();
    }
    fsBtn.addEventListener("click", () => { if (isFs()) exitFs(); else enterFs(); });
    function stepEpisode(dir) {
      const links = [...document.querySelectorAll("#watch-navigator-footer a")];
      const link = links.find(a => new RegExp(dir < 0 ? "Previous" : "Next", "i").test(a.textContent));
      if (link) link.click(); else showBanner(dir < 0 ? "This is the first episode." : "No next episode available.", [], 2200);
    }
    prevBtn.addEventListener("click", () => stepEpisode(-1));
    nextBtn.addEventListener("click", () => stepEpisode(1));
    function toggleShield(forceOff) {
      const turnOff = forceOff ? true : shieldOn();
      prefs.shieldOff = Object.assign({}, prefs.shieldOff, { [shieldKey]: turnOff });
      savePrefs(); applyShield(); sync(); reload();
      showBanner(turnOff ? "Ad shield OFF for this server \u2014 pop-up ads may appear." : (SHIELD_OFF_BY_DEFAULT[shieldKey] ? "Ad shield ON \u2014 this server may show \u201cSandbox Detected\u201d; turn it off again if so." : "Ad shield ON \u2014 pop-ups and redirects are blocked."), [], 4200);
    }
    shieldBtn.addEventListener("click", () => toggleShield(false));
    function nextLink() {
      if (!hasAlts) return;
      altIndex = (altIndex + 1) % src.alts.length;
      const url = src.alts[altIndex];
      src = { ...src, url, origin: new URL(url).origin };
      reload();
      showBanner(`AutoEmbed link ${altIndex + 1} of ${src.alts.length}. Not the right video? Tap again.`, [], 6000);
    }
    altBtn.addEventListener("click", nextLink);
    reloadBtn.addEventListener("click", () => { reload(); showBanner("Reloading the video\u2026", [], 1800); });
    const onKey = event => {
      if (event.key === "Escape" && target.classList.contains("pd-pseudo-fs") && !isLocked()) { exitFs(); return; }
      if (event.ctrlKey || event.metaKey || event.altKey || isLocked()) return;
      const t = event.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      const k = String(event.key || "").toLowerCase();
      if (k === "f") fsBtn.click();
      else if (k === "l") setLocked(true);
      else if (k === "r") reloadBtn.click();
      else if (k === "g") gestureBtn.click();
      else if (k === "a") toggleShield(false);
      else if (k === "s") nextServer();
      else if (k === "v" && hasAlts) nextLink();
      else if (k === "n" && hasEps) stepEpisode(1);
      else if (k === "p" && hasEps) stepEpisode(-1);
      else if (k === "?" || k === "/") showBanner("Keys: F fullscreen \u00b7 L lock \u00b7 R reload \u00b7 S next server" + (hasEps ? " \u00b7 N / P next / previous episode" : "") + " \u00b7 G gestures \u00b7 A ad shield", [], 8000);
      else return;
      event.preventDefault();
    };
    document.addEventListener("keydown", onKey);
    const onVisible = () => { if (!dead && document.visibilityState === "visible" && isFs()) keepAwake(true); };
    document.addEventListener("visibilitychange", onVisible);

    /* controls fade a little when idle */
    const wakeControls = () => {
      controls.classList.add("is-awake");
      clearTimeout(ctlTimer);
      ctlTimer = setTimeout(() => controls.classList.remove("is-awake"), 3000);
    };
    wrapper.addEventListener("pointermove", wakeControls, { passive: true });
    wrapper.addEventListener("pointerdown", wakeControls, { passive: true });

    /* banner (hints + "not playing" help) */
    let bannerTimer = 0;
    function showBanner(text, actions, autoHideMs) {
      banner.replaceChildren(el("span", "", ""));
      banner.firstChild.textContent = text;
      (actions || []).forEach(action => {
        const button = el("button", action.primary ? "pd-primary" : "");
        button.type = "button";
        button.textContent = action.label;
        button.addEventListener("click", () => { action.run(); });
        banner.append(button);
      });
      banner.hidden = false;
      clearTimeout(bannerTimer);
      if (autoHideMs) bannerTimer = setTimeout(() => { banner.hidden = true; }, autoHideMs);
    }
    const hideBanner = () => { clearTimeout(bannerTimer); banner.hidden = true; };
    function reload() { hideBanner(); showLoader(); frame.src = "about:blank"; setTimeout(() => { if (!dead) frame.src = src.url; armStall(); }, 60); }
    function nextServer() {
      hideBanner();
      let next = ((Number(options.playbackServer) || 1) % SERVER_COUNT) + 1;
      if (options.type === "anime" && SERVERS[next].provider === "vidstuck") next = (next % SERVER_COUNT) + 1;
      const button = document.querySelector(`[data-watch-server="${next}"]`);
      if (button) button.click(); else reload();
    }
    function armStall() {
      clearTimeout(stallTimer);
      if (cur.signal || SIGNALS[src.provider] === false) return;
      stallTimer = setTimeout(() => {
        if (dead || cur.signal || isLocked()) return;
        const actions = [{ label: "Try another server", primary: true, run: nextServer }];
        if (shieldOn()) actions.push({ label: "Ad shield off", run: () => toggleShield(true) });
        actions.push({ label: "Dismiss", run: hideBanner });
        showBanner("Not playing yet?", actions);
      }, STALL_MS);
    }
    armStall();
    if (hasAlts) showBanner("Wrong or empty video? Tap the swap button for another AutoEmbed link.", [], 7000);

    if (touch && customFs && !prefs.hinted) {
      prefs.hinted = true;
      savePrefs();
      showBanner("Tip: fullscreen enables swipe brightness; the lock stops accidental touches.", [], 6000);
    }

    /* messages from the embed (vidstuck: JSON string · vumeto: object with gaia:/publicdrop: type) */
    function parseMessage(event) {
      let data = event.data;
      if (typeof data === "string") { try { data = JSON.parse(data); } catch { return null; } }
      if (!data || typeof data !== "object") return null;
      const type = String(data.type || "");
      if (type === "PLAYER_EVENT" && data.data && typeof data.data === "object") {
        const d = data.data;
        return { kind: "progress", currentTime: Number(d.currentTime), duration: Number(d.duration), season: d.season, episode: d.episode, completed: d.event === "ended" };
      }
      if (/embed-episode-change$/.test(type) && data.payload) return { kind: "episode", ...data.payload };
      if (/playback-progress$/.test(type) && data.payload) return { kind: "progress", ...data.payload };
      if ("timestamp" in data || "duration" in data) {
        return { kind: "progress", currentTime: Number(data.timestamp), duration: Number(data.duration), season: data.season, episode: data.episode };
      }
      return null;
    }
    const validInt = value => Number.isInteger(Number(value)) && Number(value) >= 1;
    function episodeMoved(season, episode) {
      if (!isTv || !validInt(season) || !validInt(episode)) return;
      season = Number(season); episode = Number(episode);
      if (season === cur.season && episode === cur.episode) return;
      const automatic = season === cur.season && episode === cur.episode + 1 && cur.ratio >= 0.85;
      cur.season = season; cur.episode = episode; cur.ratio = 0; cur.lastReport = 0;
      window.dispatchEvent(new CustomEvent("publicdrop:player-episode-change", {
        cancelable: true,
        detail: { id: String(options.id), type: options.type, season, episode, automatic, dub: options.dub },
      }));
    }
    function onMessage(event) {
      if (dead || event.source !== frame.contentWindow || event.origin !== src.origin) return;
      const message = parseMessage(event);
      if (!message) return;
      cur.signal = true;
      clearTimeout(stallTimer);
      if (!banner.hidden && banner.textContent.startsWith("Not playing")) hideBanner();
      if (message.kind === "episode") { episodeMoved(message.season, message.episode); return; }
      const currentTime = Number(message.currentTime), duration = Number(message.duration);
      if (isTv) episodeMoved(message.season, message.episode);
      if (!Number.isFinite(currentTime) || !Number.isFinite(duration) || duration <= 0) return;
      cur.ratio = currentTime / duration;
      const now = Date.now();
      const nearEnd = cur.ratio >= 0.9 || message.completed;
      if (!nearEnd && now - cur.lastReport < 4000) return;
      cur.lastReport = now;
      if (typeof options.onProgress === "function") {
        const movie = options.type === "movie";
        options.onProgress({
          type: options.type, id: String(options.id),
          season: movie ? 0 : (validInt(message.season) ? Number(message.season) : cur.season),
          episode: movie ? 0 : (validInt(message.episode) ? Number(message.episode) : cur.episode),
          currentTime, duration, completed: Boolean(message.completed), metadata: options.metadata,
        });
      }
    }
    window.addEventListener("message", onMessage);

    sync();

    return function cleanup() {
      dead = true;
      [hudTimer, awakeTimer, holdTimer, stallTimer, ctlTimer, bannerTimer, loaderTimer].forEach(clearTimeout);
      window.removeEventListener("message", onMessage);
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("visibilitychange", onVisible);
      keepAwake(false);
      fsListeners.delete(sync);
      wrapper.remove();
      // Fullscreen + lock belong to the .watch-shell, so they carry over to the next episode on purpose.
    };
  }

  window.PublicDROPStaticPlayer = Object.freeze({ mount, version: "5.0.0" });
})();
