(function () {
  "use strict";

  const API_URL = "https://bintvjson.lovable.app/api/public/bintvjson";
  const PLAYER_HOST = "bintv-sources.pages.dev";
  const cache = new Map();
  const CHANNEL_PAGE_SIZE = 24;
  const boundRoots = new WeakSet();
  let renderToken = 0;
  let state = { tab: "live", query: "", sports: [], live: [], upcoming: [], channels: [] };

  function localPreviewData() {
    const query = new URLSearchParams((location.hash.split("?")[1] || ""));
    if (!/^(?:localhost|127\.0\.0\.1)$/i.test(location.hostname) || query.get("preview") !== "1") return null;
    const now = Date.now();
    const sports = [{ id: "football", name: "Football" }, { id: "basketball", name: "Basketball" }, { id: "hockey", name: "Hockey" }, { id: "tennis", name: "Tennis" }, { id: "mma", name: "MMA" }];
    const matches = [
      { id:"preview-1",title:"Arsenal vs Manchester City",category:"football",date:now-18*60000,popular:true,_live:true,teams:{home:{name:"Arsenal"},away:{name:"Manchester City"}},sources:[{source:"alpha",id:"preview"},{source:"bravo",id:"preview"}] },
      { id:"preview-2",title:"Los Angeles vs Denver",category:"basketball",date:now-7*60000,popular:true,_live:true,teams:{home:{name:"Los Angeles"},away:{name:"Denver"}},sources:[{source:"charlie",id:"preview"}] },
      { id:"preview-3",title:"New York vs Toronto",category:"hockey",date:now+42*60000,popular:false,teams:{home:{name:"New York"},away:{name:"Toronto"}},sources:[{source:"delta",id:"preview"},{source:"echo",id:"preview"}] },
      { id:"preview-4",title:"Madrid Open — Centre Court",category:"tennis",date:now+84*60000,popular:true,teams:{home:{name:"Centre Court"},away:{name:"Live coverage"}},sources:[{source:"foxtrot",id:"preview"}] },
      { id:"preview-5",title:"Fight Night: Main Card",category:"mma",date:now+140*60000,popular:false,teams:{home:{name:"Main event"},away:{name:"Fight night"}},sources:[{source:"golf",id:"preview"}] },
      { id:"preview-6",title:"Liverpool vs Newcastle",category:"football",date:now+190*60000,popular:true,teams:{home:{name:"Liverpool"},away:{name:"Newcastle"}},sources:[{source:"hotel",id:"preview"},{source:"intel",id:"preview"}] },
    ];
    return { sports, live: matches.filter(match => match._live), upcoming: matches.filter(match => !match._live), channels: [] };
  }

  const escapeHTML = value => String(value ?? "").replace(/[&<>'"]/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
  })[character]);

  async function requestCatalog(ttl = 30000) {
    const key = API_URL;
    const saved = cache.get(key);
    if (saved && Date.now() - saved.time < ttl) return saved.value;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(API_URL, { signal: controller.signal, headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error(`BinTV API returned ${response.status}`);
      const value = await response.json();
      if (!value?.success) throw new Error("BinTV returned an invalid catalog.");
      cache.set(key, { time: Date.now(), value });
      return value;
    } finally {
      clearTimeout(timeout);
    }
  }

  function imageUrl(value) {
    if (!/^https?:\/\/[^\s]+$/i.test(String(value || ""))) return "";
    // Catalog artwork includes HTTP CDN links; upgrade rather than discard it
    // or introduce mixed content on the HTTPS site.
    return String(value).replace(/^http:/i, "https:");
  }

  function badgeUrl(value) {
    return imageUrl(value);
  }

  function playerUrl(value) {
    try {
      const url = new URL(String(value || ""));
      return url.protocol === "https:" && url.hostname === PLAYER_HOST ? url.href : "";
    } catch {
      return "";
    }
  }

  function normalizeEvent(item, fallbackStatus) {
    if (!item?.id || !item?.name) return null;
    const streams = (Array.isArray(item.streams) ? item.streams : []).map((stream, index) => {
      const embedUrl = playerUrl(stream?.url);
      if (!embedUrl) return null;
      const name = String(stream?.name || `Feed ${index + 1}`);
      return { embedUrl, name, language: name, hd: /(?:\bhd\b|4k|1080|720)/i.test(name), streamNo: index + 1 };
    }).filter(Boolean);
    if (!streams.length) return null;
    const title = String(item.name).trim();
    const versus = title.split(/\s+(?:vs\.?|v|@)\s+/i);
    return {
      id: String(item.id), title, category: String(item.category || "Other"),
      poster: imageUrl(item.poster), status: String(item.status || fallbackStatus),
      _live: String(item.status || fallbackStatus).toLowerCase() === "live",
      teams: versus.length === 2 ? { home: { name: versus[0] }, away: { name: versus[1] } } : null,
      sources: streams,
    };
  }

  function normalizeCatalog(data) {
    const list = (name, status) => (Array.isArray(data?.[name]) ? data[name] : []).map(item => normalizeEvent(item, status)).filter(Boolean);
    const live = list("Live Events", "live");
    const upcoming = list("Upcoming Events", "upcoming");
    const channels = list("24/7 Channels", "24/7");
    const categories = [...new Set([...live, ...upcoming, ...channels].map(item => item.category))];
    return { sports: categories.map(id => ({ id, name: id })), live, upcoming, channels };
  }

  function uniqueMatches(groups) {
    const found = new Map();
    groups.flat().forEach(match => {
      if (!match?.id) return;
      const previous = found.get(String(match.id));
      found.set(String(match.id), { ...previous, ...match, _live: Boolean(match._live || previous?._live) });
    });
    return [...found.values()].sort((a, b) => Number(a.date || 0) - Number(b.date || 0));
  }

  function sportName(id) {
    return state.sports.find(sport => sport.id === id)?.name || String(id || "Sports").replace(/-/g, " ");
  }

  function teamMarkup(team, side) {
    if (!team) return `<div class="sports-team is-placeholder"><span class="sports-team-badge">${side === "home" ? "H" : "A"}</span><strong>TBA</strong></div>`;
    const badge = badgeUrl(team.badge);
    return `<div class="sports-team"><span class="sports-team-badge">${badge ? `<img src="${escapeHTML(badge)}" alt="" loading="lazy">` : escapeHTML(String(team.name || "T").charAt(0))}</span><strong>${escapeHTML(team.name || "TBA")}</strong></div>`;
  }

  function timeParts(match) {
    const value = Number(match.date || 0);
    if (!value) return { day: "Scheduled", time: "Time TBA" };
    const date = new Date(value);
    return {
      day: new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(date),
      time: new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(date),
    };
  }

  function matchCard(match, featured = false) {
    const teams = match.teams || {};
    const timing = timeParts(match);
    const poster = imageUrl(match.poster);
    const sourceCount = Array.isArray(match.sources) ? match.sources.length : 0;
    const channel = match.status === "24/7";
    return `<article class="sports-match-card ${poster ? "has-poster" : ""} ${channel ? "is-channel" : ""}" data-sports-match="${escapeHTML(match.id)}">
      <div class="sports-match-art">
        ${poster ? `<img class="sports-event-poster" src="${escapeHTML(poster)}" alt="" loading="lazy" decoding="async">` : ""}
        ${channel ? `<span class="sports-channel-fallback" aria-hidden="true">${escapeHTML(String(match.title || "TV").slice(0, 3).toUpperCase())}</span>` : ""}
        <div class="sports-versus">${teamMarkup(teams.home, "home")}<span class="sports-vs">VS</span>${teamMarkup(teams.away, "away")}</div>
        <span class="sports-card-play" aria-hidden="true">▶</span>
      </div>
      <div class="sports-match-copy"><span class="sports-event-category">${channel ? "Live TV · 24/7" : escapeHTML(sportName(match.category))}</span>
        <h3>${escapeHTML(match.title || "Live sporting event")}</h3>
        ${match.date ? `<time>${escapeHTML(timing.day)} · ${escapeHTML(timing.time)}</time>` : ""}
      </div>
      <button class="sports-card-hit" type="button" data-watch-sport="${escapeHTML(match.id)}" aria-label="${escapeHTML(`${match._live ? "Watch live" : "View streams"}: ${match.title} (${sourceCount} feeds)`)}"></button>
    </article>`;
  }

  function selectedMatches() {
    let matches = state.tab === "live" ? state.live : state.tab === "channels" ? state.channels : state.upcoming;
    if (state.query) {
      const query = state.query.toLowerCase();
      matches = matches.filter(match => `${match.title || ""} ${match.teams?.home?.name || ""} ${match.teams?.away?.name || ""}`.toLowerCase().includes(query));
    }
    if (state.tab === "channels") {
      if (state.channelLetter) matches = matches.filter(match => channelLetter(match.title) === state.channelLetter);
      matches = [...matches].sort((a, b) => a.title.localeCompare(b.title, undefined, { numeric: true, sensitivity: "base" }));
    }
    return matches;
  }

  function channelLetter(title) {
    const first = String(title || "").trim().charAt(0).toUpperCase();
    return /^[A-Z]$/.test(first) ? first : "#";
  }

  function channelPage(matches, requestedPage = 0) {
    const pages = Math.max(1, Math.ceil(matches.length / CHANNEL_PAGE_SIZE));
    const page = Math.max(0, Math.min(Number(requestedPage) || 0, pages - 1));
    return { page, pages, items: matches.slice(page * CHANNEL_PAGE_SIZE, (page + 1) * CHANNEL_PAGE_SIZE) };
  }

  function renderChannelNavigation(root, matches) {
    const target = root.querySelector("[data-channel-navigation]");
    const pager = root.querySelector("[data-channel-pagination]");
    if (!target || !pager) return;
    target.hidden = pager.hidden = state.tab !== "channels";
    if (target.hidden) return;
    const letters = [...new Set(state.channels.map(match => channelLetter(match.title)))].sort();
    target.innerHTML = `<span>Browse by name</span><div class="sports-channel-letters"><button type="button" data-channel-letter="" aria-pressed="${!state.channelLetter}">All</button>${letters.map(letter => `<button type="button" data-channel-letter="${escapeHTML(letter)}" aria-pressed="${state.channelLetter === letter}">${escapeHTML(letter)}</button>`).join("")}</div>`;
    const { page, pages } = channelPage(matches, state.channelPage);
    state.channelPage = page;
    pager.innerHTML = `<span>${matches.length ? page * CHANNEL_PAGE_SIZE + 1 : 0}–${Math.min((page + 1) * CHANNEL_PAGE_SIZE, matches.length)} of ${matches.length} channels</span><div><button type="button" data-channel-page="${page - 1}" ${page === 0 ? "disabled" : ""}>← Previous</button><label>Page <select data-channel-page-select aria-label="Channel page">${Array.from({ length: pages }, (_, index) => `<option value="${index}" ${index === page ? "selected" : ""}>${index + 1}</option>`).join("")}</select> of ${pages}</label><button type="button" data-channel-page="${page + 1}" ${page === pages - 1 ? "disabled" : ""}>Next →</button></div>`;
  }

  function groupedMatches(matches) {
    const groups = new Map();
    matches.forEach(match => {
      const id = String(match.category || "other");
      if (!groups.has(id)) groups.set(id, []);
      groups.get(id).push(match);
    });
    const order = new Map(state.sports.map((sport, index) => [String(sport.id), index]));
    return [...groups.entries()].sort(([left], [right]) => {
      const leftIndex = order.has(left) ? order.get(left) : Number.MAX_SAFE_INTEGER;
      const rightIndex = order.has(right) ? order.get(right) : Number.MAX_SAFE_INTEGER;
      return leftIndex - rightIndex || sportName(left).localeCompare(sportName(right));
    });
  }

  function categoryRow(category, matches) {
    const title = sportName(category);
    return `<section class="sports-category-row rail-section">
      <div class="section-heading">
        <h2>${escapeHTML(title)}</h2>
        <div class="rail-heading-actions">
          <button class="rail-arrow" type="button" data-rail-scroll="left" aria-label="Scroll ${escapeHTML(title)} left"><svg><use href="#i-back"></use></svg></button>
          <button class="rail-arrow" type="button" data-rail-scroll="right" aria-label="Scroll ${escapeHTML(title)} right"><svg><use href="#i-arrow"></use></svg></button>
        </div>
      </div>
      <div class="sports-event-rail media-rail" aria-label="${escapeHTML(title)} events">${matches.map(match => matchCard(match)).join("")}</div>
    </section>`;
  }

  function renderMatches(root) {
    const matches = selectedMatches();
    const target = root.querySelector("[data-sports-groups]");
    const count = root.querySelector("[data-sports-count]");
    if (count) count.textContent = `${matches.length} ${state.tab === "live" ? "streaming" : state.tab === "channels" ? "channels" : "scheduled"}`;
    const heading = root.querySelector("[data-sports-section-title]");
    if (heading) heading.textContent = state.tab === "live" ? "Live" : state.tab === "channels" ? "Live TV channels" : "Upcoming";
    renderChannelNavigation(root, matches);
    const preview = root.querySelector("[data-channel-preview]");
    if (preview) preview.hidden = state.tab === "channels" || !state.channels.length;
    const search = root.querySelector("[data-sports-search]");
    if (search) search.placeholder = state.tab === "channels" ? "Search channel names" : "Search teams or events";
    if (!target) return;
    const visible = state.tab === "channels" ? channelPage(matches, state.channelPage).items : matches;
    target.innerHTML = visible.length ? visible.map(match => matchCard(match)).join("") : `<div class="sports-empty"><span>◉</span><h3>No ${state.tab === "channels" ? "channels" : "events"} found</h3><p>Try another name or clear your filters.</p><button type="button" data-sports-reset>Clear filters</button></div>`;
  }

  function renderLoaded(root) {
    root.innerHTML = `<div class="sports-page sports-catalog-page">
      <section class="sports-content" id="sports-events">
        <div class="sports-heading"><div><span class="eyebrow">PublicDROP Sports</span><h2>Match centre</h2></div><label class="sports-search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><input type="search" aria-label="Search teams or events" placeholder="Search teams or events" data-sports-search></label></div>
        <div class="sports-toolbar"><div class="sports-tabs"><button type="button" class="active" data-sports-tab="live" aria-pressed="true"><i></i> Live <b>${state.live.length}</b></button><button type="button" data-sports-tab="upcoming" aria-pressed="false"><i></i> Upcoming <b>${state.upcoming.length}</b></button><button type="button" data-sports-tab="channels" aria-pressed="false"><i></i> Live TV <b>${state.channels.length}</b></button></div></div>
        <div class="sports-results-heading"><h3 data-sports-section-title>Live</h3><span data-sports-count></span></div>
        <nav class="sports-channel-navigation" data-channel-navigation aria-label="Channel name filters" hidden></nav>
        <div class="sports-match-grid" data-sports-groups></div>
        <nav class="sports-channel-pagination" data-channel-pagination aria-label="Channel pages" hidden></nav>
        <section class="sports-channel-preview" data-channel-preview>
          <div class="sports-channel-preview-heading"><div><h3>Live TV channels</h3><span>${state.channels.length} channels · streaming 24/7</span></div><button type="button" data-channel-view-all>View all channels →</button></div>
          <div class="sports-match-grid sports-channel-preview-grid">${state.channels.slice(0, 10).map(match => matchCard(match)).join("")}</div>
        </section>
        <div class="sports-data-credit"><span>Live event data</span><a href="https://bintvjson.lovable.app/api/public/bintvjson" target="_blank" rel="noopener noreferrer">Powered by BinTV</a></div>
      </section>
      <section class="sports-player-panel" data-sports-player hidden></section>
    </div>`;
    renderMatches(root);
  }

  function streamButton(stream, index, active) {
    return `<button type="button" class="${active ? "active" : ""}" data-sports-stream="${index}"><span>Server ${Number(stream.streamNo) || index + 1}</span><small>${escapeHTML(stream.language || "Unknown")} · ${stream.hd ? "HD" : "SD"}</small></button>`;
  }

  async function openPlayer(root, match) {
    const panel = root.querySelector("[data-sports-player]");
    if (!panel) return;
    panel.hidden = false;
    panel.innerHTML = `<div class="sports-player-backdrop" data-close-sports-player></div><div class="sports-player-dialog"><button type="button" class="sports-player-close" data-close-sports-player aria-label="Close">×</button><div class="sports-player-loading"><span></span><h2>Finding available feeds</h2><p>${escapeHTML(match.title || "Live event")}</p></div></div>`;
    document.body.classList.add("sports-player-open");
    try {
      const sources = (Array.isArray(match.sources) ? match.sources : []).filter(stream => playerUrl(stream?.embedUrl));
      if (!sources.length) throw new Error("No stream sources are listed for this event.");
      const unique = [...new Map(sources.map(stream => [stream.embedUrl, stream])).values()].sort((a, b) => Number(b.hd) - Number(a.hd) || String(a.language || "").localeCompare(String(b.language || "")));
      if (!unique.length) throw new Error("No playable feeds are available for this event yet.");
      panel.dataset.streams = JSON.stringify(unique);
      panel.querySelector(".sports-player-dialog").innerHTML = `<button type="button" class="sports-player-close" data-close-sports-player aria-label="Close">×</button><div class="sports-player-head"><div><span class="sports-live-badge"><i></i> Live event</span><h2>${escapeHTML(match.title || "Live sport")}</h2></div><span>${unique.length} feed${unique.length === 1 ? "" : "s"}</span></div><div class="sports-player-layout"><div class="sports-embed-shell"><iframe src="${escapeHTML(unique[0].embedUrl)}" title="${escapeHTML(match.title || "Live sports stream")}" allow="autoplay; fullscreen; picture-in-picture; encrypted-media" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div><aside><span class="eyebrow">Choose a feed</span><div class="sports-stream-list">${unique.map((stream, index) => streamButton(stream, index, index === 0)).join("")}</div></aside></div>`;
    } catch (error) {
      panel.querySelector(".sports-player-dialog").innerHTML = `<button type="button" class="sports-player-close" data-close-sports-player aria-label="Close">×</button><div class="sports-player-error"><span>!</span><h2>Stream unavailable</h2><p>${escapeHTML(error.message || "No feed could be loaded.")}</p><button type="button" data-close-sports-player>Back to matches</button></div>`;
    }
  }

  function bind(root) {
    if (boundRoots.has(root)) return;
    boundRoots.add(root);
    root.addEventListener("error", event => {
      if (!event.target.matches?.(".sports-event-poster")) return;
      event.target.hidden = true;
      event.target.closest(".sports-match-card")?.classList.add("poster-unavailable");
    }, true);
    root.addEventListener("click", event => {
      if (event.target.closest("[data-channel-view-all]")) {
        state.query = ""; state.channelLetter = ""; state.channelPage = 0;
        const input = root.querySelector("[data-sports-search]"); if (input) input.value = "";
        root.querySelector('[data-sports-tab="channels"]')?.click();
        root.querySelector(".sports-toolbar")?.scrollIntoView({ block: "start" });
        input?.focus({ preventScroll: true }); return;
      }
      const letter = event.target.closest("[data-channel-letter]");
      if (letter) { state.channelLetter = letter.dataset.channelLetter; state.channelPage = 0; renderMatches(root); return; }
      const page = event.target.closest("[data-channel-page]");
      if (page && !page.disabled) { state.channelPage = Number(page.dataset.channelPage); renderMatches(root); root.querySelector("[data-sports-section-title]")?.scrollIntoView({ block: "start" }); return; }
      const tab = event.target.closest("[data-sports-tab]");
      if (tab) {
        state.tab = tab.dataset.sportsTab;
        state.channelPage = 0; state.channelLetter = "";
        root.querySelectorAll("[data-sports-tab]").forEach(button => { button.classList.toggle("active", button === tab); button.setAttribute("aria-pressed", String(button === tab)); });
        renderMatches(root); return;
      }
      const reset = event.target.closest("[data-sports-reset]");
      if (reset) {
        state.query = "";
        state.channelPage = 0; state.channelLetter = "";
        const input = root.querySelector("[data-sports-search]"); if (input) input.value = "";
        renderMatches(root); return;
      }
      if (event.target.closest("[data-close-sports-player]")) {
        const panel = root.querySelector("[data-sports-player]"); if (panel) { panel.hidden = true; panel.innerHTML = ""; }
        document.body.classList.remove("sports-player-open"); return;
      }
      const streamButtonNode = event.target.closest("[data-sports-stream]");
      if (streamButtonNode) {
        const panel = root.querySelector("[data-sports-player]");
        const streams = JSON.parse(panel?.dataset.streams || "[]");
        const stream = streams[Number(streamButtonNode.dataset.sportsStream)];
        const frame = panel?.querySelector("iframe"); if (frame && stream?.embedUrl) frame.src = stream.embedUrl;
        panel?.querySelectorAll("[data-sports-stream]").forEach(button => button.classList.toggle("active", button === streamButtonNode)); return;
      }
      const watch = event.target.closest("[data-watch-sport], [data-sports-match]");
      if (watch) {
        if (event.target.closest("a")) return;
        const id = watch.dataset.watchSport || watch.dataset.sportsMatch;
        const match = uniqueMatches([state.live, state.upcoming, state.channels]).find(item => String(item.id) === String(id));
        if (match) openPlayer(root, match);
      }
    });
    root.addEventListener("input", event => {
      if (!event.target.matches("[data-sports-search]")) return;
      state.query = event.target.value.trim(); state.channelPage = 0; renderMatches(root);
    });
    root.addEventListener("change", event => {
      if (!event.target.matches("[data-channel-page-select]")) return;
      state.channelPage = Number(event.target.value); renderMatches(root);
      root.querySelector("[data-sports-section-title]")?.scrollIntoView({ block: "start" });
    });
  }

  async function render(root) {
    const token = ++renderToken;
    document.body.classList.remove("sports-player-open");
    root.innerHTML = `<div class="sports-page"><section class="sports-loading"><div><span class="sports-load-mark">G</span><p>Opening the live arena</p><i></i></div></section></div>`;
    bind(root);
    const preview = localPreviewData();
    if (preview) {
      state = { tab:"live", query:"", ...preview };
      renderLoaded(root);
      return;
    }
    try {
      const catalog = await requestCatalog();
      if (token !== renderToken || !root.isConnected) return;
      state = { tab: "live", query: "", ...normalizeCatalog(catalog) };
      if (!state.live.length && !state.upcoming.length && !state.channels.length) throw new Error("The live sports service returned no playable feeds.");
      renderLoaded(root);
    } catch (error) {
      if (token !== renderToken || !root.isConnected) return;
      root.innerHTML = `<div class="sports-page"><section class="sports-api-error"><span class="eyebrow">Live arena</span><h1>Sports are temporarily offline</h1><p>${escapeHTML(error.message || "The event service could not be reached.")}</p><button type="button" class="primary-button" data-sports-retry>Try again</button></section></div>`;
      root.querySelector("[data-sports-retry]")?.addEventListener("click", () => render(root));
    }
  }

  window.PublicDROPSports = { render };
})();
