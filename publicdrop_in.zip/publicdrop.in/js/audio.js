/* PublicDROP audio language: default Hindi. Saved with the account through the existing settings sync (auth.js). */
(function () {
  "use strict";
  var KEY = "publicdrop-audio-lang";
  var LANGS = [
    { code: "hi", name: "Hindi", native: "हिन्दी", sub: "hindi" }, { code: "en", name: "English", native: "English", sub: "english" },
    { code: "ta", name: "Tamil", native: "தமிழ்", sub: "tamil" }, { code: "te", name: "Telugu", native: "తెలుగు", sub: "telugu" },
    { code: "ml", name: "Malayalam", native: "മലയാളം", sub: "malayalam" }, { code: "kn", name: "Kannada", native: "ಕನ್ನಡ", sub: "kannada" },
    { code: "bn", name: "Bengali", native: "বাংলা", sub: "bengali" }, { code: "mr", name: "Marathi", native: "मराठी", sub: "marathi" },
    { code: "pa", name: "Punjabi", native: "ਪੰਜਾਬੀ", sub: "punjabi" }
  ];
  function info(code) { for (var i = 0; i < LANGS.length; i++) if (LANGS[i].code === code) return LANGS[i]; return { code: code, name: String(code || "").toUpperCase(), native: "", sub: "english" }; }
  function get() { var v = ""; try { v = localStorage.getItem(KEY) || ""; } catch (e) {} return LANGS.some(function (l) { return l.code === v; }) ? v : "hi"; }
  function set(code) {
    if (!LANGS.some(function (l) { return l.code === code; }) || code === get()) return;
    try { localStorage.setItem(KEY, code); } catch (e) {}
    window.dispatchEvent(new CustomEvent("publicdrop:audio-changed", { detail: { code: code } }));
  }
  /* true = the title is in this language, false = it is not, null = we cannot tell yet (TMDB only knows the original + spoken languages) */
  function originalOf(x) { return x ? String(x.originalLanguage || x.original_language || "") : ""; }
  function supports(x, code) {
    code = code || get(); if (!x) return null;
    var o = originalOf(x), sp = x.spokenLanguages || (x.spoken_languages || []).map(function (l) { return l && l.iso_639_1; });
    if (o === code || (sp || []).indexOf(code) >= 0) return true;
    if (!o && !(sp && sp.length)) return null;
    return false;
  }
  function options(selected) { return LANGS.map(function (l) { return '<option value="' + l.code + '"' + (l.code === selected ? " selected" : "") + ">" + l.name + (l.native && l.native !== l.name ? " (" + l.native + ")" : "") + "</option>"; }).join(""); }

  /* popup: shown when the chosen audio language is probably not available for the title being played */
  function notice(opts) {
    if (document.getElementById("pd-audio-pop")) return;
    if (!document.getElementById("pd-audio-css")) {
      var st = document.createElement("style"); st.id = "pd-audio-css";
      st.textContent = "#pd-audio-pop{position:fixed;inset:0;z-index:2000;display:grid;place-items:center;padding:18px;background:rgba(0,0,0,.62);backdrop-filter:blur(6px)}#pd-audio-pop .b{width:100%;max-width:420px;background:var(--surface,#14161c);color:var(--text,#fff);border:1px solid rgba(255,255,255,.14);border-radius:22px;padding:24px;box-shadow:0 30px 80px rgba(0,0,0,.6)}#pd-audio-pop h3{margin:0 0 8px;font-size:1.15rem}#pd-audio-pop p{margin:0 0 18px;color:var(--muted,#aab);line-height:1.5;font-size:.93rem}#pd-audio-pop .r{display:flex;gap:10px;flex-wrap:wrap}#pd-audio-pop button{flex:1;min-height:44px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:transparent;color:inherit;font:700 .9rem inherit;cursor:pointer}#pd-audio-pop button.p{background:var(--accent,#e50914);border-color:transparent;color:#fff}#pd-audio-pop select{width:100%;min-height:44px;margin:0 0 14px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:inherit;padding:0 10px;font:inherit}#pd-audio-pop select option{color:#000}";
      document.head.appendChild(st);
    }
    var d = document.createElement("div"); d.id = "pd-audio-pop"; d.setAttribute("role", "dialog"); d.setAttribute("aria-modal", "true");
    d.innerHTML = '<div class="b"><h3></h3><p></p><select aria-label="Audio language"></select><div class="r"><button type="button" data-a="stay"></button><button type="button" class="p" data-a="change">Change language</button></div></div>';
    d.querySelector("h3").textContent = info(opts.code).name + " audio may not be available";
    d.querySelector("p").textContent = (opts.title ? "\u201C" + opts.title + "\u201D" : "This title") + " looks like a " + info(opts.original).name + " title, so " + info(opts.code).name + " audio may not be available. You can play it anyway, or pick another audio language.";
    d.querySelector("select").innerHTML = options(opts.original && info(opts.original).name !== String(opts.original).toUpperCase() ? opts.original : "en");
    d.querySelector('[data-a="stay"]').textContent = "Play anyway";
    function close() { d.remove(); }
    d.querySelector('[data-a="stay"]').onclick = close;
    d.querySelector('[data-a="change"]').onclick = function () { var v = d.querySelector("select").value; close(); set(v); };
    d.addEventListener("click", function (e) { if (e.target === d) close(); });
    document.body.appendChild(d); d.querySelector("button.p").focus();
  }

  /* top-bar language button: shows the code (HI) and opens a picker */
  function pick() {
    if (document.getElementById("pd-audio-pick")) return;
    var d = document.createElement("div"); d.id = "pd-audio-pop"; d.setAttribute("role", "dialog"); d.setAttribute("aria-modal", "true");
    d.innerHTML = '<div class="b"><h3>Movie language</h3><p>The home page shows the top hit movies made in this language.</p><div class="pd-ap-list"></div></div>';
    var list = d.querySelector(".pd-ap-list");
    LANGS.forEach(function (l) {
      var b = document.createElement("button"); b.type = "button"; b.style.cssText = "width:100%;justify-content:space-between;display:flex;align-items:center;margin:0 0 8px;padding:0 14px;text-align:left";
      b.className = l.code === get() ? "p" : ""; b.textContent = l.name + (l.native !== l.name ? " (" + l.native + ")" : "");
      b.onclick = function () { set(l.code); d.remove(); }; list.appendChild(b);
    });
    d.addEventListener("click", function (e) { if (e.target === d) d.remove(); });
    ensureCss(); document.body.appendChild(d);
  }
  function ensureCss() {
    if (document.getElementById("pd-audio-css")) return;
    var st = document.createElement("style"); st.id = "pd-audio-css";
    st.textContent = "#pd-audio-pop{position:fixed;inset:0;z-index:2000;display:grid;place-items:center;padding:18px;background:rgba(0,0,0,.62);backdrop-filter:blur(6px)}#pd-audio-pop .b{width:100%;max-width:420px;max-height:88vh;overflow:auto;background:var(--surface,#14161c);color:var(--text,#fff);border:1px solid rgba(255,255,255,.14);border-radius:22px;padding:24px;box-shadow:0 30px 80px rgba(0,0,0,.6)}#pd-audio-pop h3{margin:0 0 8px;font-size:1.15rem}#pd-audio-pop p{margin:0 0 18px;color:var(--muted,#aab);line-height:1.5;font-size:.93rem}#pd-audio-pop .r{display:flex;gap:10px;flex-wrap:wrap}#pd-audio-pop button{flex:1;min-height:44px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:transparent;color:inherit;font:700 .9rem inherit;cursor:pointer}#pd-audio-pop button.p{background:var(--accent,#e50914);border-color:transparent;color:#fff}#pd-audio-pop select{width:100%;min-height:44px;margin:0 0 14px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:inherit;padding:0 10px;font:inherit}#pd-audio-pop select option{color:#000}.lang-chip{width:auto!important;min-width:40px;padding:0 10px!important;font:800 .72rem/1 inherit!important;letter-spacing:.04em}";
    document.head.appendChild(st);
  }
  function bindChip() {
    ensureCss(); var c = document.getElementById("audio-button"); if (!c) return;
    function paint() { c.textContent = get().toUpperCase(); c.title = "Movie language: " + info(get()).name; }
    paint(); c.onclick = pick; window.addEventListener("publicdrop:audio-changed", paint); window.addEventListener("publicdrop:settings-loaded", paint);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bindChip); else bindChip();

  /* settings drawer (works for guests too) */
  function bindSelect() {
    var s = document.getElementById("audio-select"); if (!s) return;
    s.innerHTML = options(get()); s.onchange = function () { set(s.value); };
    window.addEventListener("publicdrop:audio-changed", function () { s.value = get(); });
    window.addEventListener("publicdrop:settings-loaded", function () { s.value = get(); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bindSelect); else bindSelect();

  /* ---- automatic proof that a Hollywood title is probably available in the chosen language ----
     Four checks, each worth 1 point. A title passes with 3 of 4 and it MUST have an India release:
       hit          well liked worldwide (many votes + good rating, or big box office)
       india        released in India (cinema / digital) or streaming there
       local        TMDB has this language listed for the title (Hindi title / description = it was localised for India)
       demand       it was in Indian cinemas, or is on Netflix / Prime Video / Hotstar in India
     TMDB has no audio-track data, so this is strong evidence, not a guarantee. */
  var IN_PLATFORMS = [8, 119, 122, 2336, 220, 232, 237];
  function evidence(type, raw, code) {
    code = code || get(); var r = { hit: false, india: false, local: false, demand: false };
    if (!raw) return { ok: false, points: 0, r: r };
    var votes = raw.vote_count || 0, avg = raw.vote_average || 0, rev = raw.revenue || 0, tv = type === "tv";
    r.hit = tv ? (votes >= 500 && avg >= 6.5) : ((votes >= 1000 && avg >= 6.3) || rev >= 100000000);
    var wp = (raw["watch/providers"] && raw["watch/providers"].results && raw["watch/providers"].results.IN) || {};
    var flat = (wp.flatrate || []).map(function (p) { return p.provider_id; }), any = flat.length || (wp.rent || []).length || (wp.buy || []).length;
    var types = []; ((raw.release_dates && raw.release_dates.results) || []).forEach(function (x) { if (x.iso_3166_1 === "IN") (x.release_dates || []).forEach(function (d) { types.push(d.type); }); });
    if (tv) { r.india = !!any; r.demand = flat.some(function (id) { return IN_PLATFORMS.indexOf(id) >= 0; }); }
    else { r.india = types.some(function (t) { return t === 2 || t === 3 || t === 4; }); r.demand = types.indexOf(3) >= 0 || flat.length > 0; }
    r.local = ((raw.translations && raw.translations.translations) || []).some(function (t) { return t && t.iso_639_1 === code; });
    var pts = (r.hit ? 1 : 0) + (r.india ? 1 : 0) + (r.local ? 1 : 0) + (r.demand ? 1 : 0);
    return { ok: r.india && pts >= 3, points: pts, r: r };
  }
  var VKEY = "pd-dubv1";
  function vload() { try { return JSON.parse(localStorage.getItem(VKEY) || "{}") || {}; } catch (e) { return {}; } }
  function verdictGet(type, id, code) { var v = vload()[(code || get()) + ":" + type + ":" + id]; return v && Date.now() - v[1] < 7 * 864e5 ? !!v[0] : null; }
  function verdictSet(type, id, ok, code) {
    var m = vload(), k = Object.keys(m); if (k.length > 800) k.slice(0, 200).forEach(function (x) { delete m[x]; });
    m[(code || get()) + ":" + type + ":" + id] = [ok ? 1 : 0, Date.now()]; try { localStorage.setItem(VKEY, JSON.stringify(m)); } catch (e) {}
  }

  window.PublicDROPAudio = Object.freeze({ evidence: evidence, verdictGet: verdictGet, verdictSet: verdictSet, get: get, set: set, info: info, langs: LANGS, supports: supports, originalOf: originalOf, options: options, notice: notice });
})();
